from ast import Return
from pyexpat import model
from attr import dataclass
from django.contrib.auth.models import Group
from django.core import serializers
from django.core.mail import send_mail
from django.db.models import Q, query
from django.apps import apps
from django.contrib import messages
from django.contrib.auth import authenticate, login
from django.contrib.auth.decorators import login_required, permission_required
from django.contrib.auth.hashers import check_password, make_password
from django.contrib.auth.mixins import (LoginRequiredMixin, PermissionRequiredMixin)
from django.db import connection, migrations
from django.db.models import Avg, Count, Max, Min, ProtectedError, Q, Sum
from django.http import Http404, HttpResponse, HttpResponseRedirect, JsonResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.template import loader
from django.template.defaultfilters import date
from django.utils import timezone
from django.contrib.auth.models import User
from django.contrib.sessions.models import Session
from django.views import generic
from django.views.decorators.csrf import csrf_protect
from django.views.generic import CreateView, View
from rest_framework import generics
from django.contrib.auth import logout
from django.core.paginator import Paginator
from django_datatables_view.base_datatable_view import BaseDatatableView
from django.utils.html import escape
from .forms import *
from .models import *
from jalali_date import datetime2jalali, date2jalali
import random
import string
import requests
from zeep import Client
import jdatetime
from WebSite.templatetags.intdot import *
from django.db.models import F

from django.views.decorators.csrf import csrf_exempt
from idpay.api import IDPayAPI
import requests
import uuid

from django.core.mail import send_mail

# Just For Logout Of WebSite.


def logout_view(request):
    logout(request)
    request.session.get_expire_at_browser_close()
    request.session.clear_expired()
    if request.session.test_cookie_worked():
        request.session.delete_test_cookie()

    return redirect('WebSite:login')


forms = {'productsForm': productsForm, 'productsFormUpdate': productsFormUpdate, 'productsgroupsform': productsgroupsform, 'productsgroupsFormUpdate': productsgroupsFormUpdate, 'productsbrandsform': productsbrandsform,
         'productsbrandsUpdate': productsbrandsUpdate, 'userinfocreate': userinfocreate, 'userinfoupdate': userinfoupdate, 'formslidercreate': formslidercreate, 'formsliderupdate': formsliderupdate,
         'firstpagebanersform': firstpagebanersform, 'firstpagebanersFormUpdate': firstpagebanersFormUpdate, 'aboutusForm': aboutusForm, 'aboutusFormUpdate': aboutusFormUpdate, 'centercontactusForm': centercontactusForm, 'centercontactusFormUpdate': centercontactusFormUpdate,
         'salecontactusForm': salecontactusForm, 'salecontactusFormUpdate': salecontactusFormUpdate, 'customerquestionsForm': customerquestionsForm, 'customerquestionsFormUpdate': customerquestionsFormUpdate, 'aboutusp1Form': aboutusp1Form, 'aboutusp1FormUpdate': aboutusp1FormUpdate,
         'firstpagehlform': firstpagehlform, 'firstpagehlUpdate': firstpagehlUpdate, 'ersalform': ersalform, 'osoolform': osoolform, 'osoolformupdate': osoolformupdate, 'ersalformupdate': ersalformupdate, 'lastnewsform': lastnewsform, 'lastnewsformupdate': lastnewsformupdate,
         'parametsaccountsform': parametsaccountsform, 'parametsaccountsformupdate': parametsaccountsformupdate, 'parametssasform': parametssasform, 'parametssasformupdate': parametssasformupdate, 'parametssupportform': parametssupportform, 'parametssupportformupdate': parametssupportformupdate,
         'productscategoryform': productscategoryform, 'productscategoryformupdate': productscategoryformupdate, 'insideslidercreate': insideslidercreate, 'insidesliderupdate': insidesliderupdate, 'weblogform': weblogform, 'weblogformupdate': weblogformupdate,
         'DiscountFinalUpdateForm': DiscountFinalUpdateForm, 'customersgroupForm': customersgroupForm, 'customersgroupFormUpdate': customersgroupFormUpdate, 'productscolorsformUpdate': productscolorsformUpdate,
         'productssizeformUpdate': productssizeformUpdate, 'productsparametrformUpdate': productsparametrformUpdate, 'productsparaminvchargeformUpdate': productsparaminvchargeformUpdate}

# # Create your views here.


def get_all_logged_in_users(requset):
    # Query all non-expired sessions
    # use timezone.now() instead of datetime.now() in latest versions of Django
    sessions = Session.objects.filter(expire_date__gte=timezone.now())
    uid_list = []

    # Build a list of user ids from that query
    for session in sessions:
        data = session.get_decoded()
        uid_list.append(data.get('_auth_user_id', None))

    active_users = User.objects.filter(id__in=uid_list)
    return render(requset, 'activeusers.html', {'active_users': active_users})

class deleteusersession(View):
    def get(self,request):
        useractiveid = request.GET.get('activeuserid', None)
        sessions = Session.objects.filter(expire_date__gte=timezone.now())
        for session in sessions:
            data = session.get_decoded()
            if data['_auth_user_id'] != '5':
                Session.objects.all().delete()
        html = 'ارتباط کاربر با سیستم قطع شد .'
        data = {
            'html': html
        }
        return JsonResponse(data)


def makestars(request, pid):
    star = stars.objects.filter(pid_id=pid).values_list('stars')
    if star:
        star = star[0]
    else:
        star = [0]

    selecttedtstart = stars.objects.all()
    StarSum = stars.objects.filter(pid_id=pid).values('pid_id').order_by('pid_id').annotate(total_stars=Sum('stars'))
    Starcount = stars.objects.filter(pid_id=pid).values('pid_id').order_by('pid_id').annotate(count=Count('pid_id'))
    StarAvarage = []
    if Starcount:
        StarAvarage = (StarSum[0]['total_stars'] /(Starcount[0]['count']*5))*100

    return star ,  StarAvarage , Starcount , StarSum, pid

def calculateoff(price, product_id, product_count):
    sumBascketPriceoff = 0
    sumoff = 0
    for discount in price:
        if discount[1] == product_id:
            sumBascketPriceoff += discount[5]
            sumoff += discount[3] 
    return sumBascketPriceoff*product_count , sumoff*product_count


def makepreiceoff(request, getproductid ,colorid_bycolor, sizeid_bycolor, colorid_bysize, sizeid_bysize):
    sumBascketPriceoff = 0
    priceoff = 0
    total = 0
    price = 0
    off = 0
    orginalprice =0

    if int(colorid_bycolor) != 0:
        price = productsparamerts.objects.filter(pid_id = int(getproductid), cid_id = int(colorid_bycolor) , sid_id = int(sizeid_bycolor)).values_list('productprice', 'takhfif', 'takhfifprice')
    if int(colorid_bysize) != 0:
        price = productsparamerts.objects.filter(pid_id = int(getproductid), cid_id = int(colorid_bysize) , sid_id = int(sizeid_bysize)).values_list('productprice', 'takhfif', 'takhfifprice')
    
    p_c = sellbascket.objects.filter(Create_Uid=request.user.id, status=0, pid_id=int(getproductid), colorid_bycolor=int(colorid_bycolor),sizeid_bycolor=int(sizeid_bycolor),colorid_bysize=int(colorid_bysize), sizeid_bysize=int(sizeid_bysize))

    totalsum = 0
    totalsumsell = []
    totalcount = 0
    pct = sellbascket.objects.filter(Create_Uid=request.user.id, status=0)
    for t in pct:
        total = t.pcount * t.pprise
        totalsum += total
        totalcount += t.pcount
        totalsumsell = totalsum

    if len(price) != 0: 
        if p_c:
            for one_price in p_c: 
                if len(price) != 0:
                    priceoff = int(price[0][1])
                    off = int(price[0][2])
                    orginalprice = int(price[0][0])
                    sumBascketPriceoff = priceoff * one_price.pcount 
        else:
            priceoff = int(price[0][1])
            sumBascketPriceoff = priceoff
            orginalprice = int(price[0][0])
            off = int(price[0][2])
    else:
        priceoff = int(price[0][0])
        off = 0
        orginalprice = int(price[0][0])
        sumBascketPriceoff = totalsumsell

    return priceoff , sumBascketPriceoff, totalsumsell, off, orginalprice, totalcount


def convertdate(year, month, day, type):
    if type.lower() == 'shamsitomiladi':
        res = jdatetime.date(year, month, day).togregorian()
    elif type.lower() == 'miladitoshamsi':
        res = jdatetime.date.fromgregorian(day=day, month=month, year=year)
    return res


def MiladiToShamsi(Date):
    t = convertdate(Date)
    return t


# Creat For All Views
# @login_required(login_url='login')

@login_required(login_url='login')
@permission_required('User.can_read_private_section')
def create(request, ModelName, form_name, redirect_path, html_name, context_name):
    error = []
    cerror = []
    errorall = []
    form = forms[form_name]
    model = apps.get_model('WebSite', ModelName)
    Create_Uid = request.user.id
    Update_Uid = request.user.id
    DC = customersgroup.objects.all()

    cname = request.POST.get('cname')
    checkcname = productscategory.objects.filter(cname=cname)
    cname1 = request.POST.get('cname1')
    cname2 = request.POST.get('cname2')
    cname3 = request.POST.get('cname3')


    productname = request.POST.get('name')
    productgroup_id = request.POST.get('group')

    productgroup = 0
    if productgroup_id != '0':
        productgroup = productgroup_id
    

    checkproductname = '0'
    if ModelName == 'products':
        if productname != None and productgroup != None :
            checkproductname = products.objects.filter(Q(name=productname),  Q(group=productgroup))


    productgroups = request.POST.get('Group_Name')
    checkproductgroups = productsgroups.objects.all().filter(Group_Name=productgroups)

    if request.method == 'POST':
        if (cname1 and (cname1 == cname2 or cname1 == cname3) or (cname2 and cname2 == cname3)):
            cerror.append(
                ' توجه : کابر گرامی دسته بندی های انتخاب شده نباید یکسان باشند .'
            )
            context = form(request.POST)
            groups = productsgroups.objects.all()
            group_parent_name =  productsgroups.objects.all().filter(glevel=2) 
            group_parent_name_l1 =  productsgroups.objects.all().filter(glevel=1)

            errorall.append('توجه : کاربر گرامی برخی از اطلاعات وارد شده صحیح نمی باشند.')
            id = 0
            return render(request, '{}.html'.format(html_name), {'{}'.format(context_name): context,'id': id,'group_parent_name_l1': group_parent_name_l1,'group_parent_name': group_parent_name, 'groups': groups, 'error': error})
            
        if checkcname:
            error.append(
                'توجه : کاربر گرامی نام دسته بندی انتخاب شده تکراری می باشد .')
            context = form(request.POST)
            groups = productsgroups.objects.all()
            group_parent_name =  productsgroups.objects.all().filter(glevel=2) 
            group_parent_name_l1 =  productsgroups.objects.all().filter(glevel=1)

            errorall.append('توجه : کاربر گرامی برخی از اطلاعات وارد شده صحیح نمی باشند.')
            id = 0
            return render(request, '{}.html'.format(html_name), {'{}'.format(context_name): context,'id': id,'group_parent_name_l1': group_parent_name_l1,'group_parent_name': group_parent_name, 'groups': groups, 'error': error})
         
        if  len(checkproductname) > 1:
            error.append('توجه : کاربر گرامی نام محصول انتخاب شده در گروه جاری تکراری می باشد .')
            context = form(request.POST)
            groups = productsgroups.objects.all()
            group_parent_name =  productsgroups.objects.all().filter(glevel=2) 
            group_parent_name_l1 =  productsgroups.objects.all().filter(glevel=1)

            errorall.append('توجه : کاربر گرامی برخی از اطلاعات وارد شده صحیح نمی باشند.')
            id = 0
            return render(request, '{}.html'.format(html_name), {'{}'.format(context_name): context,'id': id,'group_parent_name_l1': group_parent_name_l1,'group_parent_name': group_parent_name, 'groups': groups, 'error': error})

        if checkproductgroups:
            error.append(
                'توجه : کاربر گرامی نام گروه وارد شده تکراری می باشد .')
            context = form(request.POST)
            groups = productsgroups.objects.all()
            group_parent_name =  productsgroups.objects.all().filter(glevel=2) 
            group_parent_name_l1 =  productsgroups.objects.all().filter(glevel=1)

            errorall.append('توجه : کاربر گرامی برخی از اطلاعات وارد شده صحیح نمی باشند.')
            id = 0
            return render(request, '{}.html'.format(html_name), {'{}'.format(context_name): context,'id': id,'group_parent_name_l1': group_parent_name_l1,'group_parent_name': group_parent_name, 'groups': groups, 'error': error})
         

        
        model.objects.filter(id=model.objects.latest('id').id).update(
            Create_Uid=Create_Uid, Update_Uid=Update_Uid)

        if ModelName == 'productsgroups':
            pgid = productsgroups.objects.all().filter(glevel=0)
            for pgid in pgid:
                if pgid.gparentid == 0:
                    productsgroups.objects.all().filter(gparentid=0).update(glevel=1)
            return redirect('WebSite:{}'.format(redirect_path))

        context = form(request.POST, request.FILES)
        if context.is_valid():
            context.save()
            model.objects.filter(id=model.objects.latest('id').id).update(Create_Uid=Create_Uid, Update_Uid=Update_Uid)
            if ModelName == 'productsgroups':
                pgid = productsgroups.objects.all().filter(glevel=0)
                for pgid in pgid:
                    if pgid.gparentid == 0:
                        productsgroups.objects.all().filter(gparentid=0).update(glevel=1)

            groups = productsgroups.objects.all()
            group_parent_name =  productsgroups.objects.all().filter(glevel=2) 
            group_parent_name_l1 =  productsgroups.objects.all().filter(glevel=1)
            
            if ModelName not in  ['products', 'productsgroups', 'productscategory']:
                return redirect('WebSite:{}'.format(redirect_path))
            else:
                return redirect('WebSite:{}'.format(redirect_path), id = 0)

        context = form(request.POST)
        groups = productsgroups.objects.all()
        group_parent_name =  productsgroups.objects.all().filter(glevel=2) 
        group_parent_name_l1 =  productsgroups.objects.all().filter(glevel=1)

        errorall.append('توجه : کاربر گرامی برخی از اطلاعات وارد شده صحیح نمی باشند.')
        id = 0
        return render(request, '{}.html'.format(html_name), {'{}'.format(context_name): context,'id': id,'group_parent_name_l1': group_parent_name_l1,'group_parent_name': group_parent_name, 'groups': groups, 'DC': DC, 'cname1': cname1, 'cname2': cname2, 'cname3': cname3, 'error': error})
            
    context = form(request.POST)
    groups = productsgroups.objects.all()

    group_parent_name =  productsgroups.objects.all().filter(glevel=2) 
    group_parent_name_l1 =  productsgroups.objects.all().filter(glevel=1)

    parenr_category = productscategory.objects.all().filter(cparentid=0)
    category = productscategory.objects.all().filter(cparentid__gt=0)
    id = 0
    return render(request, '{}.html'.format(html_name), {'{}'.format(context_name): context,'id': id, 'group_parent_name_l1': group_parent_name_l1,'parenr_category': parenr_category, 'category': category,'group_parent_name': group_parent_name, 'groups': groups, 'DC': DC, 'cname1': cname1, 'cname2': cname2, 'cname3': cname3, 'error': error})


# Update For All Views
@login_required(login_url='login')
@permission_required('User.can_read_private_section')
def update(request, ModelName, form_name, redirect_path, html_name, context_name, id):
    form = forms[form_name]
    model = apps.get_model('WebSite', ModelName)
    ins_obj = get_object_or_404(model, pk=int(id))
    ins_obj2 = model.objects.filter(id=id)
    DC = User.objects.all()
    groups = productsgroups.objects.all()
    Customersglist = customersgroup.objects.all()
    productbrand = products.objects.all().filter(
        id=id).values_list('brand', flat=True)

    brandp = []
    for b in productbrand:
        brandp.append(b)
    categoryproduct = productsgroups.objects.filter(id=0)

    parenr_category = productscategory.objects.all().filter(cparentid=0)
    category = productscategory.objects.all().filter(cparentid__gt=0)

    if ModelName == 'products':
        categoryproduct = productsgroups.objects.filter(
            id=ins_obj2[0].group_id)

    
    context = form(request.POST, request.FILES, instance=ins_obj)
    if request.method == 'POST':
        if context.is_valid():
            new_product_charge_inv = request.POST.get('productinventory_recharge', None)
            charged_info = productsparaminvcharge.objects.filter(id=id)
            for ch_info in charged_info:
                invchare = ch_info.productinventory_recharge

                if new_product_charge_inv != None:
                    defrence_inv = int(new_product_charge_inv) - int(invchare)

                    param_choseed = productsparamerts.objects.filter(pid_id=int(ch_info.invpid_id),cid_id=int(ch_info.invcid_id),
                    sid_id=int(ch_info.invsid_id))
                    for pa_ch in param_choseed:
                        productsparamerts.objects.filter(
                            pid_id=int(ch_info.invpid_id),
                            cid_id=int(ch_info.invcid_id),
                            sid_id=int(ch_info.invsid_id)
                        ).update(
                        productinventory_recharge = int(invchare)+int(defrence_inv),
                        productinventory_remain = (int(pa_ch.productinventory)+(int(pa_ch.productinventory_recharge)+int(defrence_inv)))-int(pa_ch.productinventory_sold)
                        )
            context.save()

            if ModelName == 'productsparamerts':
                new_remain_in_update = request.POST.get('productinventory', None)
                old_remain = productsparamerts.objects.get(id=id).productinventory_remain
                sold = productsparamerts.objects.get(id=id).productinventory_sold
                recharge = productsparamerts.objects.get(id=id).productinventory_recharge
                calculat_remain = ((int(old_remain))+ (int(new_remain_in_update)-int(old_remain))+int(recharge))-int(sold)
                productsparamerts.objects.filter(id=id).update(productinventory_remain=int(calculat_remain))


            new_product_charge_inv = request.POST.get('productinventory_recharge', None)
            charged_info = productsparaminvcharge.objects.filter(id=id)
            for ch_info in charged_info:
                invchare = ch_info.productinventory_recharge

                if new_product_charge_inv != None:
                    defrence_inv = int(new_product_charge_inv) - int(invchare)

                    new_remain = (int(ch_info.productinventory)+(int(ch_info.productinventory_recharge)-int(defrence_inv)))-int(ch_info.productinventory_sold)
                    productsparaminvcharge.objects.filter(id = id).update(productinventory_remain = int(new_remain))

            products_id_check = []
            for pic in products.objects.all().values_list('id', flat=True):
                products_id_check.append(pic)

            products_id = 0
            products_priceorg = 0
            products_specialcell = 0
            for aid in products_id_check:
                if id == aid:
                    products_id = products.objects.get(id=id).id
                    products_priceorg = products.objects.get(id=id).priceorg
                    products_specialcell = products.objects.get(id=id).specialcell

            spsell = request.POST.get('specialcell')
            spsell_result = 'False'
            if spsell == 'on':
                spsell_result == 'True'

                
            if ModelName not in  ['products', 'productsgroups', 'productscategory']:
                return redirect('WebSite:{}'.format(redirect_path))
            else:
                if id != 0:
                    if ModelName == 'productsgroups':
                        return redirect('WebSite:{}'.format(redirect_path), id = 0)
                    else:
                        return redirect('WebSite:{}'.format(redirect_path), id = id)
                else:
                    return redirect('WebSite:{}'.format(redirect_path), id = 0)

        return redirect('WebSite:{}'.format(redirect_path) )

    context = form(instance=ins_obj)
    id = id
    if id == 0:
        id = 0
    groups = productsgroups.objects.all()
    group_parent_name =  productsgroups.objects.all().filter(glevel=2) 
    group_parent_name_l1 =  productsgroups.objects.all().filter(glevel=1)

    parametrs = productsparamerts.objects.all().filter(id=id)
    product = products.objects.all()
    parametr_color = productscolors.objects.all()
    parametr_size = productssize.objects.all()


    paramproducts = productsparamerts.objects.values('pid_id').annotate(count=Count('pid_id')).order_by()
    products_info_charge = []
    for pinfo in paramproducts:
        prodc = products.objects.filter(id=pinfo['pid_id']).values_list('id','name')
        products_info_charge.append(prodc)
    colors = productscolors.objects.all()
    sizes = productssize.objects.all()
    
    sizes_chose = 0
    colors_chose = 0
    products_chose = 0
    new_product_charge_inv = request.POST.get('productinventory_recharge', None)
    charged_info = productsparaminvcharge.objects.filter(id=id)
    for ch_info in charged_info:
        colors_chose = productscolors.objects.filter(id=ch_info.invcid_id)
        sizes_chose = productssize.objects.filter(id=ch_info.invsid_id)
        products_chose = products.objects.filter(id=ch_info.invpid_id)
        invchare = ch_info.productinventory_recharge

                

    return render(request, '{}.html'.format(html_name), {'{}'.format(context_name): context,
     'group_parent_name_l1': group_parent_name_l1,'id': id,
     'group_parent_name': group_parent_name, 'groups': groups,
      'ins_obj2': ins_obj2, 'groups': groups, 'categoryproduct': categoryproduct,
       'parenr_category': parenr_category, 'category': category,
        'Customersglist': Customersglist, 'DC': DC, 'productbrand': productbrand,
         'brandp': brandp,  'parametrs': parametrs, 'products': product
        , 'parametr_color': parametr_color, 'parametr_size': parametr_size,
        'sizes_chose': sizes_chose ,'colors_chose': colors_chose,
        'sizes': sizes, 'colors': colors, 'products_chose': products_chose,
        'products_info_charge': products_info_charge})


# Delete For All Views
# @login_required(login_url='login')
@login_required(login_url='login')
@permission_required('User.can_read_private_section')
def delete(request, ModelName, redirect_path, id):
    model = apps.get_model('WebSite', ModelName)
    to_delete = get_object_or_404(model, pk=int(id))

    check_pid_in_productsparamerts = productsparamerts.objects.filter(pid_id = int(id))
    if ModelName == 'products':
        if check_pid_in_productsparamerts :
            error = ('کاربر گرامی : کالایی که قصد حذف آن را دارید در لیست قیمت ها دارای قیمت بوده و قابل حذف نمی باشد در صورت نیاز لطفا ابتدا تمامی قیمت های مربوط به این کالا را حذف نمایید و سپس اقدام به حذف این کلا کنید . ')
            return render(request, 'product.html', {'id': id, 'error': error})
        else:
            to_delete.delete()
            return render(request, 'product.html', {'id': id})

    if ModelName == 'productsgroups':
        parent_id = 0
        gparent_id = productsgroups.objects.get(id=id).gparentid
        if gparent_id:
            parent_id = gparent_id

        products_check = products.objects.filter(group_id=id)
        productsgroup_check = productsgroups.objects.filter(gparentid=id)
        if len(products_check) > 0:
            error = ('کاربر گرامی در برخی از کالا ها از این گروه استفاده شده است')
        elif len(productsgroup_check) > 0:
            error = ('کاربر گرامی این گروه دارای زیر مجموعه می باشد')
        else:
            to_delete.delete()
        return redirect('WebSite:{}'.format(redirect_path), id=parent_id)

    if ModelName == 'productsparaminvcharge':
        charged_info = productsparaminvcharge.objects.filter(id=id)
        for ch_info in charged_info:
            invchare = ch_info.productinventory_recharge

            if invchare != 0:
                defrence_inv = int(invchare)
                param_choseed = productsparamerts.objects.filter(pid_id=int(ch_info.invpid_id),cid_id=int(ch_info.invcid_id),
                sid_id=int(ch_info.invsid_id))
                for pa_ch in param_choseed:
                    productsparamerts.objects.filter(
                        pid_id=int(ch_info.invpid_id),
                        cid_id=int(ch_info.invcid_id),
                        sid_id=int(ch_info.invsid_id)
                        ).update(
                        productinventory_recharge = int(pa_ch.productinventory_recharge)-int(defrence_inv),
                        productinventory_remain = (int(pa_ch.productinventory)+(int(pa_ch.productinventory_recharge)-int(defrence_inv)))-int(pa_ch.productinventory_sold)
                        )
    if ModelName == 'productscategory':
        to_delete.delete()
        return redirect('WebSite:{}'.format(redirect_path), id = 0)

    to_delete.delete()
    return redirect('WebSite:{}'.format(redirect_path))


@login_required(login_url='login')
@permission_required('User.can_read_private_section')
def create_user(request):
    error = []
    checkusername = request.POST.get('username')
    customersgroupid = customersgroup.objects.all()
    if request.method == 'POST':
        Users = userinfocreate(request.POST, request.FILES)
        if User.objects.filter(username=checkusername):
            listUsers = User.objects.all()
            error.append(
                'توجه : کاربر گرامی نام کاربری {} تکراری می باشد .'.format(checkusername))
            id = 0
            return render(request, 'users_create.html',
                          {'Users': Users, 'listUsers': listUsers, 'error': error,'id': id})
        if Users.is_valid():
            user = Users.save()
            user.set_password(user.password)
            user.save()
            id = 0
            return redirect('WebSite:usersreport', id=id)
    listUsers = User.objects.all()
    Users = userinfocreate(request.POST)
    # Customerslist = Customers.objects.all()
    customersgroupid = customersgroup.objects.all()
    id = 0
    return render(request, 'users_create.html',
                  {'id': id,'Users': Users, 'listUsers': listUsers,'customersgroupid': customersgroupid})


# user_update
@login_required(login_url='login')
@permission_required('User.can_read_private_section')
def update_user(request, id):
    try:
        error = []
        edit_user = get_object_or_404(User, pk=id)
        Customerslist = Customers.objects.all()
        userinfo = User.objects.filter(id=id)
        customersgroupid = customersgroup.objects.all()
        Users = userupdate(request.POST, request.FILES, instance=edit_user)
        customersid = request.POST.get('id', '')
        if request.method == 'POST':
            print('step 2')
            if Users.is_valid():
                print('step 3')
                Users.save()

                print('step 4')
                id = 0
                if id > 0:
                    id = id
                return redirect('WebSite:usersreport' , id = id)
        Users = userinfoupdate(instance=edit_user)
        print('step 5')
        id = 0
        if id > 0:
            id = id
        return render(request, 'users_update.html', {'customersgroupid': customersgroupid, 'Users': Users, 'error': error, 'Customerslist': Customerslist, 'userinfo': userinfo, 'id': id})
    except Exception as error:
        print(error)

@login_required(login_url='login')
@permission_required('User.can_read_private_section')
def Delete_User(request, id):
    User_to_delete = get_object_or_404(User, pk=int(id))
    User_to_delete.delete()
    id = 0
    return redirect('WebSite:usersreport', id = id)


@login_required(login_url='login')
@permission_required('User.can_read_private_section')
def DeleteRecords(request, list_ids, ModelName, RedirectPath):
    error = []
    deletelist = []
    try:
        model = apps.get_model('WebSite', ModelName)
    except:
        model = apps.get_model('auth', ModelName)
    l = list_ids.split(",")
    l.remove('')
    counter = 0
    for ids in l:
        if len(ids) > 0:
            ModelName_delete = get_object_or_404(model, id=ids)
            try:
                ModelName_delete.delete()
                counter = counter + 1
                deletelist.append(ids)
            except ProtectedError:
                error.append(ids)
    id = 0
    return render(request, '{}.html'.format(RedirectPath), {
        '{}'.format(RedirectPath): model.objects.all(),
        'error': error,
        'deletelist': deletelist,
        'id': id
    })


@login_required(login_url='login')
@permission_required('User.can_read_private_section')
def ChangePassword_AdminView(request, id):
    error = []
    report = []
    newpass1 = request.POST.get('newpass')
    newpass2 = request.POST.get('password')
    if request.method == 'POST':
        if newpass1 == newpass2:
            User.objects.filter(id=id).update(password=make_password(newpass2))
            report.append(
                'توجه : کاربر گرامی کلمه عبور با موفقیت تغییر یافت .')
            if request.user.id == id:
                user = authenticate(
                    username=request.user.username, password=newpass2)
                if user is not None:
                    login(request, user)
            id = 0
            return render(request, 'AdminChangePassword.html', {'report': report, 'id': id})
        error.append(
            'توجه : کاربر گرامی کلمه های عبور وارد شده یکسان نمی باشد .')
        id = 0
        return render(request, 'AdminChangePassword.html', {'error': error, 'id': id})
    id = 0
    return render(request, 'AdminChangePassword.html', {'id': id})


@login_required(login_url='login')
def ChangePassword_UserView(request):
    error = []
    report = []
    newpass1 = request.POST.get('newpass')
    newpass2 = request.POST.get('password')
    oldpassword = request.POST.get('oldpassword')
    user = User.objects.get(id=request.user.id)
    user_id = request.user.id
    if request.method == 'POST':
        if user.check_password(oldpassword):
            if newpass1 == newpass2:
                User.objects.filter(id=user_id).update(
                    password=make_password(newpass2))
                report.append(
                    'توجه : کاربر گرامی کلمه عبور با موفقیت تغییر یافت .')
                user = authenticate(
                    username=request.user.username, password=newpass2)
                if user is not None:
                    login(request, user)
                id = 0
                return render(request, 'AUserChangePassword.html', {'report': report, 'id': id})
            error.append(
                'توجه : کاربر گرامی کلمه های عبور وارد شده یکسان نمی باشد .')
            id = 0
            return render(request, 'AUserChangePassword.html', {'error': error, 'id': id})
        error.append('توجه : کاربر گرامی کلمه عبور فعلی صحیح نمی باشد .')
        id = 0
        return render(request, 'AUserChangePassword.html', {'error': error, 'id': id})
    id = 0
    return render(request, 'AUserChangePassword.html', {'id': id})



def customersquestions_create(request):
    Create_Uid = request.user.id
    Update_Uid = request.user.id
    if request.method == 'POST':
        cq = customerquestionsForm(request.POST, request.FILES)
        if cq.is_valid():
            cq.save()
            customerquestions.objects.filter(id=customerquestions.objects.latest(
                'id').id).update(Create_Uid=Create_Uid, Update_Uid=Update_Uid)
            return redirect('WebSite:contact')
    cq = customerquestionsForm(request.POST)
    fcontact = centercontactus.objects.all()
    uccontactus = centercontactus.objects.all()
    uscontactus = salecontactus.objects.all()
    spg, spgid, spgt, spgtr ,spgtr2 = headermenu()
    fhlogo = firstpagelogo.objects.all()
    id = 0
    return render(request, 'contact.html', {'fcontact': fcontact, 'id': id, 'cq': cq, 'uccontactus': uccontactus, 'uscontactus': uscontactus, 'spg': spg, 'spgt': spgt, 'spgtr': spgtr, 'spgtr2': spgtr2, 'fhlogo': fhlogo})

class contactusreport(generic.ListView):
    model = customerquestions
    context_object_name = 'cq'
    template_name = 'contact.html'
    queryset = customerquestions.objects.all()

    def get_context_data(self, **kwargs):
        context = super(contactusreport, self).get_context_data(**kwargs)
        context['fcontact'] = centercontactus.objects.all()
        context['uccontactus'] = centercontactus.objects.all()
        context['centercontactus_info'] = centercontactus.objects.all()
        context['uscontactus'] = salecontactus.objects.all()
        spg, spgid, spgt, spgtr ,spgtr2 = headermenu()
        context['spg'] = spg
        context['spgid'] = spgid
        context['spgt'] = spgt
        context['spgtr'] = spgtr
        context['spgtr2'] = spgtr2
        context['fhlogo'] = firstpagelogo.objects.all()
        context['id'] = 0
        return context

class customersquestions_create(View):
    def get(self, request):
        html_success = ''
        html_tell_error = ''
        Create_Uid = request.user.id
        Update_Uid = request.user.id
        tell_start = '0'
        tel_lenght = 10
        inserted_tell = request.GET.get('cqtell', None)
        if inserted_tell[0:1] == tell_start and len(inserted_tell[1:]) == tel_lenght:
            if request.is_ajax():
                cq = customerquestions(
                name = request.GET.get('cqname', None), 
                title = request.GET.get('cqtitle', None),
                tell = request.GET.get('cqtell', None),
                email = request.GET.get('cqemail', None),
                desc = request.GET.get('cqdesc', None), 
                Create_Uid = Create_Uid,
                Update_Uid = Update_Uid
                )
                cq.save()
                html_success = 'سوال مورد نظر با موفقیت ایجاد شد'
        else:
            html_tell_error = 'شماره تلن وارد شده صحیح نمی باشد'
        
        data = {
            'html_success': html_success,
            'html_tell_error': html_tell_error
        }
        return JsonResponse(data)


class useraboutreportview(generic.ListView):
    model = aboutus
    context_object_name = 'about'
    template_name = 'about-2.html'
    queryset = aboutus.objects.all()

    def get_context_data(self, **kwargs):
        context = super(useraboutreportview, self).get_context_data(**kwargs)
        context['fcontact'] = centercontactus.objects.all()
        context['aboutusteam'] = aboutusp1.objects.all()
        context['aboutbrand'] = productsbrands.objects.all()
        context['form'] = User.objects.all()
        context['fhlogo'] = firstpagelogo.objects.all()
        spg, spgid, spgt, spgtr ,spgtr2 = headermenu()
        context['spg'] = spg
        context['spgid'] = spgid
        context['spgt'] = spgt
        context['spgtr'] = spgtr
        context['spgtr2'] = spgtr2
        return context


class showproductlist(generic.ListView):
    models = products
    context_object_name = 'productslist'
    template_name = 'products-category-boxed.html'

    def get(self, request, id):
        fehrests = productsgroups.objects.all()
        productslist = products.objects.all().filter(group=id , id__gt = 0)
        fhlogo = firstpagelogo.objects.all()
        aboutus_info = aboutus.objects.all()
        centercontactus_info = centercontactus.objects.all()
        return render(request, 'products-category-boxed.html', {'aboutus_info': aboutus_info, 'centercontactus_info': centercontactus_info, 'fhlogo': fhlogo, 'productslist': productslist, 'fehrests': fehrests})


class showproduct(generic.ListView):
    models = products

    def get(self, request, id, name=None):
        spg, spgid, spgt, spgtr ,spgtr2 = headermenu()

        max_p_price = []
        for lstid in range(1):
            param_best = productsparamerts.objects.filter(pid_id= id).values_list('productprice', 'pid', 'takhfifprice', 'productinventory_remain', 'takhfif').order_by('productprice')
            max_p_price.append(param_best)
        max_min_price_info_choseproduct = []
        for mpp in max_p_price:
            if len(mpp) > 0:
                remain_sum = productsparamerts.objects.filter(pid_id = mpp[0][1]).aggregate(sum=Sum('productinventory_remain'))['sum']
                max_product_price = max(list(mpp))
                min_product_price = min(list(mpp))
                product_price_select = mpp[0][1]
                product_price_after_takhfif = mpp[0][2]
                product_productinventory_remain = mpp[0][3]
                max_min_price_info_choseproduct.append((product_price_select,max_product_price[0],min_product_price[0], product_price_after_takhfif, product_productinventory_remain, remain_sum, max_product_price[2], int(max_product_price[4])))


        fehrests = productsgroups.objects.all()
        aboutus_info = aboutus.objects.all()
        centercontactus_info = centercontactus.objects.all()

        a = ''
        replacedesc = products.objects.filter(id=id).values_list('desc')
        for b in replacedesc:
            a = b
        c = str(a)
        truedesc = c.replace('.', '<br/>')

        gid = products.objects.all().filter(id=id).values_list('group_id')
        groupproducts = []
        for p1 in products.objects.all().filter(group_id=gid[0]):
            groupproducts.append(p1)
        
        max_p_price = []
        for group_products in groupproducts:
            param_best = productsparamerts.objects.filter(pid_id= group_products.id).values_list('productprice', 'pid', 'takhfifprice', 'productinventory_remain', 'takhfif').order_by('productprice')
            max_p_price.append(param_best)
        max_min_price_info_samegroup = []
        for mpp in max_p_price:
            if len(mpp) > 0:
                remain_sum = productsparamerts.objects.filter(pid_id = mpp[0][1]).aggregate(sum=Sum('productinventory_remain'))['sum']
                max_product_price = max(list(mpp))
                min_product_price = min(list(mpp))
                product_price_select = mpp[0][1]
                product_price_after_takhfif = mpp[0][2]
                product_productinventory_remain = mpp[0][3]
                max_min_price_info_samegroup.append((product_price_select,max_product_price[0],min_product_price[0], product_price_after_takhfif, product_productinventory_remain, remain_sum, max_product_price[2], int(max_product_price[4])))


        aboutproduct = products.objects.all().filter(id=id)
        technicalinfo = products.objects.all().filter(id=id)
        totalprice = 0
        SellBascket = sellbascket.objects.filter(Create_Uid=request.user.id, status=0).order_by('-id')
        SellBascket_list = []
        SellBascket_list_with_price = []
        sumoftotals = []
        
        if SellBascket:
            SellBascket_list = list(SellBascket.values())
            SellBascket_list_with_price=[]
            for a in SellBascket_list:
                SellBascket_list_with_price.append(a)
                totalprice += a['pprise']
                sumoftotals.append(totalprice)

        sumBascketPriceoff = 0
        if len(sumoftotals) != 0:
            sumBascketPriceoff = sumoftotals[0]

        sellbascketCount_find = sellbascket.objects.filter(Create_Uid=request.user.id, status=0).count()
        sellbascketCount = []
        if sellbascketCount_find:
            sellbascketCount = sellbascketCount_find

        productsdetails = products.objects.all().filter(id__gt= 0)
        productdetailsDesc = productdetails.objects.filter(Create_Uid=request.user.id)
        
        fhlogo = firstpagelogo.objects.all()
        # favoriteCount
        productdetailsDescCount = productdetails.objects.filter(Create_Uid=request.user.id, favorite=1).count()
        

        Comments = comment.objects.filter(pid_id=id, status=1)
        CommentCount = comment.objects.filter(pid_id=id, status=1).count()
        Users = User.objects.all()
        fcontact = centercontactus.objects.all()

        StarAvarage_percent = []
        for pid in groupproducts:
            star ,  StarAvarage , Starcount , StarSum , pid= makestars(request, pid.id)
            StarAvarage_percent.append((pid,StarAvarage))

        selecttedtstart = stars.objects.all()
        StarSum = stars.objects.filter(uid=request.user.id, pid_id=id).values('pid_id').order_by('pid_id').annotate(total_stars=Sum('stars'))
        Starcount = stars.objects.filter(uid=request.user.id, pid_id=id).values('pid_id').order_by('pid_id').annotate(count=Count('pid_id'))
        StarAvarage = []
        if Starcount:
            StarAvarage = (StarSum[0]['total_stars'] /(Starcount[0]['count']*5))*100

        showproduct = products.objects.all().filter(id = id)
        
        product_size_color = productsparamerts.objects.all().filter(pid_id=id)
        co = productsparamerts.objects.all().filter(pid_id=id).values('cid_id').annotate(count = Count('cid_id')).order_by('cid_id')
        si = productsparamerts.objects.all().filter(pid_id=id).values('sid_id').annotate(count = Count('sid_id')).order_by('sid_id')
        color = []
        for c_o in co:
            color_name = productscolors.objects.get(id=c_o['cid_id']).color
            color_id = productscolors.objects.get(id=c_o['cid_id']).id
            color_hegxa = productscolors.objects.get(id=c_o['cid_id']).hezacode
            products_id = self.kwargs.get('id')
            color.append((color_name, products_id, color_hegxa, color_id))
        size = []
        for s_o in si:
            size_name = productssize.objects.get(id=s_o['sid_id']).size
            size_id = productssize.objects.get(id=s_o['sid_id']).id
            products_id = self.kwargs.get('id')
            size.append((size_name ,products_id, size_id ))

        totalsum = 0
        totalsumsell = []
        totalcount = 0
        pct = sellbascket.objects.filter(Create_Uid=request.user.id, status=0)
        for t in pct:
            total = t.pcount * t.pprise
            totalsum += total
            totalcount += t.pcount
            totalsumsell = totalsum

        check_zero_procuts_count = productsparamerts.objects.all()

        session = Session.objects.all()

        error_list = []
        form = LoginForm(request.POST)
        if form.is_valid() and request.user.is_authenticated == False:
            cd = form.cleaned_data
            if User.objects.filter(username=cd['username']):
                if authenticate(username=cd['username'], password=cd['password']):
                    user = authenticate(
                        username=cd['username'], password=cd['password'])
                    if user is not None:
                        if user.is_active:
                            login(request, user)
                            return redirect(request.path)
                        error_list.append('کاربر وارد شده غیر فعال می باشد.')

        return render(request, 'products.html' , { 'max_min_price_info_choseproduct': max_min_price_info_choseproduct,
                                                    'max_min_price_info_samegroup': max_min_price_info_samegroup,
                                                    'showproduct': showproduct,'check_zero_procuts_count': check_zero_procuts_count,
                                                    'truedesc': truedesc, 'fcontact': fcontact, 'technicalinfo': technicalinfo, 
                                                    'aboutproduct': aboutproduct,  'fehrests': fehrests,
                                                    'groupproducts': groupproducts, 'SellBascket': SellBascket_list_with_price,
                                                    'sellbascketCount': sellbascketCount, 'sumBascketPriceoff': sumBascketPriceoff,
                                                    'productdetailsDesc': productdetailsDesc, 'productdetailsDescCount': productdetailsDescCount,
                                                     'productsdetails': productsdetails,
                                                    'Comments': Comments, 'CommentCount': CommentCount, 'Users': Users,
                                                    'id': id, 'spg': spg, 'spgt': spgt, 'spgtr': spgtr,
                                                    'spgtr2': spgtr2, 'fhlogo': fhlogo ,'aboutus_info': aboutus_info,
                                                    'centercontactus_info': centercontactus_info, 'selecttedtstart': selecttedtstart,
                                                    'StarAvarage_percent': StarAvarage_percent, 'color': color, 'size': size ,
                                                    'totalsumsell': totalsumsell, 'form': form, 'error_list': error_list})


        

class salebacket(generic.ListView):
    models = sellbascket
    template_name = 'cart.html'

    def get(self, request):

        userid = request.user.id
        off = 0
        orginalprice = 0
        user_info = User.objects.filter(id=userid)

        check_zero_procuts_count = productsparamerts.objects.all()
        sell_products = sellbascket.objects.all().filter(pgroupid = 0).values_list('pid_id')
        for pro_id in sell_products: 
            pro_group_id = products.objects.filter(id=pro_id[0]).values_list('group_id')
            for p_g_id in pro_group_id:
                sellbascket.objects.filter(pid_id=pro_id[0]).update(pgroupid=p_g_id[0])

        proid = sellbascket.objects.filter(status=1).filter(Create_Uid=request.user.id).values_list('pid_id', flat=True)
        plist = []
        for proide in proid:
            groupproducts = '0'
            plist.append(proide)

        p_list = []
        if len(plist) == 1:
            p_list = products.objects.all().filter(id__in=plist)[0]
        elif len(plist) == 2:
            p_list = products.objects.all().filter(id__in=plist)[0:1]
        elif len(plist) == 3:
            p_list = products.objects.all().filter(id__in=plist)[0:2]
        elif len(plist) == 4:
            p_list = products.objects.all().filter(id__in=plist)[0:3]
        elif len(plist) > 4:
            p_list = products.objects.all().filter(id__in=plist)[0:4]

        groupproducts = p_list
        max_p_price = []
        max_min_price_info_groupproducts = ['0', '0', '0', '0']
        if len(groupproducts)>0:
            for gr_pro in groupproducts:
                param_best = productsparamerts.objects.filter(pid_id= gr_pro.id).values_list('productprice', 'pid', 'takhfifprice', 'productinventory_remain', 'takhfif').order_by('productprice')
                max_p_price.append(param_best)
            max_min_price_info_groupproducts = []
            for mpp in max_p_price:
                if len(mpp) > 0:
                    remain_sum = productsparamerts.objects.filter(pid_id = mpp[0][1]).aggregate(sum=Sum('productinventory_remain'))['sum']
                    max_product_price = max(list(mpp))
                    min_product_price = min(list(mpp))
                    product_price_select = mpp[0][1]
                    product_price_after_takhfif = mpp[0][2]
                    product_productinventory_remain = mpp[0][3]
                    max_min_price_info_groupproducts.append((product_price_select,max_product_price[0],min_product_price[0], product_price_after_takhfif, product_productinventory_remain, remain_sum, max_product_price[2], int(max_product_price[4])))


        fehrests = productsgroups.objects.all()
        fhlogo = firstpagelogo.objects.all()
        sb = sellbascket.objects.all().filter(status=0, Create_Uid=userid)

        products_c_s = []
        psb = sellbascket.objects.all().filter(id__gt= 0, Create_Uid=request.user.id, status=0)
        for ppsb in psb:
            colorname = '0'
            colorname_info_bycolor = productscolors.objects.filter(id=ppsb.colorid_bycolor).values_list('color', flat=True)
            colorname_id_bycolor = productscolors.objects.filter(id=ppsb.colorid_bycolor).values_list('id', flat=True)
            colorname_info_bysize = productscolors.objects.filter(id=ppsb.colorid_bysize).values_list('color', flat=True)
            colorname_id_bysize = productscolors.objects.filter(id=ppsb.colorid_bysize).values_list('id', flat=True)

            if len(colorname_info_bycolor) > 0:
                if colorname_info_bycolor[0] != '0':
                    colorname = colorname_info_bycolor
                    colorname_id = colorname_id_bycolor
                else:
                    colorname = ['0']
            if len(colorname_info_bysize) > 0:        
                if colorname_info_bysize[0] != '0':
                    colorname = colorname_info_bysize
                    colorname_id = colorname_id_bysize
                else:
                    colorname = ['0']

            sizename = 0
            sizename_info_bycolor = productssize.objects.filter(id=ppsb.sizeid_bycolor).values_list('size', flat=True)
            sizename_id_bycolor = productssize.objects.filter(id=ppsb.sizeid_bycolor).values_list('id', flat=True)
            sizename_info_bysize = productssize.objects.filter(id=ppsb.sizeid_bysize).values_list('size', flat=True)
            sizename_id_bysize = productssize.objects.filter(id=ppsb.sizeid_bysize).values_list('id', flat=True)

            if len(sizename_info_bycolor) > 0:
                if sizename_info_bycolor[0] != '0':
                    sizename = sizename_info_bycolor
                    sizename_id = sizename_id_bycolor
                else:
                    sizename = ['0']
            if len(sizename_info_bysize) > 0:
                if sizename_info_bysize[0] != '0':
                    sizename = sizename_info_bysize
                    sizename_id = sizename_id_bysize
                else:
                    sizename = ['0']
                    
            product_name = products.objects.get(id=ppsb.pid_id).name
            product_serial = products.objects.get(id=ppsb.pid_id).serial
            product_img1 = products.objects.get(id=ppsb.pid_id).img1
            
            if ppsb.colorid_bycolor != 0:
                products_remain = productsparamerts.objects.get(pid_id= ppsb.pid_id, cid_id= ppsb.colorid_bycolor, sid_id= ppsb.sizeid_bycolor).productinventory_remain
            else:
                products_remain = productsparamerts.objects.get(pid_id= ppsb.pid_id, cid_id= ppsb.colorid_bysize, sid_id= ppsb.sizeid_bysize).productinventory_remain

            products_c_s.append(( ppsb.pid_id, colorname[0], sizename[0], product_name, product_serial , product_img1, products_remain, colorname_id[0], sizename_id[0]))
   
        spg, spgid, spgt, spgtr ,spgtr2 = headermenu()
   
        SellBascket = sellbascket.objects.filter(Create_Uid=request.user.id, status=0).order_by('-id')
        SellBascket_list = list(SellBascket.values())
        SellBascket_list_with_price=[]
        for a in SellBascket_list:  
            SellBascket_list_with_price.append(a)
   
        sellbascketCount = sellbascket.objects.filter(Create_Uid=request.user.id, status=0).count()
   
        max_price = '0'
        send_price = '0'
        pay_after_laastpay_free = '0'
        
        user_sellb = 0
        for sellb in SellBascket:
            user_sellb = products.objects.filter(id = sellb.pid_id).values_list('priceorg')[0][0]
 
        pay_after_laastpay = user_sellb

        sinfo = 0
        sumBascketPriceoff = 0
        priceoff = 0
        totalsumsell = 0
        totalcount = 0
        for sinfo in SellBascket_list:
            colorid_bycolor = sellbascket.objects.get(pid_id= sinfo['pid_id'], id = sinfo['id']).colorid_bycolor
            sizeid_bycolor = sellbascket.objects.get(pid_id= sinfo['pid_id'], id = sinfo['id']).sizeid_bycolor
            colorid_bysize = sellbascket.objects.get(pid_id= sinfo['pid_id'], id = sinfo['id']).colorid_bysize
            sizeid_bysize = sellbascket.objects.get(pid_id= sinfo['pid_id'], id = sinfo['id']).sizeid_bysize
            getproductid = sinfo['pid_id']
            priceoff , sumBascketPriceoff , totalsumsell, off, orginalprice, totalcount= makepreiceoff(request ,getproductid ,colorid_bycolor, sizeid_bycolor, colorid_bysize, sizeid_bysize)

        sumBascketPriceoff = sumBascketPriceoff
        pay_after_laastpay_vat = 0
        send_price = 0
        pay_after_laastpay = 0
        pay_calculated = 0
        send_count = 0
        DMaxType = 0
        discount_on_finalcheckout_price = price_off()
        if len(discount_on_finalcheckout_price) > 0:
            send_price = int(discount_on_finalcheckout_price[2])
            send_count = int(discount_on_finalcheckout_price[1])
            max_price = int(discount_on_finalcheckout_price[0])
            DMaxType = int(discount_on_finalcheckout_price[3])

            totalsumsell + send_price
            if totalsumsell <= max_price:
                totalsumsell
        # pay_after_laastpay_vat = str(((int(sumBascketPriceoff))*9)/100)
        # pay_after_laastpay_vat = '0'
        # vatprice = pay_after_laastpay_vat.split('.0')
        # int_pay_after_laastpay_vat = int(vatprice[0])
        int_pay_after_laastpay_vat = 0
        max_price_with_vat_cost = 0
        max_price_with_vat = 0
        if len(discount_on_finalcheckout_price) > 0:
            if DMaxType == 1:
                if int(max_price) > 0 and int(totalsumsell) >= int(max_price):
                    max_price_with_vat = int(totalsumsell) + int(int_pay_after_laastpay_vat)
                    ersalcost = 0
                elif int(max_price) > 0 and  int(totalsumsell) < int(max_price):
                    max_price_with_vat_cost = int(totalsumsell) + int(send_price) + int(int_pay_after_laastpay_vat)
                    ersalcost = send_price
            elif DMaxType == 2: 
                if int(send_count) > 0 and int(totalcount) >= int(send_count):
                    max_price_with_vat = int(totalsumsell) + int(int_pay_after_laastpay_vat)
                    ersalcost = 0
                elif int(send_count) > 0 and  int(totalcount) < int(send_count):
                    max_price_with_vat_cost = int(totalsumsell) + int(send_price) + int(int_pay_after_laastpay_vat)
                    ersalcost = send_price
            elif DMaxType == 3:
                if int(max_price) > 0 and  int(send_count) > 0 and int(totalsumsell) >= int(max_price) or int(totalcount) >= int(send_count):
                    max_price_with_vat = int(totalsumsell) + int(int_pay_after_laastpay_vat)
                    ersalcost = 0
                elif int(max_price) > 0 and  int(send_count) > 0 and int(totalsumsell) < int(max_price) or int(totalcount) <= int(send_count):
                    max_price_with_vat_cost = int(totalsumsell) + int(send_price) + int(int_pay_after_laastpay_vat)
                    ersalcost = send_price

        Newtotalcost = 0
        NewTotalOff = 0
        if sinfo:
            Newtotalcost = sellbascket.objects.get(id=sinfo['id']).pcount * priceoff 
            NewTotalOff = sellbascket.objects.get(id=sinfo['id']).pcount * sumBascketPriceoff
        totalsum = 0
        totalsumsell = []
        totalcount = 0
        pct = sellbascket.objects.filter(Create_Uid=request.user.id, status=0)
        for t in pct:
            total = t.pcount * t.pprise
            totalsum += total
            totalcount += t.pcount
            totalsumsell = totalsum
        return render(request, self.template_name, {'max_price': max_price,'max_min_price_info_groupproducts': max_min_price_info_groupproducts,
                                                    'pay_after_laastpay_free': pay_after_laastpay_free,
                                                    'send_price': send_price, 'ersalcost': ersalcost,
                                                    'pay_after_laastpay': pay_after_laastpay,
                                                    'sellbascketCount': sellbascketCount,
                                                    'sumoff': priceoff,  'totalcount': int(totalcount),
                                                    'groupproducts': groupproducts, 
                                                    'check_zero_procuts_count': check_zero_procuts_count,
                                                    'user_info': user_info, 'fhlogo': fhlogo, 'sb': sb, 
                                                    'fehrests': fehrests,
                                                    'psb': psb, 'send_count': int(send_count),
                                                    'sumBascketPriceoff': sumBascketPriceoff,
                                                    'SellBascket': SellBascket_list_with_price,
                                                    'spg': spg, 'spgt': spgt, 'spgtr': spgtr,
                                                    'spgtr2': spgtr2,
                                                    'discount_on_finalcheckout_price': discount_on_finalcheckout_price,
                                                    'int_pay_after_laastpay_vat': int_pay_after_laastpay_vat,
                                                    'max_price_with_vat_cost': max_price_with_vat_cost,
                                                    'max_price_with_vat': max_price_with_vat,
                                                    'totalsumsell': totalsumsell, 'off': off,
                                                    'orginalprice': orginalprice,
                                                    'products_c_s': products_c_s,
                                                    'NewTotalOff': NewTotalOff,
                                                    'Newtotalcost': Newtotalcost})


class userorders(LoginRequiredMixin, View):
    models = finalcheckout

    def get(self, request):
        userid = request.user.id
        userorders = finalcheckout.objects.filter(status=1).filter(
            Create_Uid=userid).filter(Create_Uid=userid)
        return render(request, 'userorders.html', {'userorders': userorders})


def productstadil(request, tadil, tadil_value, rowid):
    Create_Uid = request.user.id
    Update_Uid = request.user.id
    if tadil == 0:
        sumprice = int(tadil_value) + int(products.objects.get(id=rowid).priceorg)
        products.objects.filter(id=rowid).update(priceorg=sumprice)
        
    if tadil == 1:
        sumprice = int(tadil_value) - int(products.objects.get(id=rowid).priceorg)
        products.objects.filter(id=rowid).update(priceorg=sumprice)
        
    if tadil == 2:
        sumprice = int(products.objects.get(id=rowid).priceorg) + (int(products.objects.get(id=rowid).priceorg)*int(tadil_value)/100)
        products.objects.filter(id=rowid).update(priceorg=sumprice)
        
    if tadil == 3:
        sumprice = int(products.objects.get(id=rowid).priceorg) - (int(products.objects.get(id=rowid).priceorg)*int(tadil_value)/100)
        products.objects.filter(id=rowid).update(priceorg=sumprice)
        
    if tadil == 4:
        newcount = int(tadil_value) + int(products.objects.get(id=rowid).numberofgoods)
        products.objects.filter(id=rowid).update(numberofgoods=newcount, goods='True')
    if tadil == 5:
        newcount = int(products.objects.get(id=rowid).numberofgoods) - int(tadil_value)
        products.objects.filter(id=rowid).update(numberofgoods=newcount)
    if tadil == 6:
        products.objects.filter(id=rowid).update(specialcell = 'True')
    if tadil == 7:
        products.objects.filter(id=rowid).update(goods='False')
    if tadil == 8:
        products.objects.filter(id=rowid).update(goods='True')
    if tadil == 9:
        products.objects.filter(id=rowid).update(numberofgoods=0, goods='False', specialcell = 'False')
    data = {'Changed': 'OK'}
    return JsonResponse(data)


def updatesendstatus(request, sendstatus, sendtype, postcode, rowid):
    finalcheckout.objects.filter(TrackingCode=rowid).update(sendstatus=sendstatus, sendtype=sendtype, postcode=postcode)
    data = {'Changed': 'OK'}
    return JsonResponse(data)


class selectsendtypeforusers(LoginRequiredMixin ,View):
    def get(self, request, sendtype, senddate):
        dtime = datetime.date(datetime.now())
        old_id = usersendtype.objects.filter(Create_Uid=request.user.id).order_by('-id')[:1]
        if old_id:
            usersendtype.objects.filter(id=old_id).update(sendtype=sendtype, senddate=senddate, Update_Date=str(dtime))
        else:
            usersendtype.objects.create(sendtype=sendtype, senddate=senddate, Create_Uid=request.user.id, Update_Uid=request.user.id, Create_Date=dtime, Update_Date=dtime)
        html = 'کاربر گرامی تاریخ و روش ارسال با موفقیت در سیستم ثبت گردید .'
        data = {
            'Changed': 'OK',
            'html': html
            }
        return JsonResponse(data)


class userordersjson(BaseDatatableView):
    model = finalcheckout
    columns = ['',  'TrackingCode', 'Create_Date', 'first_name',
               'totalprise', 'cellphone', 'email', 'last_name']
    order_columns = ['',  'TrackingCode', 'Create_Date',
                     'first_name', 'totalprise', 'cellphone', 'email', 'last_name']

    def render_column(self, row, column):
        return super(userordersjson, self).render_column(row, column)

    def filter_queryset(self, qs):
        search = self.request.GET.get('search[value]', None)
        qs = qs.filter(Create_Uid=self.request.user.id, status=1)
        if search:
            qs = qs.filter(Q(TrackingCode__icontains=search) | Q(Create_Date__icontains=search) | Q(first_name__icontains=search) | Q(
                totalprise__icontains=search) | Q(cellphone__icontains=search) | Q(email__icontains=search) | Q(last_name__icontains=search))
        return qs


class usermasterordersjson(BaseDatatableView):
    model = finalcheckout
    columns = ['',  'TrackingCode', 'BankTrackingCode', 'senddate',
                'status', 'sendstatus', 'sendtype', 'postcode','Create_Date', 'first_name',
                'totalprise', 'cellphone', 'email', 'last_name']
    order_columns = ['',  'TrackingCode', 'BankTrackingCode', 'senddate',
                'status', 'sendstatus', 'sendtype', 'postcode','Create_Date', 'first_name',
                'totalprise', 'cellphone', 'email', 'last_name']

    def render_column(self, row, column):
        return super(usermasterordersjson, self).render_column(row, column)

    def filter_queryset(self, qs):
        search = self.request.GET.get('search[value]', None)
        qs = qs.filter(Create_Uid=self.request.user.id, status=1, sendstatus=0)
        if search:
            qs = qs.filter(Q(BankTrackingCode__icontains=search) |  Q(totalprise__icontains=search) | Q(last_name__icontains=search)
                | Q(sendstatus__icontains=search)| Q(postcode__icontains=search)| Q(sendtype__icontains=search))
            
        return qs

class usermasterorderssentjson(BaseDatatableView):
    model = finalcheckout
    columns = ['',  'TrackingCode', 'BankTrackingCode', 'senddate',
                'status', 'sendstatus', 'sendtype', 'postcode','Create_Date', 'first_name',
                'totalprise', 'cellphone', 'email', 'last_name']
    order_columns = ['',  'TrackingCode', 'BankTrackingCode', 'senddate',
                'status', 'sendstatus', 'sendtype', 'postcode','Create_Date', 'first_name',
                'totalprise', 'cellphone', 'email', 'last_name']

    def render_column(self, row, column):
        return super(usermasterorderssentjson, self).render_column(row, column)

    def filter_queryset(self, qs):
        search = self.request.GET.get('search[value]', None)
        qs = qs.filter(Create_Uid=self.request.user.id, status=1, sendstatus=1)
        if search:
            qs = qs.filter(Q(BankTrackingCode__icontains=search) |  Q(totalprise__icontains=search) | Q(last_name__icontains=search)
                | Q(sendstatus__icontains=search)| Q(postcode__icontains=search)| Q(sendtype__icontains=search))
            
        return qs 

class usermasterorderscanceljson(BaseDatatableView):
    model = finalcheckout
    columns = ['',  'TrackingCode', 'BankTrackingCode', 'senddate',
                'status', 'sendstatus', 'sendtype', 'postcode','Create_Date', 'first_name',
                'totalprise', 'cellphone', 'email', 'last_name']
    order_columns = ['',  'TrackingCode', 'BankTrackingCode', 'senddate',
                'status', 'sendstatus', 'sendtype', 'postcode','Create_Date', 'first_name',
                'totalprise', 'cellphone', 'email', 'last_name']

    def render_column(self, row, column):
        return super(usermasterorderscanceljson, self).render_column(row, column)

    def filter_queryset(self, qs):
        search = self.request.GET.get('search[value]', None)
        qs = qs.filter(Create_Uid=self.request.user.id, status=2)
        if search:
            qs = qs.filter(Q(BankTrackingCode__icontains=search) |  Q(totalprise__icontains=search) | Q(last_name__icontains=search)
                | Q(sendstatus__icontains=search)| Q(postcode__icontains=search)| Q(sendtype__icontains=search))
            
        return qs 


class userorderscanceled(LoginRequiredMixin, View):
    model = finalcheckout

    def get(self, request):
        userid = request.user.id
        userorderscanceled = finalcheckout.objects.filter(
            status=2).filter(Create_Uid=userid)
        return render(request, 'userorderscanceled.html', {'userorderscanceled': userorderscanceled})


class userorderscanceledjson(BaseDatatableView):
    model = finalcheckout
    columns = ['',  'TrackingCode', 'Create_Date', 'first_name',
               'totalprise', 'cellphone', 'email', 'last_name']
    order_columns = ['',  'TrackingCode', 'Create_Date',
                     'first_name', 'totalprise', 'cellphone', 'email', 'last_name']

    def render_column(self, row, column):
        return super(userorderscanceledjson, self).render_column(row, column)

    def filter_queryset(self, qs):
        search = self.request.GET.get('search[value]', None)
        qs = qs.filter(Create_Uid=self.request.user.id, status=2)
        if search:
            qs = qs.filter(Q(TrackingCode__icontains=search) | Q(Create_Date__icontains=search) | Q(first_name__icontains=search) | Q(
                totalprise__icontains=search) | Q(cellphone__icontains=search) | Q(email__icontains=search) | Q(last_name__icontains=search))
        return qs




class userordersdetails(LoginRequiredMixin, View):
    model = sellbascket
    def get(self, request, TrackingCode):
        customer_info = ''
        final_info = ''
        order = sellbascket.objects.filter(TrackingCode=TrackingCode, Create_Uid=request.user.id, status = 1)
        send_price_control = DiscountFinal.objects.all().first()
        cs_info = []
        for cs in order:
            if cs.colorid_bycolor != 0:
                color_name = productscolors.objects.filter(id=cs.colorid_bycolor).values_list('color', flat=True)
                size_name = productssize.objects.filter(id=cs.sizeid_bycolor).values_list('size', flat=True)
                color_id = productscolors.objects.filter(id=cs.colorid_bycolor).values_list('id', flat=True)
                size_id = productssize.objects.filter(id=cs.sizeid_bycolor).values_list('id', flat=True)
                product_serial = products.objects.get(id=cs.pid_id).serial
                article_sum = (cs.orginalprice - cs.pdiscount) * cs.pcount
                cs_info.append((cs.pid_id, color_name[0], size_name[0], product_serial, article_sum, color_id[0], size_id[0]))
            else:
                color_name = productscolors.objects.filter(id=cs.colorid_bysize).values_list('color', flat=True)
                size_name = productssize.objects.filter(id=cs.sizeid_bysize).values_list('size', flat=True)
                color_id = productscolors.objects.filter(id=cs.colorid_bysize).values_list('id', flat=True)
                size_id = productssize.objects.filter(id=cs.sizeid_bysize).values_list('id', flat=True)
                product_serial = products.objects.get(id=cs.pid_id).serial
                article_sum = (cs.orginalprice - cs.pdiscount) * cs.pcount
                cs_info.append((cs.pid_id, color_name[0], size_name[0], product_serial, article_sum, color_id[0], size_id[0]))
        
            customer_info = User.objects.filter(id=cs.Create_Uid)
            final_info = finalcheckout.objects.filter(TrackingCode=TrackingCode, Create_Uid=request.user.id, status = 1)

        price_off_sum = 0
        price_sum_cost = 0
        price_sum = 0
        p_s_total = 0
        for p_s in cs_info:
            p_s_total += int(p_s[4])
            price_sum = p_s_total

        if send_price_control:
            if price_sum > int(send_price_control.DmaxPriceToSend):
                price_sum_cost = price_sum
                price_off_sum = {'sum': 0}
            else:
                price_sum_cost = int(price_sum) + int(send_price_control.ErsalPrice)
                price_off_sum = sellbascket.objects.filter(TrackingCode=TrackingCode, Create_Uid=request.user.id, status = 1).aggregate(sum=Sum('pdiscount'))
        else:
            if price_sum > 0:
                price_sum_cost = price_sum
                price_off_sum = {'sum': 0}
            else:
                price_sum_cost = int(price_sum) + 0
                price_off_sum = sellbascket.objects.filter(TrackingCode=TrackingCode, Create_Uid=request.user.id, status = 1).aggregate(sum=Sum('pdiscount'))
        
        fhlogo = firstpagelogo.objects.all().order_by('-id')[:1]

        return render(request, 'userordersdetails.html', {'order': order,
        'cs_info': cs_info, 'customer_info': customer_info, 'final_info': final_info, 'price_sum': price_sum
        ,'price_off_sum': price_off_sum['sum'], 'fhlogo': fhlogo, 'price_sum_cost': price_sum_cost})

        
        
            
class adminorders(LoginRequiredMixin, View):
    models = finalcheckout

    def get(self, request):
        userorders = finalcheckout.objects.filter(status=1, sendstatus=0)
        finalcheckout_status = finalcheckout.objects.filter(status=1, sendstatus=0)
        return render(request, 'adminorders.html', {'id': 0,'userorders': userorders, 'finalcheckout_status': finalcheckout_status})


class adminordersjson(BaseDatatableView):
    model = finalcheckout
    columns = ['',  'TrackingCode', 'Create_Date', 'first_name',
               'totalprise', 'cellphone', 'email', 'last_name', 'status',
                'sendstatus', 'postcode', 'sendtype', 'BankTrackingCode', 'bank_card_no']
    order_columns = ['',  'TrackingCode', 'Create_Date',
                     'first_name', 'totalprise', 'cellphone', 'email', 'last_name', 'status',
                'sendstatus', 'postcode', 'sendtype', 'BankTrackingCode', 'bank_card_no']

    def render_column(self, row, column):
        return super(adminordersjson, self).render_column(row, column)

    def filter_queryset(self, qs):
        search = self.request.GET.get('search[value]', None)

        qs = qs.filter(status=1, sendstatus=0)
        if search:
            qs = qs.filter(Q(TrackingCode__icontains=search) | Q(Create_Date__icontains=search) |
                Q(first_name__icontains=search) | Q(totalprise__icontains=search) |
                Q(cellphone__icontains=search) | Q(email__icontains=search) | Q(last_name__icontains=search)
                | Q(sendstatus__icontains=search) | Q(postcode__icontains=search) |
                 Q(sendtype__icontains=search) | Q(BankTrackingCode__icontains=search) | 
                 Q(bank_card_no__icontains=search))


        return qs



class adminsentorders(LoginRequiredMixin, View):
    models = finalcheckout

    def get(self, request):
        userorders = finalcheckout.objects.filter(status=1, sendstatus=1)
        finalcheckout_status = finalcheckout.objects.filter(status=1, sendstatus=1)
        return render(request, 'adminsentorders.html', {'id': 0,'userorders': userorders, 'finalcheckout_status': finalcheckout_status})


class adminsentordersjson(BaseDatatableView):
    model = finalcheckout
    columns = ['',  'TrackingCode', 'Create_Date', 'first_name',
               'totalprise', 'cellphone', 'email', 'last_name', 'status',
                'sendstatus', 'postcode', 'sendtype', 'BankTrackingCode', 'bank_card_no']
    order_columns = ['',  'TrackingCode', 'Create_Date',
                     'first_name', 'totalprise', 'cellphone', 'email', 'last_name', 'status',
                'sendstatus', 'postcode', 'sendtype', 'BankTrackingCode', 'bank_card_no']

    def render_column(self, row, column):
        return super(adminsentordersjson, self).render_column(row, column)

    def filter_queryset(self, qs):
        search = self.request.GET.get('search[value]', None)

        qs = qs.filter(status=1, sendstatus=1)
        if search:
            qs = qs.filter(Q(TrackingCode__icontains=search) | Q(Create_Date__icontains=search) |
                Q(first_name__icontains=search) | Q(totalprise__icontains=search) |
                Q(cellphone__icontains=search) | Q(email__icontains=search) | Q(last_name__icontains=search)
                | Q(sendstatus__icontains=search) | Q(postcode__icontains=search) |
                 Q(sendtype__icontains=search) | Q(BankTrackingCode__icontains=search) | 
                 Q(bank_card_no__icontains=search))


        return qs


class adminorderscanceled(LoginRequiredMixin, View):
    model = finalcheckout

    def get(self, request):
        userorderscanceled = finalcheckout.objects.filter(status=2)
        return render(request, 'adminorderscanceled.html', {'id': 0,'userorderscanceled': userorderscanceled})


class adminorderscanceledjson(BaseDatatableView):
    model = finalcheckout
    columns = ['',  'TrackingCode', 'Create_Date', 'first_name',
               'totalprise', 'cellphone', 'email', 'last_name']
    order_columns = ['',  'TrackingCode', 'Create_Date', 'first_name',
               'totalprise', 'cellphone', 'email', 'last_name']

    def render_column(self, row, column):
        return super(adminorderscanceledjson, self).render_column(row, column)

    def filter_queryset(self, qs):
        search = self.request.GET.get('search[value]', None)
        id = self.kwargs.get('id')
        qs = qs.filter(status=2)
        if search:
            qs = qs.filter(Q(TrackingCode__contains=search) | Q(Create_Date=search) | Q(first_name__contains=search) | Q(totalprise=search) | Q(cellphone=search) | Q(email__icontains=search) | Q(last_name__contains=search))

        return qs


class adminordersdetails(LoginRequiredMixin, View):
    model = sellbascket

    def get(self, request, TrackingCode):
        userinfo = sellbascket.objects.filter(TrackingCode=TrackingCode).values_list('Create_Uid',flat=True)
        customer_info = User.objects.filter(id=userinfo[0])
        final_info = finalcheckout.objects.filter(TrackingCode=TrackingCode)
        order = sellbascket.objects.filter(TrackingCode=TrackingCode)
        send_price_control = DiscountFinal.objects.first()
        print('1')
        cs_info = []
        for cs in order:
            if cs.colorid_bycolor != 0:
                color_name = productscolors.objects.filter(id=cs.colorid_bycolor).values_list('color', flat=True)
                size_name = productssize.objects.filter(id=cs.sizeid_bycolor).values_list('size', flat=True)
                color_id = productscolors.objects.filter(id=cs.colorid_bycolor).values_list('id', flat=True)
                size_id = productssize.objects.filter(id=cs.sizeid_bycolor).values_list('id', flat=True)
                product_serial = products.objects.get(id=cs.pid_id).serial
                article_sum = (cs.pprise - cs.pdiscount) * cs.pcount
                cs_info.append((cs.pid_id, color_name[0], size_name[0], product_serial, article_sum, color_id[0], size_id[0]))
            else:
                color_name = productscolors.objects.filter(id=cs.colorid_bysize).values_list('color', flat=True)
                size_name = productssize.objects.filter(id=cs.sizeid_bysize).values_list('size', flat=True)
                color_id = productscolors.objects.filter(id=cs.colorid_bysize).values_list('id', flat=True)
                size_id = productssize.objects.filter(id=cs.sizeid_bysize).values_list('id', flat=True)
                product_serial = products.objects.get(id=cs.pid_id).serial
                article_sum = (cs.pprise - cs.pdiscount) * cs.pcount
                cs_info.append((cs.pid_id, color_name[0], size_name[0], product_serial, article_sum, color_id[0], size_id[0]))
        
            customer_info = User.objects.filter(id=cs.Create_Uid)
            final_info = finalcheckout.objects.filter(TrackingCode=TrackingCode)
        print('2')
        price_off_sum = 0
        price_sum_cost = 0
        price_sum = 0
        p_s_total = 0
        for p_s in cs_info:
            p_s_total += int(p_s[4])
            price_sum = p_s_total
        print('3')
        if send_price_control:
            if price_sum > int(send_price_control.DmaxPriceToSend):
                price_sum_cost = price_sum
                price_off_sum = {'sum': 0}
            else:
                price_sum_cost = int(price_sum) + int(send_price_control.ErsalPrice)
                price_off_sum = sellbascket.objects.filter(TrackingCode=TrackingCode).aggregate(sum=Sum('pdiscount'))
        else:
            if price_sum > 0:
                price_sum_cost = price_sum
                price_off_sum = {'sum': 0}
            else:
                price_sum_cost = int(price_sum)
                price_off_sum = sellbascket.objects.filter(TrackingCode=TrackingCode).aggregate(sum=Sum('pdiscount'))

        print('4')
        fhlogo = firstpagelogo.objects.all().order_by('-id')[:1]
        send_price_factor = int(send_price_control.ErsalPrice)
        send_max_price = int(send_price_control.DmaxPriceToSend)

        return render(request, 'adminordersdetails.html', {'order': order,
         'cs_info': cs_info, 'customer_info': customer_info, 'final_info': final_info, 'price_sum': price_sum, 'send_max_price': send_max_price
         ,'price_off_sum': price_off_sum['sum'], 'fhlogo': fhlogo, 'price_sum_cost': price_sum_cost, 'send_price_factor': send_price_factor})


def payment_init(request):
    base_url = config('BASE_URL', default='https://rahafashion.ir/', cast=str)
    api_key = config('X-API-KEY', default='2fa4be71-26cd-4d16-81c3-e8bcd27b17fb', cast=str)
    # api_key = config('X-API-KEY', default='aa0de06b-4091-4e84-96df-9140fe97c9a8', cast=str)
    sandbox = config('IDPAY_SANDBOX', default='0', cast=bool)

    return IDPayAPI(api_key, base_url, sandbox)

def home(request):
    payments = Main.objects.all()
    return render(request, 'pay_temp/home.html', {'payments': payments})

def send_request(request):
    price = 0
    discount_on_finalcheckout_price = price_off()
    SellBascket = sellbascket.objects.filter(Create_Uid=request.user.id, status=0)
    SellBascket_list = list(SellBascket.values())
    SellBascket_list_with_price=[]
    for a in SellBascket_list:  
        SellBascket_list_with_price.append(a)
   
    sinfo = 0
    sumBascketPriceoff = 0
    priceoff = 0
    totalsumsell = 0
    getproductid = 0
    colorid_bycolor = 0
    sizeid_bycolor = 0
    colorid_bysize = 0
    sizeid_bysize = 0
    sellinfo = []
    for sinfo in SellBascket_list:
        colorid_bycolor = sellbascket.objects.get(pid_id= sinfo['pid_id'], id = sinfo['id']).colorid_bycolor
        sizeid_bycolor = sellbascket.objects.get(pid_id= sinfo['pid_id'], id = sinfo['id']).sizeid_bycolor
        colorid_bysize = sellbascket.objects.get(pid_id= sinfo['pid_id'], id = sinfo['id']).colorid_bysize
        sizeid_bysize = sellbascket.objects.get(pid_id= sinfo['pid_id'], id = sinfo['id']).sizeid_bysize
        getproductid = sinfo['pid_id']
        sellinfo.append((getproductid,colorid_bycolor,sizeid_bycolor,colorid_bysize,sizeid_bysize))
        priceoff , sumBascketPriceoff , totalsumsell, off, orginalprice, totalcount= makepreiceoff(request ,getproductid ,colorid_bycolor, sizeid_bycolor, colorid_bysize, sizeid_bysize)

    pay_after_laastpay = 0

    pay_after_laastpay = int(totalsumsell) + int(discount_on_finalcheckout_price[2])
    if int(totalsumsell) >= int(discount_on_finalcheckout_price[0]):
        pay_after_laastpay = int(totalsumsell)

    order_id = uuid.uuid1()
    amount = pay_after_laastpay

    payer = {
        'name': request.user.first_name,
        'phone': request.user.cellphone,
        'mail': request.user.email,
        'desc': request.user.last_name,
    }
    numberofgoods = 0
    sellbascketcountsells =0

    in_payproducts = sellbascket.objects.filter(pid_id=getproductid,
        status=3, 
        colorid_bycolor=colorid_bycolor,
        sizeid_bycolor=sizeid_bycolor,
        colorid_bysize=colorid_bysize,
        sizeid_bysize=sizeid_bysize).values_list('pcount', flat=True)

    in_pay = 0
    if len(in_payproducts) > 0:
        in_pay = in_payproducts

    sellb_info = []
    sellbascket_check = sellbascket.objects.filter(pid_id=getproductid, status=0, colorid_bycolor=colorid_bycolor, sizeid_bycolor=sizeid_bycolor, colorid_bysize=colorid_bysize, sizeid_bysize=sizeid_bysize)
    for a in sellbascket_check:
        sellbascketcountsells += a.pcount
        sellb_info.append(a.id)

    if colorid_bycolor != 0:
        remain = productsparamerts.objects.filter(
            pid_id=getproductid,cid_id=colorid_bycolor, sid_id=sizeid_bycolor).values_list(
                'productinventory_remain', flat=True)
        if len(remain) == 0:
            remain = ['0']
        numberofgoods = int(remain[0])- int(in_pay)
    else:
        remain = productsparamerts.objects.filter(
            pid_id=getproductid,cid_id=colorid_bysize, sid_id=sizeid_bysize).values_list(
                'productinventory_remain', flat=True)
        if len(remain) == 0:
            remain = ['0']
        numberofgoods = int(remain[0])- int(in_pay)

    if numberofgoods <= 0:

        return redirect('WebSite:salebacket')
    else:
        sellb_info = []
        sellb_check = sellbascket.objects.filter(Create_Uid=request.user.id, pid_id=getproductid, status=0, colorid_bycolor=colorid_bycolor, sizeid_bycolor=sizeid_bycolor, colorid_bysize=colorid_bysize, sizeid_bysize=sizeid_bysize)
        for a in sellb_check:
            sellb_info.append(a.id)

        record = Main(order_id=order_id, amount=int(amount), sellbid=sellb_info[0])
        record.save()

        for si in sellinfo:
            sellbascket.objects.filter(pid_id=si[0],
                status=0, 
                colorid_bycolor=si[1],
                sizeid_bycolor=si[2],
                colorid_bysize=si[3],
                sizeid_bysize=si[4]).update(
                    status=3 , order_id=order_id, Create_Uid=request.user.id)

        idpay_payment = payment_init(request)

        result = idpay_payment.payment(str(order_id), amount, "payment/return", payer)

        if 'id' in result:
        
            record.status = 1
            record.payment_id = result['id']
            record.save()

            return redirect(result['link'])

        else:
            txt = result['message']


    return render(request, 'pay_temp/error.html', {'txt': txt, 'amount': amount})



@csrf_exempt
def payment_return(request):
    pid = request.GET.get('id')
    status = request.GET.get('status')
    pidtrack = request.GET.get('track_id')
    order_id_ = request.GET.get('order_id')
    amount = request.GET.get('amount')
    card = "****"
    date = datetime.date(datetime.now())
    print('1')
    if Main.objects.filter(order_id=order_id_, payment_id=pid, status=1).count() == 1:
        print('2')
        idpay_payment = payment_init(request)
        Main.objects.filter(order_id=order_id_, payment_id=pid).update(
            status = status,
            date = str(date),
            card_number = card,
            idpay_track_id = pidtrack
        )
        print('3')
        if str(status) == '10':
            print('4')
            payment = Main.objects.get(order_id=order_id_, payment_id=pid)
            result = idpay_payment.verify(pid, payment.order_id)
            if 'status' in result:
                print('5')
                payment.status = result['status']
                payment.bank_track_id = result['payment']['track_id']
                payment.save()
                print('6')
                subject = 'یک سفارش جدید از وب سایت'
                message = ' یک سفارش جدید با شماره :', result['payment']['track_id'], 'در وبسایت توسط مشتری : ', request.user.username, ' شده است.'
                from_email = '_mainaccount@rahafashion.ir'
                if subject and message and from_email:
                    try:
                        toemail = User.objects.get(username='admin').email
                        send_mail(subject, message, from_email, [str(toemail)])
                    except Exception as error:
                        print('email error')
                        print(error)
                        
                print('7')
                sellbascket.objects.filter(Create_Uid=request.user.id, status=3).update(status=1, TrackingCode=result['track_id'], pprise=result['amount'])
                finalcheckout.objects.create(totalprise=result['amount'], bank_card_no=result['payment']['card_no'],BankTrackingCode=result['payment']['track_id'], TrackingCode=result['track_id'], first_name=request.user.first_name,
                                            last_name=request.user.last_name, cellphone=request.user.cellphone, email=request.user.email, Create_Uid=request.user.id, status=1)
                print('8')                            
                user_order_info = sellbascket.objects.filter(status =1, TrackingCode=result['track_id'])
                for uoi in user_order_info:
                    s_count = uoi.pcount
                    if int(uoi.colorid_bycolor) != 0:
                        print('9')
                        p_color_info = productsparamerts.objects.filter(pid_id=uoi.pid, cid_id=uoi.colorid_bycolor, sid_id=uoi.sizeid_bycolor)
                        for pci in p_color_info:
                            soldcount = int(pci.productinventory_sold) + int(s_count)
                            remaincount = (int(pci.productinventory) + int(pci.productinventory_recharge)) - int(soldcount)
                            productsparamerts.objects.filter(id=pci.id).update(productinventory_sold=soldcount, productinventory_remain=remaincount)
                            productsparaminvcharge.objects.create(
                            invpid_id = int(pci.pid_id),
                            invcid_id = int(pci.cid_id),
                            invsid_id = int(pci.sid_id),
                            productinventory = int(pci.productinventory),
                            productinventory_recharge = int(pci.productinventory_recharge),
                            productinventory_sold = int(s_count),
                            productinventory_remain = remaincount,
                            pdesc = 'فروش کالا',
                            Create_Uid = request.user.id,
                            Update_Uid = request.user.id
                            )
                    if int(uoi.colorid_bycolor) == 0:
                        print('10')
                        p_size_info = productsparamerts.objects.filter(pid_id=uoi.pid, cid_id=uoi.colorid_bysize, sid_id=uoi.sizeid_bysize)
                        for psi in p_size_info:
                            soldcount = int(psi.productinventory_sold) + int(s_count)
                            remaincount = (int(psi.productinventory) + int(psi.productinventory_recharge)) - int(soldcount)
                            productsparamerts.objects.filter(id=psi.id).update(productinventory_sold=soldcount, productinventory_remain=remaincount)
                            productsparaminvcharge.objects.create(
                            invpid_id = int(psi.pid_id),
                            invcid_id = int(psi.cid_id),
                            invsid_id = int(psi.sid_id),
                            productinventory = int(psi.productinventory),
                            productinventory_recharge = int(psi.productinventory_recharge),
                            productinventory_sold = int(s_count),
                            productinventory_remain = remaincount,
                            pdesc = 'فروش کالا',
                            Create_Uid = request.user.id,
                            Update_Uid = request.user.id
                            )
                print('11')
                seleted_send_user_type = usersendtype.objects.all().filter(Create_Uid=request.user.id).values_list('sendtype', 'senddate', 'Create_Uid').order_by('-id')[:1]
                if len(seleted_send_user_type) > 0:
                    print('12')
                    sendtype = seleted_send_user_type[0][0]
                    senddate = seleted_send_user_type[0][1]
                    findelatestusersell = finalcheckout.objects.filter(Create_Uid=seleted_send_user_type[0][2]).values_list('TrackingCode').order_by('-id')[:1]
                    finalcheckout.objects.filter(TrackingCode=findelatestusersell[0][0]).update(sendtype = sendtype, senddate=senddate)
                print('13')
                trackcode = result['payment']['track_id']
                return render(request, 'partials/successpay.html', {'trackcode': trackcode })
                # return redirect('WebSite:salebacket')
                print('14')
            else:
                txt = result['message']
        else:
            print('15')
            txt = "Error Code : " + str(status) + "   |   " + "Description : " + idpay_payment.get_status(status)
            user_order_info_status_3 = sellbascket.objects.filter(Create_Uid=request.user.id, status=3)
            for u_o_i_s3 in user_order_info_status_3:
                if u_o_i_s3.id > 0:
                    print('16')
                    sellbascket.objects.filter(Create_Uid=request.user.id, status=3).update(status=0)
                        
    else:
        print('17')
        txt = "Order Not Found"
        user_order_info_status3 = sellbascket.objects.filter(Create_Uid=request.user.id, status=3)
        if len(user_order_info_status3) > 0:
            for u_o_i_s3 in user_order_info_status3:
                sellbascket.objects.filter(Create_Uid=request.user.id, status=3).update(status=0)
    print('18')
    return render(request, 'pay_temp/error.html', {'txt': txt})
    # return redirect('WebSite:salebacket')
    


def payment_check(request, pk):

    payment = Main.objects.get(pk=pk)

    idpay_payment = payment_init()
    result = idpay_payment.inquiry(payment.payment_id, payment.order_id)

    if 'status' in result:

        payment.status = result['status']
        payment.idpay_track_id = result['track_id']
        payment.bank_track_id = result['payment']['track_id']
        payment.card_number = result['payment']['card_no']
        payment.date = str(result['date'])
        payment.save()

    return render(request, 'pay_temp/error.html', {'txt': result['message']})


class wishlist(generic.ListView):
    models = productdetails
    context_object_name = 'wishlist'
    template_name = 'wishlist.html'

    def get(self, request):
        userid = request.user.id
        fehrests = productsgroups.objects.all()
        sb = productdetails.objects.all().filter(Create_Uid=userid)

        products_c_s = []
        psb = products.objects.all().filter(id__gt= 0)
        for ppsb in psb:
            productparam = productsparamerts.objects.filter(pid_id=ppsb.id)
            for pppsb in productparam:
                colorname = productscolors.objects.filter(id=pppsb.cid_id)
                sizename = productssize.objects.filter(id=pppsb.sid_id)
                products_c_s.append((pppsb.pid_id, colorname, sizename, pppsb.productinventory_remain))

        sumBascketPriceoff = 0
        productdetailsDescCount = productdetails.objects.filter(
            Create_Uid=request.user.id, favorite=1).count()
        price = 0

        return render(request, 'wishlist.html', {'sb': sb, 'fehrests': fehrests, 'psb': psb, 'products_c_s': products_c_s})

def bestssale_6_():
    pid = sellbascket.objects.all().values_list('id')
    count = []
    for id in pid[0]:
        id_count = sellbascket.objects.filter(id=id).values_list('pcount').count()
        count.append(id_count)


def price_off():
    # dtime = datetime.date(datetime.now()).togregorian()
    discount_on_finalcheckout_price = DiscountFinal.objects.all().values_list('DmaxPriceToSend', 'DmaxCountToSend', 'ErsalPrice', 'Dmax_Type')
    return discount_on_finalcheckout_price[0]

def headermenu():
    spg = productsgroups.objects.filter(gparentid=0, id__gt = 0).order_by('id')[:9]
    spgid = list(productsgroups.objects.filter(gparentid=0, id__gt = 0).values_list('id', flat=True))
    spgt = productsgroups.objects.all().filter(glevel=2, id__gt = 0)
    spgtr = productsgroups.objects.raw(
         """select *,(select count(*) from productsgroups where gparentid=a.gparentid ) tedad from productsgroups a where gparentid in (select id from productsgroups where gparentid in (select id from productsgroups where gparentid=0)) and a.id in (select id from productsgroups where gparentid=a.gparentid and id <> 0 limit 5)  """)
    spgtr2 = productsgroups.objects.raw("""
        select distinct gparentid as id,(select count(*) from productsgroups where gparentid=a.gparentid ) tedad from productsgroups a where gparentid in (select id from productsgroups where gparentid in (select id from productsgroups where gparentid=0)) and a.id in (select id from productsgroups where gparentid=a.gparentid  limit 5) """)  
    
    return spg, spgid, spgt, spgtr ,spgtr2

# Login
def loginuser(request):        
    spg, spgid, spgt, spgtr ,spgtr2 = headermenu()
    fcontact = centercontactus.objects.all()
    bankreport = parametsaccounts.objects.all()
    fehrests = productsgroups.objects.all().filter(id__gt = 0)
    productsdetails = products.objects.all()
    brand = productsbrands.objects.all().filter(id__gt= 0)
    result = products.objects.all()
    
    sliders = slider.objects.all()
    aboutus_info = aboutus.objects.all()
    centercontactus_info = centercontactus.objects.all()

    check_zero_procuts_count = productsparamerts.objects.all()
    Latestproducts = products.objects.filter(id__gt = 0, goods='True').order_by('-id')[:12]
    latestp = []
    for latest_p in Latestproducts:
        la_p = productsparamerts.objects.filter(pid_id=latest_p.id).values_list('pid_id', flat=True).order_by('takhfifprice')
        if len(la_p)>0:
            latestp.append(la_p[0])

    max_p_price = []
    for lstid in Latestproducts:
        param_best = productsparamerts.objects.filter(pid_id= lstid.id).values_list('productprice', 'pid', 'takhfifprice', 'productinventory_remain', 'takhfif').order_by('productprice')
        max_p_price.append(param_best)
    max_min_price_info_Latestproducts = []
    for mpp in max_p_price:
        if len(mpp) > 0:
            remain_sum = productsparamerts.objects.filter(pid_id = mpp[0][1]).aggregate(sum=Sum('productinventory_remain'))['sum']
            max_product_price = max(list(mpp))
            min_product_price = min(list(mpp))
            product_price_select = mpp[0][1]
            product_price_after_takhfif = mpp[0][2]
            product_productinventory_remain = mpp[0][3]
            max_min_price_info_Latestproducts.append((product_price_select,max_product_price[0],min_product_price[0], product_price_after_takhfif, product_productinventory_remain, remain_sum, max_product_price[2], int(max_product_price[4])))

    StarAvarage_percent = []
    for pid in Latestproducts:
        star ,  StarAvarage , Starcount , StarSum , pid= makestars(request, pid.id)
        StarAvarage_percent.append((pid,StarAvarage))


    ng = products.objects.filter(goods=0, id__gt = 0).values_list('id', flat=True)

    newproducts = products.objects.all().order_by('-id')[:12]
    register = User.objects.all()
    banner = firstpagebaners.objects.all()

    SellBascket = sellbascket.objects.filter(Create_Uid=request.user.id, status=0).order_by('-id')
    SellBascket_list = list(SellBascket.values())
    price = 0
    
    SellBascket_list_with_price=[]
    priceoff = 0
    sumBascketPriceoff = 0
    totalsumsell = 0
    off = 0
    orginalprice = 0
    for a in SellBascket_list:
        colorid_bycolor = sellbascket.objects.get(pid_id= a['pid_id'], id = a['id']).colorid_bycolor
        sizeid_bycolor = sellbascket.objects.get(pid_id= a['pid_id'], id = a['id']).sizeid_bycolor
        colorid_bysize = sellbascket.objects.get(pid_id= a['pid_id'], id = a['id']).colorid_bysize
        sizeid_bysize = sellbascket.objects.get(pid_id= a['pid_id'], id = a['id']).sizeid_bysize
        pid = a['pid_id']

        a['priceoff'] , a['sumBascketPriceoff'] , a['totalsumsell'], a['off'], a['orginalprice'], a['totalcount']= makepreiceoff(request ,pid ,colorid_bycolor, sizeid_bycolor, colorid_bysize, sizeid_bysize)

        SellBascket_list_with_price.append(a)


    
    sellbascketCount = sellbascket.objects.filter(Create_Uid=request.user.id, status=0).count()
    productdetailsDesc = productdetails.objects.filter(Create_Uid=request.user.id)
    productgrouppage = productsgroups.objects.all()
    subslidergroup = productsgroups.objects.all().filter(gparentid=0).order_by('id')[:4]
    khabar = lastnews.objects.all().order_by('-id')[:3]
    fhlogo = firstpagelogo.objects.all().order_by('-id')[:1]
    bestssale2 = sellbascket.objects.values('pid').annotate(count=Count('pid')).order_by('count')
    bestssale = sellbascket.objects.raw("""
        select  a.pid_id as id,
        sum(a.pcount) as count ,
        case when 
            b.goods<>False
            then 
            b.numberofgoods-(select SUM(sb.pcount) 
                            from sellbascket sb 
                            where sb.pid_id=a.pid_id and sb.status=1) 
            else 0 
            end as existing ,
        b.img1 as img1,
        b.name as name,
        (SELECT id from productsgroups where id=b.group_id) as gid ,
        (SELECT name from productsgroups where id=b.brand_id) as brand ,
        (SELECT COALESCE(SUM(stars)*100/(COUNT(id)*5),0) FROM stars 
                WHERE pid_id=A.pid_id ) AS StarAvarage,

        b.priceorg as Price
        from sellbascket a 
        join products b on a.pid_id=b.id
        group by a.pid_id ,b.img1,b.name,b.group_id,b.brand_id, b.goods,b.numberofgoods , b.priceorg
        order by sum(a.pcount) desc
        """
    )
    max_p_price = []
    for bsid in bestssale2:
        param_best = productsparamerts.objects.filter(pid_id= bsid['pid']).values_list('productprice', 'pid', 'takhfifprice', 'productinventory_remain', 'takhfif').order_by('productprice')
        max_p_price.append(param_best)
    max_min_price_info_bestsell = []
    for mpp in max_p_price:
        if len(mpp) > 0:
            remain_sum = productsparamerts.objects.filter(pid_id = mpp[0][1]).aggregate(sum=Sum('productinventory_remain'))['sum']
            max_product_price = max(list(mpp))
            min_product_price = min(list(mpp))
            product_price_select = mpp[0][1]
            product_price_after_takhfif = mpp[0][2]
            product_productinventory_remain = mpp[0][3]
            max_min_price_info_bestsell.append((product_price_select,max_product_price[0],min_product_price[0], product_price_after_takhfif, product_productinventory_remain, remain_sum, max_product_price[2], int(max_product_price[4])))

    # favoriteCount


    productdetailsDescCount = productdetails.objects.filter(
        Create_Uid=request.user.id, favorite=1).count()

    
    totalsum = 0
    totalsumsell = []
    totalcount = 0
    pct = sellbascket.objects.filter(Create_Uid=request.user.id, status=0)
    for t in pct:
        total = t.pcount * t.pprise
        totalsum += total
        totalcount += t.pcount
        totalsumsell = totalsum                              
    
    
    products_has_takhfif = productsparamerts.objects.all().filter(takhfifprice__gt=0)
    products_colors_size = []
    for pc in products_has_takhfif:
        all_products_name = products.objects.all().filter(id=pc.pid_id).values_list('name', flat=True)
        all_products_img = products.objects.all().filter(id=pc.pid_id).values_list('img1', flat=True)
        all_products_id = products.objects.all().filter(id=pc.pid_id).values_list('id', flat=True)
        procolor = productscolors.objects.all().filter(id = pc.cid_id).values_list('color', flat=True)
        prosize = productssize.objects.all().filter(id= pc.sid_id).values_list('size', flat=True)
        products_colors_size.append((pc.pid_id,procolor[0],prosize[0], all_products_name[0], all_products_img[0], all_products_id[0]))


    group_id_level1 = productsgroups.objects.filter(glevel=1, id__gt=0).order_by('GroupOrders')
    show_level2_group_id = productsgroups.objects.filter(gparentid__in=group_id_level1, id__gt=0).values_list('id', flat=True)

    show_gl2 = productsgroups.objects.filter(id__in=show_level2_group_id, id__gt=0)

    gr_list = []
    group_list_l1 = productsgroups.objects.filter(glevel=2, id__in=show_level2_group_id , id__gt=0).values('gparentid').annotate(count=Count('gparentid')).order_by()
    for grlist in group_list_l1:
        gr_list.append(grlist['gparentid'])

    show_all_products = []
    g1= productsgroups.objects.filter(glevel=1, id__gt=0).values_list('id', flat=True)
    for grl2 in g1:
        g2 = productsgroups.objects.filter(gparentid=grl2, id__gt=0).values_list('id', flat=True).order_by('GroupOrders')
        allp = products.objects.filter(group_id__in=g2, id__gt=0).values_list('id', 'name', 'img1', 'group_id').order_by('-id')[0:12]
        if len(allp) > 0:
            for all_pro in allp:
                CommentCount = comment.objects.filter(status=1, pid_id=all_pro[0]).count()
                show_all_products.append(all_pro)

    max_p_price = []
    for price_group_level in show_all_products:
        param_best = productsparamerts.objects.filter(pid_id = price_group_level[0]).values_list('productprice', 'pid', 'takhfifprice', 'productinventory_remain', 'takhfif').order_by('productprice')
        if len(param_best) > 0:
            max_p_price.append(param_best)

    max_min_price_info_group_level = []
    for mpp in max_p_price:
        if len(mpp) > 0:
            remain_sum = productsparamerts.objects.filter(pid_id = mpp[0][1]).aggregate(sum=Sum('productinventory_remain'))['sum']
            max_product_price = max(list(mpp))
            min_product_price = min(list(mpp))
            product_price_select = mpp[0][1]
            product_price_after_takhfif = mpp[0][2]
            product_productinventory_remain = mpp[0][3]
            max_min_price_info_group_level.append((product_price_select,max_product_price[0],min_product_price[0], product_price_after_takhfif, product_productinventory_remain, remain_sum, max_product_price[2], int(max_product_price[4])))

    error_list = []
    form = LoginForm(request.POST)
    if form.is_valid() and request.user.is_authenticated == False:
        cd = form.cleaned_data
        if User.objects.filter(username=cd['username']):
            if authenticate(username=cd['username'], password=cd['password']):
                user = authenticate(username=cd['username'], password=cd['password'])
                if user is not None:
                    if user.is_active:
                        login(request, user)
                        request.session.set_expiry(0)
                        return redirect(request.path)
                    error_list.append('کاربر وارد شده غیر فعال می باشد.')
                    
                    return render(request, 'index.html', { 'aboutus_info': aboutus_info,'max_min_price_info_bestsell': max_min_price_info_bestsell,
                                                            'max_min_price_info_Latestproducts': max_min_price_info_Latestproducts,
                                                            'check_zero_procuts_count': check_zero_procuts_count, 'ng': ng,
                                                            'error_list': error_list, 'bankreport': bankreport,
                                                            'products_colors_size': products_colors_size,'CommentCount': CommentCount,
                                                            'products_has_takhfif':products_has_takhfif, 'show_gl2': show_gl2 ,
                                                            'fcontact': fcontact, 'form': form, 'error_list': error_list,
                                                            'fehrests': fehrests, 'productsdetails': productsdetails, 'brand': brand,
                                                            'result': result, 'sliders': sliders, 'newproducts': newproducts,
                                                            'Latestproducts': Latestproducts, 'register': register, 'SellBascket': SellBascket_list_with_price,
                                                            'sellbascketCount': sellbascketCount, 'sumBascketPriceoff': sumBascketPriceoff,
                                                            'productdetailsDesc': productdetailsDesc, 'productdetailsDescCount': productdetailsDescCount,
                                                            'banner': banner, 'bestssale': bestssale,
                                                            'productgrouppage': productgrouppage, 'spg': spg, 'spgt': spgt, 'spgtr': spgtr, 'spgtr2': spgtr2,
                                                            'fhlogo': fhlogo, 'subslidergroup': subslidergroup, 'khabar': khabar, 'centercontactus_info': centercontactus_info,
                                                            'StarAvarage_percent': StarAvarage_percent, 'totalsumsell': totalsumsell,
                                                            'group_id_level1': group_id_level1,'max_min_price_info_group_level': max_min_price_info_group_level,
                                                             'show_level2_group_id': show_level2_group_id,
                                                             'gr_list': gr_list, 'show_all_products': show_all_products})
            error_list.append(' کلمه عبور وارد شده اشتباه می باشد.')
            return render(request, 'index.html', { 'aboutus_info': aboutus_info,'max_min_price_info_bestsell': max_min_price_info_bestsell,
                                                    'max_min_price_info_Latestproducts': max_min_price_info_Latestproducts,
                                                    'products_colors_size': products_colors_size,'gr_list': gr_list,'max_min_price_info_group_level': max_min_price_info_group_level,
                                                    'products_has_takhfif':products_has_takhfif, 'show_gl2': show_gl2 ,
                                                    'check_zero_procuts_count': check_zero_procuts_count, 'ng': ng, 'error_list': error_list, 
                                                    'bankreport': bankreport, 'fcontact': fcontact, 'form': form, 'error_list': error_list,
                                                    'fehrests': fehrests, 'productsdetails': productsdetails, 'brand': brand,
                                                    'result': result, 'sliders': sliders, 'newproducts': newproducts,
                                                    'Latestproducts': Latestproducts, 'register': register, 'SellBascket': SellBascket_list_with_price,
                                                    'sellbascketCount': sellbascketCount, 'sumBascketPriceoff': sumBascketPriceoff,
                                                    'productdetailsDesc': productdetailsDesc, 'productdetailsDescCount': productdetailsDescCount,
                                                    'banner': banner, 'bestssale': bestssale,'CommentCount': CommentCount,
                                                    'productgrouppage': productgrouppage, 'spg': spg, 'spgt': spgt, 'spgtr': spgtr, 'spgtr2': spgtr2,
                                                    'fhlogo': fhlogo, 'subslidergroup': subslidergroup, 'khabar': khabar, 'centercontactus_info': centercontactus_info,
                                                    'StarAvarage_percent': StarAvarage_percent, 'totalsumsell': totalsumsell,
                                                    'group_id_level1': group_id_level1, 'show_level2_group_id': show_level2_group_id
                                                    , 'show_all_products': show_all_products})
        error_list.append(' نام کاربری وارد شده اشتباه می باشد.')
        return render(request, 'index.html', { 'aboutus_info': aboutus_info,'max_min_price_info_bestsell': max_min_price_info_bestsell,
                                                'max_min_price_info_Latestproducts': max_min_price_info_Latestproducts,
                                                'products_colors_size': products_colors_size,'gr_list': gr_list,'max_min_price_info_group_level': max_min_price_info_group_level,
                                                'products_has_takhfif':products_has_takhfif, 'show_gl2': show_gl2 ,
                                                'check_zero_procuts_count': check_zero_procuts_count, 'ng': ng, 'error_list': error_list,
                                                'bankreport': bankreport, 'fcontact': fcontact, 'form': form, 'error_list': error_list,
                                                'fehrests': fehrests, 'productsdetails': productsdetails, 'brand': brand,
                                                'result': result, 'sliders': sliders, 'newproducts': newproducts,
                                                'Latestproducts': Latestproducts, 'register': register, 'SellBascket': SellBascket_list_with_price,
                                                'sellbascketCount': sellbascketCount, 'sumBascketPriceoff': sumBascketPriceoff,
                                                'productdetailsDesc': productdetailsDesc, 'productdetailsDescCount': productdetailsDescCount,
                                                'banner': banner, 'bestssale': bestssale,'CommentCount': CommentCount,
                                                'productgrouppage': productgrouppage, 'spg': spg, 'spgt': spgt, 'spgtr': spgtr, 'spgtr2': spgtr2,
                                                'fhlogo': fhlogo, 'subslidergroup': subslidergroup, 'khabar': khabar, 'centercontactus_info': centercontactus_info,
                                                'StarAvarage_percent': StarAvarage_percent, 'totalsumsell': totalsumsell,
                                                'group_id_level1': group_id_level1,  'show_level2_group_id': show_level2_group_id
                                                , 'show_all_products': show_all_products})

    return render(request, 'index.html', { 'aboutus_info': aboutus_info,'max_min_price_info_bestsell': max_min_price_info_bestsell,
                                            'max_min_price_info_Latestproducts': max_min_price_info_Latestproducts,
                                            'check_zero_procuts_count': check_zero_procuts_count, 'ng': ng,
                                            'bankreport': bankreport, 'fcontact': fcontact,'gr_list': gr_list,
                                            'form': form, 'error_list': error_list, 'show_gl2': show_gl2 ,
                                            'products_colors_size': products_colors_size,'max_min_price_info_group_level': max_min_price_info_group_level,
                                            'products_has_takhfif':products_has_takhfif,
                                            'fehrests': fehrests, 'productsdetails': productsdetails, 'brand': brand,
                                            'result': result, 'sliders': sliders, 'newproducts': newproducts,
                                            'Latestproducts': Latestproducts, 'register': register, 'SellBascket': SellBascket_list_with_price,
                                            'sellbascketCount': sellbascketCount, 'sumBascketPriceoff': sumBascketPriceoff,
                                            'productdetailsDesc': productdetailsDesc, 'productdetailsDescCount': productdetailsDescCount,
                                            'banner': banner, 'bestssale': bestssale,'CommentCount': CommentCount,
                                            'productgrouppage': productgrouppage, 'spg': spg, 'spgt': spgt, 'spgtr': spgtr, 'spgtr2': spgtr2,
                                            'fhlogo': fhlogo, 'subslidergroup': subslidergroup, 'khabar': khabar, 'centercontactus_info': centercontactus_info 
                                            ,'StarAvarage_percent': StarAvarage_percent, 'totalsumsell': totalsumsell,
                                            'group_id_level1': group_id_level1, 'show_level2_group_id': show_level2_group_id
                                            , 'show_all_products': show_all_products})




class firstpageheaderlogo(generic.ListView):
    model = firstpagelogo
    context_object_name = 'fhlogo'
    template_name = 'index.html'
    queryset = firstpagelogo.objects.all()


class khabarLV(generic.ListView):
    model = firstpagelogo
    context_object_name = 'khabar'
    template_name = 'khabar.html'
    queryset = lastnews.objects.all()

    def get_context_data(self, **kuargs):
        context = super(khabarLV, self).get_context_data(**kuargs)
        userid = self.request.user.id
        context['UserInfo'] = User.objects.all().filter(id=userid)
        return context


class khabarmasterpage(generic.ListView):
    model = firstpagelogo
    context_object_name = 'khabarmastepage'
    template_name = 'khabarmastepage.html'
    queryset = lastnews.objects.all()


class subgroupheader(generic.ListView):
    model = productsgroups

    def get(self, request):
        spg, spgid, spgt, spgtr ,spgtr2 = headermenu()
        return render(request, 'partials/firstpageheader.html', {'spg': spg, 'spgt': spgt, 'spgtr': spgtr, 'spgtr2': spgtr2})


class treeshowgroup(View):
    models = productsgroups

    def get(self, request, id):
        x = id
        spg, spgid, spgt, spgtr ,spgtr2 = headermenu()
        pg = productsgroups.objects.filter(gparentid=x)
        prd = products.objects.filter(group_id=x)
        fhlogo = firstpagelogo.objects.all()
        return render(request, 'product-category-boxed.html', {'fhlogo': fhlogo, 'pg': pg, 'prd': prd, 'spg': spg, 'spgt': spgt, 'spgtr': spgtr, 'spgtr2': spgtr2})


def treeshowgroupcreate(request, id):
    if request.method == 'POST':
        group_report = productsgroupsform(request.POST, request.FILES)
        if group_report.is_valid():
            group_report.save()
            productsgroups.objects.filter(id=productsgroups.objects.latest('id').id).update(gparentid=id)

            pgid = productsgroups.objects.filter(gparentid=0, id__gt=0).values_list('id',flat=True)
            pg_id = []
            for apgid in pgid:
                pg_id.append(apgid)

                glevel_1 = productsgroups.objects.filter(id__gt=0, glevel=0 , gparentid__in=pg_id)
                pg1_id = []
                for apgid1 in glevel_1:
                    pg1_id.append(apgid1)

                for g1 in pg1_id:
                    if g1.gparentid == apgid:
                        productsgroups.objects.filter(glevel = 0 , gparentid__gt = 0 , gparentid = apgid).update(glevel=2, GroupOrders=g1.GroupOrders)

                glevel_2 = productsgroups.objects.filter(id__gt=0, glevel=0 , gparentid__gt=0)
                pg2_id = []
                for apgid2 in glevel_2:
                    pg2_id.append(apgid2)

                groups_level_1 = productsgroups.objects.filter(glevel = 2)
                for g1 in groups_level_1:
                    for g2 in pg2_id:
                        if g2.gparentid == g1.id and g1.gparentid != 0:
                            productsgroups.objects.filter(glevel = 0 , gparentid__gt = 0, gparentid = g1.id).update(glevel=3, GroupOrders=g2.GroupOrders)

            return redirect('WebSite:productsgroupsLV', id=id)

    id = 0
    group_report = productsgroupsform(request.POST)
    return render(request, 'productsgroups_create.html', {'group_report': group_report, 'id': id})



def register(request):
    print("start register ...!")
    registererror = []
    spg, spgid, spgt, spgtr ,spgtr2 = headermenu()
    fcontact = centercontactus.objects.all()
    fhlogo = firstpagelogo.objects.all().order_by('-id')[:1]
    khabar = lastnews.objects.all().order_by('-id')[:3]
    checkusername = request.POST.get('username')
    chellphonecheck = request.POST.get('cellphone')
    password = request.POST.get('password')
    password2 = request.POST.get('password2')
    if request.method == 'POST':
        if password == password2:
            try:
                register = RegisterFormClean(request.POST)
                if checkusername.isascii() == False:
                    registererror.append(
                        'توجه : نام کاربری وارد شده با حروف انگلیسی نمی باشد.')
                    return render(request, 'index.html', {'khabar': khabar, 'fcontact': fcontact, 'fhlogo': fhlogo, 'register': register, 'registererror': registererror, 'spg': spg, 'spgt': spgt, 'spgtr': spgtr, 'spgtr2': spgtr2})
                else:
                    if User.objects.all().filter(username=checkusername):
                        registererror.append(
                            'توجه : نام کاربری وارد شده تکراری می باشد.')
                        return render(request, 'index.html', {'khabar': khabar, 'fcontact': fcontact, 'fhlogo': fhlogo, 'register': register, 'registererror': registererror, 'spg': spg, 'spgt': spgt, 'spgtr': spgtr, 'spgtr2': spgtr2})
                    if User.objects.all().filter(cellphone=chellphonecheck):
                        registererror.append(
                            'توجه : شماره تلفن همراه وارد شده تکراری می باشد.')
                        return render(request, 'index.html', {'khabar': khabar, 'fcontact': fcontact, 'fhlogo': fhlogo, 'register': register, 'registererror': registererror, 'spg': spg, 'spgt': spgt, 'spgtr': spgtr, 'spgtr2': spgtr2})
                    if register.is_valid():
                        user = register.save()
                        user.set_password(password)
                        user.save()
                        error_list = []
                        form = LoginForm(request.POST)
                        if form.is_valid() and request.user.is_authenticated == False:
                            cd = form.cleaned_data
                            if User.objects.filter(username=cd['username']):
                                if authenticate(username=cd['username'], password=cd['password']):
                                    user = authenticate(
                                        username=cd['username'], password=cd['password'])
                                    if user is not None:
                                        if user.is_active:
                                            login(request, user)
                                            return redirect('WebSite:login')
                                        error_list.append('کاربر وارد شده غیر فعال می باشد.')
                                        print("Hi!")
                                        return redirect(request.path)
                    else:
                        print("validation error")
                        registererror.append('توجه : کاربر گرامی یکی از فیلد های الزامی پر نشده است لطفا مجدد تلاش بفرمایید .')
                        return render(request, 'index.html', {'khabar': khabar, 'fcontact': fcontact, 'fhlogo': fhlogo, 'register': register, 'registererror': registererror, 'spg': spg, 'spgt': spgt, 'spgtr': spgtr, 'spgtr2': spgtr2})
            except Exception as error:
                print(error)
                registererror.append('توجه : کاربر گرامی لطفا کلیه فیلد های که با علامت ستاره قرمز رنگ مشخص شده اسند را پر بفرمایید. ')
                return render(request, 'index.html', {'khabar': khabar, 'fcontact': fcontact, 'fhlogo': fhlogo, 'register': register, 'registererror': registererror, 'spg': spg, 'spgt': spgt, 'spgtr': spgtr, 'spgtr2': spgtr2})
        register = RegisterFormClean(request.POST)
        registererror.append('توجه : اطلاعات وارد شده در فیلد های کلمه عبور یکسان نمی باشند') 
        return render(request, 'index.html', {'khabar': khabar, 'fcontact': fcontact, 'fhlogo': fhlogo, 'register': register, 'registererror': registererror, 'spg': spg, 'spgt': spgt, 'spgtr': spgtr, 'spgtr2': spgtr2})            
    register = RegisterFormClean(request.POST)
    return render(request, 'index.html', {'khabar': khabar, 'fcontact': fcontact, 'fhlogo': fhlogo, 'register': register, 'registererror': registererror, 'spg': spg, 'spgt': spgt, 'spgtr': spgtr, 'spgtr2': spgtr2})




def registermobile(request):
    mregistererror = []
    mform = LoginFormmobile(request.POST)
    spg, spgid, spgt, spgtr ,spgtr2 = headermenu()
    fcontact = centercontactus.objects.all()
    fhlogo = firstpagelogo.objects.all().order_by('-id')[:1]
    khabar = lastnews.objects.all().order_by('-id')[:3]
    checkusername = request.POST.get('username')
    chellphonecheck = request.POST.get('cellphone')
    password = request.POST.get('password')
    print('step 1')
    if request.method == 'POST':
        print('step 2')
        mregister = RegistermobileFormClean(request.POST)
        if User.objects.all().filter(username=checkusername):
            mregistererror.append(
                'توجه : نام کاربری وارد شده تکراری می باشد.')
            return render(request, 'login.html', {'khabar': khabar, 'fcontact': fcontact, 'fhlogo': fhlogo, 'mregister': mregister, 'mregistererror': mregistererror, 'mform': mform, 'spg': spg, 'spgt': spgt, 'spgtr': spgtr, 'spgtr2': spgtr2})
        if User.objects.all().filter(cellphone=chellphonecheck):
            print('step 3')
            mregistererror.append(
                'توجه : شماره تلفن همراه وارد شده تکراری می باشد.')
            return render(request, 'login.html', {'khabar': khabar, 'fcontact': fcontact, 'fhlogo': fhlogo, 'mregister': mregister, 'mregistererror': mregistererror, 'mform': mform, 'spg': spg, 'spgt': spgt, 'spgtr': spgtr, 'spgtr2': spgtr2})
        print('step 4')
        if mregister.is_valid():
            print('step 5: validation')
            user = mregister.save()
            user.set_password(password)
            user.save()
            print('step 6:HI !')
            return redirect('WebSite:login')
    print('step 7')
    mregister = RegistermobileFormClean(request.POST)
    return render(request, 'login.html', {'khabar': khabar, 'fcontact': fcontact, 'fhlogo': fhlogo, 'mregister': mregister, 'mform': mform, 'mregistererror': mregistererror, 'spg': spg, 'spgt': spgt, 'spgtr': spgtr, 'spgtr2': spgtr2})


# def createpass(phone):
#     url = "http://RestfulSms.com/api/Token?"

#     payload = "{\r\n  \"UserApiKey\": \"b3039ef2668d9207a1ffa89d\",\r\n  \"SecretKey\": \"123Albas456\"\r\n}"
#     headers = {
#         'Content-Type': 'application/json'
#     }

#     response = requests.request("POST", url, headers=headers, data=payload)


#     token = response.json()["TokenKey"]



#     url = "http://RestfulSms.com/api/VerificationCode"
#     letters = string.digits
#     result_str = ''.join(random.choice(letters) for i in range(6))

#     payload = "{\r\n   \"Code\": \""+result_str + \
#         "\",\r\n   \"MobileNumber\": \""+phone + "\"\r\n} "

#     headers = {
#         'Content-Type': 'application/json',
#         'x-sms-ir-secure-token': '{}'.format(token)
#     }

#     response = requests.request("POST", url, headers=headers, data=payload)

#     return result_str


# Login


def loginusermobile(request):
    merror_list = []
    x = 0
    mform = LoginFormmobile(request.POST)
    if mform.is_valid() and request.user.is_authenticated == False:
        mcd = mform.cleaned_data
        if User.objects.filter(username=mcd['username']):
            if authenticate(username=mcd['username'], password=mcd['password']):
                user = authenticate(
                    username=mcd['username'], password=mcd['password'])
                if user is not None:
                    if user.is_active:
                        login(request, user)
                        return redirect('WebSite:login')
                    merror_list.append('کاربر وارد شده غیر فعال می باشد.')
                    return render(request, 'login.html', {'mform': mform, 'merror_list': merror_list})
            merror_list.append(' کلمه عبور وارد شده اشتباه می باشد.')
            return render(request, 'login.html', {'mform': mform, 'merror_list': merror_list})
        merror_list.append(' نام کاربری وارد شده اشتباه می باشد.')
        return render(request, 'login.html', {'mform': mform, 'merror_list': merror_list})
    mfehrests = productsgroups.objects.all()
    return render(request, 'login.html', {'x': x, 'mform': mform, 'merror_list': merror_list, 'mfehrests': mfehrests})


def productscategoryparent(request, id):
    if request.method == 'POST':
        pcategory = productscategoryform(request.POST, request.FILES)
        if pcategory.is_valid():
            pcategory.save()
            productscategory.objects.filter(
                id=productscategory.objects.latest('id').id).update(cparentid=id)
            return redirect('WebSite:productscategoryLV', id=id)
    pcategory = productscategoryform(request.POST)
    id = 0
    return render(request, 'productscategory_create.html', {'pcategory': pcategory, 'id': id})


class productscategoryview(generic.ListView):
    model = productscategory
    context_object_name = 'productscategoryLV'
    template_name = 'productscategoryLV.html'
    queryset = productscategory.objects.all().filter(id__gt = 0)

    def get_context_data(self, **kuargs):
        context = super(productscategoryview, self).get_context_data(**kuargs)
        userid = self.request.user.id
        context['UserInfo'] = User.objects.all().filter(id=userid)
        context['id'] =  self.kwargs['id']
        return context


class productscategoryjasonview(BaseDatatableView):
    model = productscategory
    columns = ['', 'id', 'cname', 'cparentid', 'cdesc']
    order_columns = ['', 'id', 'cname','cparentid',  'cdesc']

    def render_column(self, row, column):
        return super(productscategoryjasonview, self).render_column(row, column)

    def filter_queryset(self, qs):
        search = self.request.GET.get('search[value]', None)
        id = self.kwargs.get('id')
        
        if search:
            qs = qs.filter(Q(id__in=search) | Q(cname__name__icontains=search) | Q(cparentid=search) | Q(cdesc__icontains=search))

        if id:
            qs = qs.filter(Q(cparentid = id) , Q(id__gt = 0))
        else:
            qs = qs.filter(Q(cparentid = 0) , Q(id__gt = 0))

        return qs


class allproducts(generic.ListView):
    model = products
    context_object_name = 'Allproducts'
    template_name = 'category-boxed.html'
    queryset = products.objects.all()

    def get_context_data(self, **kuargs):
        context = super(allproducts, self).get_context_data(**kuargs)
        context['Latestproducts'] = products.objects.all().filter(id__gt = 0).order_by('-id')[:1]
        context['fehrests'] = productsgroups.objects.all()
        spg, spgid, spgt, spgtr ,spgtr2 = headermenu()
        context['spg'] = spg
        context['spgid'] = spgid
        context['spgt'] = spgt
        context['spgtr'] = spgtr
        context['spgtr2'] = spgtr2
        context['id'] = 0
        return context


class firstpagelogoview(generic.ListView):
    models = firstpagebaners
    context_object_name = 'logo'
    template_name = 'index.html'
    queryset = firstpagebaners.objects.all()


class bankreport(generic.ListView):
    model = parametsaccounts
    context_object_name = 'bankreport'
    template_name = 'bank_view.html'
    queryset = parametsaccounts.objects.all()

    def get_context_data(self, **kwargs):
        context = super(bankreport, self).get_context_data(**kwargs)
        context['fcontact'] = centercontactus.objects.all()
        context['fhlogo'] = firstpagelogo.objects.all()
        spg, spgid, spgt, spgtr ,spgtr2 = headermenu()
        context['spg'] = spg
        context['spgid'] = spgid
        context['spgt'] = spgt
        context['spgtr'] = spgtr
        context['spgtr2'] = spgtr2
        context['id'] = 0
        return context


class bankaccount(generic.ListView):
    model = parametsaccounts
    context_object_name = 'bankreport'
    template_name = 'bacnkaccount.html'
    queryset = parametsaccounts.objects.all()

    def get_context_data(self, **kuargs):
        context = super(bankaccount, self).get_context_data(**kuargs)
        userid = self.request.user.id
        context['UserInfo'] = User.objects.all().filter(id=userid)
        context['id'] = 0
        return context


class sasreportfooter(generic.ListView):
    model = parametssas
    context_object_name = 'sasreport'
    template_name = 'after_sale_view.html'
    queryset = parametssas.objects.all()

    def get_context_data(self, **kwargs):
        context = super(sasreportfooter, self).get_context_data(**kwargs)
        context['fcontact'] = centercontactus.objects.all()
        context['fhlogo'] = firstpagelogo.objects.all()
        spg, spgid, spgt, spgtr ,spgtr2 = headermenu()
        context['spg'] = spg
        context['spgid'] = spgid
        context['spgt'] = spgt
        context['spgtr'] = spgtr
        context['spgtr2'] = spgtr2
        context['id'] = 0
        return context


class weblogadmin(generic.ListView):
    models = weblog
    context_object_name = 'weblogadmin'
    template_name = 'weblogadmin.html'
    queryset = weblog.objects.all()


class weblogusers(generic.ListView):
    models = weblog
    context_object_name = 'weblogs'
    template_name = 'weblog_view.html'
    queryset = weblog.objects.all()

    def get_context_data(self, **kwargs):
        context = super(weblogusers, self).get_context_data(**kwargs)
        context['fcontact'] = centercontactus.objects.all()
        context['fhlogo'] = firstpagelogo.objects.all()
        spg, spgid, spgt, spgtr ,spgtr2 = headermenu()
        context['spg'] = spg
        context['spgid'] = spgid
        context['spgt'] = spgt
        context['spgtr'] = spgtr
        context['spgtr2'] = spgtr2
        context['id'] = 0
        return context


class sasreportadmin(generic.ListView):
    model = parametssas
    context_object_name = 'sas'
    template_name = 'after_sale_support.html'
    queryset = parametssas.objects.all()

    def get_context_data(self, **kuargs):
        context = super(sasreportadmin, self).get_context_data(**kuargs)
        userid = self.request.user.id
        context['UserInfo'] = User.objects.all().filter(id=userid)
        context['id'] = 0
        return context


class supportreportfooter(generic.ListView):
    model = parametssupport
    context_object_name = 'supportreport'
    template_name = 'support_view.html'
    queryset = parametssupport.objects.all()

    def get_context_data(self, **kwargs):
        context = super(supportreportfooter, self).get_context_data(**kwargs)
        context['fcontact'] = centercontactus.objects.all()
        context['fhlogo'] = firstpagelogo.objects.all()
        spg, spgid, spgt, spgtr ,spgtr2 = headermenu()
        context['spg'] = spg
        context['spgid'] = spgid
        context['spgt'] = spgt
        context['spgtr'] = spgtr
        context['spgtr2'] = spgtr2
        context['id'] = 0

        return context


class supportreportadmin(generic.ListView):
    model = parametssupport
    context_object_name = 'support'
    template_name = 'support.html'
    queryset = parametssupport.objects.all()

    def get_context_data(self, **kuargs):
        context = super(supportreportadmin, self).get_context_data(**kuargs)
        userid = self.request.user.id
        context['UserInfo'] = User.objects.all().filter(id=userid)
        context['id'] = 0
        return context


class sparticle(generic.ListView):
    model = SPArticle
    context_object_name = 'spa'
    template_name = 'factordetaile.html'
    queryset = SPArticle.objects.all()


class AdminCheck(generic.ListView):
    model = Check
    context_object_name = 'Check'
    template_name = 'PayRcvDetail.html'
    queryset = Check.objects.all()


class userAdminCheck(generic.ListView):
    model = Check
    context_object_name = 'Check'
    template_name = 'PayRcvDetaile.html'
    queryset = Check.objects.all()


class sparticleseprate(generic.ListView):
    model = SPArticle
    context_object_name = 'spas'
    template_name = 'factordetaileseprated.html'

    def get(self, request, id, *args, **kwargs):
        spas = SPArticle.objects.all().filter(SPId=id)
        return render(request, 'factordetaileseprated.html', {'spas': spas})


class PayRcvDetailseprate(generic.ListView):
    model = Check
    context_object_name = 'pds'
    template_name = 'PayRcvDetail.html'

    def get(self, request, id, *args, **kwargs):
        pds = Check.objects.all().filter(id2=id)
        return render(request, 'PayRcvDetail.html', {'pds': pds})


class paypage(generic.ListView):
    models = sellbascket
    context_object_name = 'paypage'
    template_name = 'checkout.html'

    def get(self, request):
        userid = request.user.id
        fehrests = productsgroups.objects.all()
        sb = sellbascket.objects.all().filter(status=0, Create_Uid=userid)

        products_c_s = []
        psb = products.objects.all().filter(id__gt= 0)
        for ppsb in psb:
            productparam = productsparamerts.objects.filter(pid_id=ppsb.id)
            for pppsb in productparam:
                colorname = productscolors.objects.filter(id=pppsb.cid_id)
                sizename = productssize.objects.filter(id=pppsb.sid_id)
                products_c_s.append((pppsb.pid_id, colorname, sizename))
        
        spg, spgid, spgt, spgtr ,spgtr2 = headermenu()
        id = 0
        return render(request, 'cart.html', {'id': id,'sb': sb, 'products_c_s': products_c_s, 'fehrests': fehrests, 'psb': psb, 'spg': spg, 'spgt': spgt, 'spgtr': spgtr, 'spgtr2': spgtr2})


class stors(generic.ListView):
    model = salecontactus
    context_object_name = 'stor'
    template_name = 'stors.html'
    queryset = salecontactus.objects.all()

    def get_context_data(self, **kwargs):
        context = super(stors, self).get_context_data(**kwargs)
        context['fhlogo'] = firstpagelogo.objects.all()
        context['fehrests'] = productsgroups.objects.all()
        spg, spgid, spgt, spgtr ,spgtr2 = headermenu()
        context['spg'] = spg
        context['spgid'] = spgid
        context['spgt'] = spgt
        context['spgtr'] = spgtr
        context['spgtr2'] = spgtr2
        context['id'] = 0
        return context


class indexproductshow(generic.ListView):
    models = products
    context_object_name = 'indexshowproduct'
    template_name = 'indexproduct.html'

    def get(self, request, id):
        fehrests = productsgroups.objects.all()
        indexshowproduct = products.objects.all().filter(id=id, id__gt= 0)
        id = 0
        return render(request, 'indexproduct.html', {'id': id,'indexshowproduct': indexshowproduct,
                                                     'fehrests': fehrests})


class logoreportview(generic.ListView):
    model = firstpagelogo
    context_object_name = 'Logo'
    template_name = 'Logo.html'
    queryset = firstpagelogo.objects.all()

    def get_context_data(self, **kuargs):
        context = super(logoreportview, self).get_context_data(**kuargs)
        userid = self.request.user.id
        context['UserInfo'] = User.objects.all().filter(id=userid)
        context['id'] = 0
        return context


class bannersreportview(generic.ListView):
    model = firstpagebaners
    context_object_name = 'logo'
    template_name = 'logo_report.html'
    queryset = firstpagebaners.objects.all()

    def get_context_data(self, **kuargs):
        context = super(bannersreportview, self).get_context_data(**kuargs)
        userid = self.request.user.id
        context['UserInfo'] = User.objects.all().filter(id=userid)
        context['id'] = 0
        return context


class customersgroupreport(generic.ListView):
    model = customersgroup
    context_object_name = 'customersgroupreport'
    template_name = 'cutomersgroup.html'
    queryset = customersgroup.objects.all().filter(id__gt = 0)

    def get_context_data(self, **kuargs):
        context = super(customersgroupreport, self).get_context_data(**kuargs)
        userid = self.request.user.id
        context['UserInfo'] = User.objects.all().filter(id=userid)
        context['id'] = 0
        return context


class aboutreportview(generic.ListView):
    model = aboutus
    context_object_name = 'about'
    template_name = 'about.html'
    queryset = aboutus.objects.all()

    def get_context_data(self, **kuargs):
        context = super(aboutreportview, self).get_context_data(**kuargs)
        userid = self.request.user.id
        context['UserInfo'] = User.objects.all().filter(id=userid)
        context['id'] = 0
        return context


class aboutteamreportview(generic.ListView):
    model = aboutusp1
    context_object_name = 'aboutteam'
    template_name = 'aboutteam.html'
    queryset = aboutusp1.objects.all()

    def get_context_data(self, **kuargs):
        context = super(aboutteamreportview, self).get_context_data(**kuargs)
        userid = self.request.user.id
        context['UserInfo'] = User.objects.all().filter(id=userid)
        context['id'] = 0
        return context


class useraboutteamreportview(generic.ListView):
    model = aboutusp1
    context_object_name = 'aboutusteam'
    template_name = 'about-2.html'
    queryset = aboutusp1.objects.all()


class aboutbrandreport(generic.ListView):
    models = productsbrands
    context_object_name = 'aboutbrand'
    template_name = 'about-2.html'
    queryset = productsbrands.objects.all()


class ccontactusreportview(generic.ListView):
    model = centercontactus
    context_object_name = 'ccontactus'
    template_name = 'ccontactus.html'
    queryset = centercontactus.objects.all()

    def get_context_data(self, **kuargs):
        context = super(ccontactusreportview, self).get_context_data(**kuargs)
        userid = self.request.user.id
        context['UserInfo'] = User.objects.all().filter(id=userid)
        spg, spgid, spgt, spgtr ,spgtr2 = headermenu()
        context['spg'] = spg
        context['spgid'] = spgid
        context['spgt'] = spgt
        context['spgtr'] = spgtr
        context['spgtr2'] = spgtr2
        context['id'] = 0
        return context


class scontactusreportview(generic.ListView):
    model = salecontactus
    context_object_name = 'scontactus'
    template_name = 'scontactus.html'
    queryset = salecontactus.objects.all()

    def get_context_data(self, **kuargs):
        context = super(scontactusreportview, self).get_context_data(**kuargs)
        userid = self.request.user.id
        context['UserInfo'] = User.objects.all().filter(id=userid)
        context['id'] = 0
        return context


class footercontactus(generic.ListView):
    model = centercontactus
    context_object_name = 'fcontact'
    template_name = 'index.html'
    queryset = centercontactus.objects.all()


class userccontactusreportview(generic.ListView):
    model = centercontactus
    context_object_name = 'uccontactus'
    template_name = 'contact.html'
    queryset = centercontactus.objects.all()


class userscontactusreportview(generic.ListView):
    model = salecontactus
    context_object_name = 'uscontactus'
    template_name = 'contact.html'
    queryset = salecontactus.objects.all()


class customerquestionsview(generic.ListView):
    model = customerquestions
    context_object_name = 'cq'
    template_name = 'cq.html'
    queryset = customerquestions.objects.all()

    def get_context_data(self, **kuargs):
        context = super(customerquestionsview, self).get_context_data(**kuargs)
        userid = self.request.user.id
        context['UserInfo'] = User.objects.all().filter(id=userid)
        context['id'] = 0
        return context


class newestproducts(generic.ListView):
    model = products
    context_object_name = 'newproducts'
    template_name = 'index.html'
    queryset = products.objects.all().filter(id__gt= 0).order_by('-id')[:6]


class latestproducts(generic.ListView):
    model = products
    context_object_name = 'Latestproducts'
    template_name = 'index.html'
    queryset = products.objects.all().filter(id__gt = 0).order_by('-id')[:1]


class nonegoods(generic.ListView):
    model = products
    context_object_name = 'ng'
    template_name = 'index.html'
    queryset = products.objects.all().filter(id__gt= 0)


class usersreport(LoginRequiredMixin, PermissionRequiredMixin, generic.ListView):
    model = User
    permission_required = 'can_read_private_section'
    context_object_name = 'users'
    template_name = 'users.html'
    queryset = User.objects.all().filter(id__gt = 0)

    def get_context_data(self, **kuargs):
        context = super(usersreport, self).get_context_data(**kuargs)
        userid = self.request.user.id
        context['UserInfo'] = User.objects.all().filter(id=userid, id__gt = 0)
        context['usergroup'] = customersgroup.objects.all().filter(id__gt = 0)
        context['id'] = 0
        return context


class productfirstpage(generic.ListView):
    models = products
    context_object_name = 'productfirst'
    template_name = 'index.html'
    queryset = products.objects.all().filter(id__gt= 0)


class productss(LoginRequiredMixin, PermissionRequiredMixin, generic.ListView):
    models = products
    permission_required = 'can_read_private_section'
    context_object_name = 'product'
    template_name = 'product.html'
    queryset = products.objects.all().filter(id__gt= 0)

    def get_context_data(self, **kuargs):
        context = super(productss, self).get_context_data(**kuargs)
        userid = self.request.user.id
        context['UserInfo'] = User.objects.all().filter(id=userid)
        context['id'] = 0
        return context


class productsgroupsreport(LoginRequiredMixin, PermissionRequiredMixin, generic.ListView):
    models = productsgroups
    permission_required = 'can_read_private_section'
    context_object_name = 'productsgroupsLV'
    template_name = 'productsgroupsLV.html'
    queryset = productsgroups.objects.all()

    def get_context_data(self, **kuargs):
        context = super(productsgroupsreport, self).get_context_data(**kuargs)
        userid = self.request.user.id
        context['UserInfo'] = User.objects.all().filter(id=userid)
        rowid = self.kwargs['id']
        context['id'] = rowid

        pg_level_1 = productsgroups.objects.all().filter(id=rowid, glevel=1)
        pg_level_2 = productsgroups.objects.all().filter(gparentid=rowid, glevel=2)

        pg_level_3 = []
        for gparentid in pg_level_2:
            pgl3 = productsgroups.objects.all().filter(gparentid=gparentid.id, glevel=2)
            pg_level_3.append(pgl3)

        context['pg_level_1'] = pg_level_1
        context['pg_level_2'] = pg_level_2
        context['pg_level_3'] = pg_level_3
        
        return context


class productsgroupsreportthreeshow(LoginRequiredMixin, PermissionRequiredMixin, generic.ListView):
    models = productsgroups
    permission_required = 'can_read_private_section'
    context_object_name = 'pgthreeshow'
    template_name = 'productsgroupsLV_threeshow.html'
    queryset = productsgroups.objects.all()

    def get_context_data(self, **kuargs):
        context = super(productsgroupsreportthreeshow, self).get_context_data(**kuargs)
        userid = self.request.user.id
        context['UserInfo'] = User.objects.all().filter(id=userid)

        context['id'] = 0
        
        id = self.kwargs.get('id')
        if id:
            pg_level_1 = productsgroups.objects.all().filter(glevel=1, id__gt=0, id = id)

            pg_level_2 = []
            for gparentid_1 in pg_level_1:
                pgl2 = productsgroups.objects.all().filter(gparentid=int(gparentid_1.id), glevel=2)
                pg_level_2.extend(pgl2)


            pg_level_3 = []
            for gparentid_2 in pg_level_2:
                pgl3 = productsgroups.objects.all().filter(gparentid=int(gparentid_2.id), glevel=3)
                pg_level_3.extend((pgl3))

            context['pg_level_1'] = pg_level_1
            context['pg_level_2'] = pg_level_2
            context['pg_level_3'] = pg_level_3
        else:
            pg_level_1 = productsgroups.objects.all().filter(glevel=1, id__gt=0)

            pg_level_2 = []
            for gparentid_1 in pg_level_1:
                pgl2 = productsgroups.objects.all().filter(gparentid=int(gparentid_1.id), glevel=2)
                pg_level_2.extend(pgl2)


            pg_level_3 = []
            for gparentid_2 in pg_level_2:
                pgl3 = productsgroups.objects.all().filter(gparentid=int(gparentid_2.id), glevel=3)
                pg_level_3.extend((pgl3))

            context['pg_level_1'] = pg_level_1
            context['pg_level_2'] = pg_level_2
            context['pg_level_3'] = pg_level_3

        

        return context


class customerreport(generic.ListView):
    models = Customers
    context_object_name = 'customerLV'
    template_name = 'customer_report.html'
    queryset = Customers.objects.raw(
        "select a.id as id1 ,b.id as id,b.FAccId,b.Name,b.Family,b.CellPhone,b.PhoneNo,b.FaxNo,b.SCode,b.Email,b.EcCode,b.Address,b.ZipCode,b.UserId,b.TRes,b.CSex,b.FPId from comment a right join CustomerReport () b on a.id=b.id")

    def get_context_data(self, **kuargs):
        context = super(customerreport, self).get_context_data(**kuargs)
        userid = self.request.user.id
        context['UserInfo'] = User.objects.all().filter(id=userid)
        context['id'] = 0
        return context


class ersalreport(generic.ListView):
    models = parametrsersal
    context_object_name = 'ersal'
    template_name = 'ersal.html'
    queryset = parametrsersal.objects.all()

    def get_context_data(self, **kuargs):
        context = super(ersalreport, self).get_context_data(**kuargs)
        userid = self.request.user.id
        context['UserInfo'] = User.objects.all().filter(id=userid)
        context['id'] = 0
        return context


class osoolreport(generic.ListView):
    models = parametrsosool
    context_object_name = 'osool'
    template_name = 'osool.html'
    queryset = parametrsosool.objects.all()

    def get_context_data(self, **kuargs):
        context = super(osoolreport, self).get_context_data(**kuargs)
        userid = self.request.user.id
        context['UserInfo'] = User.objects.all().filter(id=userid)
        context['id'] = 0
        return context


class ersalreportusers(generic.ListView):
    models = parametrsersal
    context_object_name = 'ersalusers'
    template_name = 'ersal_report_users.html'
    queryset = parametrsersal.objects.all().order_by('-id')[:1]

    def get_context_data(self, **kwargs):
        context = super(ersalreportusers, self).get_context_data(**kwargs)
        context['fhlogo'] = firstpagelogo.objects.all()
        spg, spgid, spgt, spgtr ,spgtr2 = headermenu()
        context['spg'] = spg
        context['spgid'] = spgid
        context['spgt'] = spgt
        context['spgtr'] = spgtr
        context['spgtr2'] = spgtr2  
        context['id'] = 0
        return context


class osoolreportusers(generic.ListView):
    models = parametrsosool
    context_object_name = 'osool'
    template_name = 'osool_report_users.html'
    queryset = parametrsosool.objects.all().order_by('-id')[:1]

    def get_context_data(self, **kwargs):
        context = super(osoolreportusers, self).get_context_data(**kwargs)
        context['fhlogo'] = firstpagelogo.objects.all()
        spg, spgid, spgt, spgtr ,spgtr2 = headermenu()
        context['spg'] = spg
        context['spgid'] = spgid
        context['spgt'] = spgt
        context['spgtr'] = spgtr
        context['spgtr2'] = spgtr2
        context['id'] = 0
        return context


class customerreportJson(BaseDatatableView):
    model = Customers
    # def get_initial_queryset(self):
    #     return Customers.objects.raw("select a.id as id1 ,b.id as id,b.FAccId,b.Name,b.Family,b.CellPhone,b.PhoneNo,b.FaxNo,b.SCode,b.Email,b.EcCode,b.Address,b.ZipCode,b.UserId,b.TRes,b.CSex,b.FPId from comment a right join CustomerReport () b on a.id=b.id")

    context_object_name = 'customerLV'
    columns = ['', 'id', 'FAccId', 'Name', 'Family', 'CellPhone', 'PhoneNo', 'FaxNo',
               'SCode', 'Email', 'EcCode', 'Address', 'ZipCode', 'UserId', 'TRes', 'CSex', 'FPId']
    order_columns = ['', 'id', 'FAccId', 'Name', 'Family', 'CellPhone', 'PhoneNo', 'FaxNo',
                     'SCode', 'Email', 'EcCode', 'Address', 'ZipCode', 'UserId', 'TRes', 'CSex', 'FPId']

    def render_column(self, row, column):
        return super(customerreportJson, self).render_column(row, column)

    def filter_queryset(self, qs):
        search = self.request.GET.get('search[value]', None)

        if search:
            qs = qs.filter(Q(id__icontains=search) | Q(FAccId__icontains=search) | Q(Name__icontains=search) | Q(Family__icontains=search) | Q(CellPhone__icontains=search)
                           | Q(PhoneNo__icontains=search) | Q(FaxNo__icontains=search) | Q(SCode__icontains=search) | Q(Email__icontains=search) | Q(EcCode__icontains=search) | Q(Address__icontains=search) | Q(ZipCode__icontains=search)
                           | Q(UserId__icontains=search) | Q(TRes__icontains=search) | Q(CSex__icontains=search) | Q(FPId__icontains=search))

        return qs


class Factorsreport(generic.ListView):
    models = SPFactor
    context_object_name = 'factorLV'
    template_name = 'factorLV.html'
    queryset = SPFactor.objects.all()

    def get_context_data(self, **kuargs):
        context = super(Factorsreport, self).get_context_data(**kuargs)
        userid = self.request.user.id
        context['UserInfo'] = User.objects.all().filter(id=userid)
        context['id'] = 0
        return context


class PayRcvreport(generic.ListView):
    models = PayRcv
    context_object_name = 'PayRcvLV'
    template_name = 'PayRcvLV.html'
    queryset = PayRcv.objects.all()

    def get_context_data(self, **kuargs):
        context = super(PayRcvreport, self).get_context_data(**kuargs)
        userid = self.request.user.id
        context['UserInfo'] = User.objects.all().filter(id=userid)
        context['id'] = 0
        return context




class UsersReaportJson(BaseDatatableView):
    model = User
    columns = ['', 'id', '', '', 'customersgroupid', 'customersid',
               'username', 'first_name', 'is_active', 'is_staff', 'is_superuser']
    order_columns = ['', 'id', '', '', 'customersgroupid', 'customersid',
                     'username', 'first_name', 'is_active', 'is_staff', 'is_superuser']

    def render_column(self, row, column):
        return super(UsersReaportJson, self).render_column(row, column)

    def filter_queryset(self, qs):
        search = self.request.GET.get('search[value]', None)
        if search:
            qs = qs.filter(Q(id__icontains=search) | Q(customersgroupid__icontains=search) | Q(
                customersid__icontains=search) | Q(username__icontains=search) | Q(first_name__icontains=search))
        return qs


class GroupReaportJson(BaseDatatableView):
    model = productsgroups
    columns = ['', 'id', 'gparentid', 'glevel', 'group_img',
               'Group_Name', 'Group_Desc', 'cname1', 'cname2', 'cname3']
    order_columns = ['', 'id', 'gparentid', 'glevel', 'group_img',
                     'Group_Name', 'Group_Desc', 'cname1', 'cname2', 'cname3']

    def render_column(self, row, column):
        return super(GroupReaportJson, self).render_column(row, column)

    def filter_queryset(self, qs):
        search = self.request.GET.get('search[value]', None)
        id = self.kwargs.get('id')
        
        if search:
            qs = qs.filter(Q(id__icontains=search) | Q(gparentid__icontains=search) | Q(
                glevel__icontains=search) | Q(Group__Name__icontains=search) | Q(Group_Desc__icontains=search))

        if id:
            qs = qs.filter(Q(gparentid = id) , Q(id__gt = 0))
        else:
            qs = qs.filter(Q(glevel = 1) , Q(id__gt = 0))

        return qs


class FactorsreportJson(BaseDatatableView):
    model = SPFactor
    columns = ['', 'id', 'FactorNo', 'ReferenceNo', 'SPDate', 'FactorType', 'CustomerId', 'Total', 'Discount', 'Expense', 'SPDesc',
               'CustomerName', 'CustomerPhoneNo', 'CustomerEcCode', 'CustomerAddress', 'FPId', 'SC', 'FStatus', 'FactorSubType', 'Committed']
    order_columns = ['', 'id', 'FactorNo', 'ReferenceNo', 'SPDate', 'FactorType', 'CustomerId', 'Total', 'Discount', 'Expense', 'SPDesc',
                     'CustomerName', 'CustomerPhoneNo', 'CustomerEcCode', 'CustomerAddress', 'FPId', 'SC', 'FStatus', 'FactorSubType', 'Committed']

    def render_column(self, row, column):
        if column == 'SPDate':
            return escape('{0}'.format(MiladiToShamsi(row.SPDate)))
        else:
            return super(FactorsreportJson, self).render_column(row, column)

    def filter_queryset(self, qs):
        search = self.request.GET.get('search[value]', None)
        if search:
            qs = qs.filter(Q(id__icontains=search) | Q(FactorNo__icontains=search) | Q(ReferenceNo__icontains=search) | Q(SPDate__icontains=search) | Q(FStatus__icontains=search) | Q(FactorSubType__icontains=search) | Q(Committed__icontains=search
                                                                                                                                                                                                                            ) | Q(FactorType__icontains=search) | Q(CustomerId__icontains=search) | Q(Total__icontains=search) | Q(Discount__icontains=search) | Q(Discount__icontains=search) | Q(Expense__icontains=search) | Q(SPDesc__icontains=search) |
                           Q(CustomerName__icontains=search) | Q(CustomerPhoneNo__icontains=search) | Q(FPId__icontains=search) | Q(CustomerEcCode__icontains=search) | Q(CustomerAddress__icontains=search) | Q(FStatus__icontains=search) | Q(SC__icontains=search))
        filter_customer = self.request.GET.get('FactorNo', None)
        return qs


class PayRcvReportJson(BaseDatatableView):
    model = PayRcv
    columns = ['', 'PNo', 'PayType', 'PDate',
               'RAB0', 'PDesc', 'CustomerId', 'PCValue']
    order_columns = ['', 'PNo', 'PayType', 'PDate',
                     'RAB0', 'PDesc', 'CustomerId', 'PCValue']

    def render_column(self, row, column):
        if column == 'PDate':
            return escape('{0}'.format(MiladiToShamsi(row.PDate)))
        else:
            return super(PayRcvReportJson, self).render_column(row, column)

    def filter_queryset(self, qs):
        search = self.request.GET.get('search[value]', None)
        if search:
            qs = qs.filter(Q(id__icontains=search) | Q(PNo__icontains=search) | Q(PayType__icontains=search) | Q(
                RAB0__icontains=search) | Q(PDesc__icontains=search) | Q(PCValue__icontains=search))
        filter_customer = self.request.GET.get('PNo', None)
        return qs


class PayRcvDetaileReportJson(BaseDatatableView):
    model = Check
    columns = ['', 'id', 'Stype', 'CheckNo',
               'CValue', 'CDate', 'RcptDate', 'CStatus']
    order_columns = ['', 'id', 'Stype', 'CheckNo',
                     'CValue', 'CDate', 'RcptDate', 'CStatus']

    def render_column(self, row, column):
        return super(PayRcvDetaileReportJson, self).render_column(row, column)

    def filter_queryset(self, qs):
        search = self.request.GET.get('search[value]', None)
        if search:
            qs = qs.filter(Q(id__icontains=search) | Q(Stype__icontains=search) | Q(CheckNo__icontains=search) | Q(
                CType__icontains=search) | Q(RcptDate__icontains=search) | Q(CValue__icontains=search))
        filter_customer = self.request.GET.get('CheckNo', None)
        return qs


class ProductReportJson(BaseDatatableView):
    model = products
    columns = ['', 'id', '', 'name', 'priceorg', 'serial', 'group', 'guarantee', 'supportaftersale', 'supportaftersalecount', 'guaranteecount']
    order_columns = ['', 'id', '', 'name', 'priceorg', 'serial', 'group', 'guarantee', 'supportaftersale', 'supportaftersalecount', 'guaranteecount']

    def render_column(self, row, column):
        return super(ProductReportJson, self).render_column(row, column)

    def filter_queryset(self, qs):
        search = self.request.GET.get('search[value]', None)
        if search:
            qs = qs.filter( Q(name__icontains=search)
             | Q(serial=search)
             | Q(group__Group_Name__icontains=search)
             | Q(serial__icontains=search)
             | Q(priceorg__icontains=search))

        return qs


class commentreport(generic.ListView):
    models = comment
    permission_required = 'can_read_private_section'
    context_object_name = 'commentLV'
    template_name = 'commentLV.html'
    queryset = comment.objects.all()

    def get_context_data(self, **kuargs):
        context = super(commentreport, self).get_context_data(**kuargs)
        userid = self.request.user.id
        context['UserInfo'] = User.objects.all().filter(id=userid)
        context['id'] = 0
        return context


class costreport(LoginRequiredMixin, PermissionRequiredMixin, generic.ListView):
    models = cost
    permission_required = 'can_read_private_section'
    context_object_name = 'costLV'
    template_name = 'costLV.html'
    queryset = cost.objects.all().filter(id__gt=0)


class brandreport(LoginRequiredMixin, PermissionRequiredMixin, generic.ListView):
    models = productsbrands
    permission_required = 'can_read_private_section'
    context_object_name = 'productsbrandsLV'
    template_name = 'productsbrandsLV.html'
    queryset = productsbrands.objects.all()

    def get_context_data(self, **kuargs):
        context = super(brandreport, self).get_context_data(**kuargs)
        userid = self.request.user.id
        context['UserInfo'] = User.objects.all().filter(id=userid)
        context['id'] = 0
        return context


class brandreportfirstpage(generic.ListView):
    models = productsbrands
    context_object_name = 'brand'
    template_name = 'index.html'
    queryset = productsbrands.objects.all()


class users(generic.ListView):
    models = User
    context_object_name = 'users'
    template_name = 'index.html'
    queryset = User.objects.all()


# 0-1 first-page-slider-LV
class sliderreport(generic.ListView):
    models = slider
    context_object_name = 'slider'
    template_name = 'slider.html'
    queryset = slider.objects.all()

    def get_context_data(self, **kuargs):
        context = super(sliderreport, self).get_context_data(**kuargs)
        userid = self.request.user.id
        context['UserInfo'] = User.objects.all().filter(id=userid)
        context['id'] = 0
        return context


class insidesliderreport(generic.ListView):
    models = insideslider
    context_object_name = 'slider'
    template_name = 'insideslider.html'
    queryset = insideslider.objects.all()

    def get_context_data(self, **kuargs):
        context = super(insidesliderreport, self).get_context_data(**kuargs)
        userid = self.request.user.id
        context['UserInfo'] = User.objects.all().filter(id=userid)
        context['id'] = 0
        return context


# 0-1 first-page-slider-LV
class sliders(generic.ListView):
    models = insideslider
    context_object_name = 'sliders'
    template_name = 'advancedsearchProducts.html'
    queryset = insideslider.objects.all()


class advancsedbanner(generic.ListView):
    models = firstpagebaners
    context_object_name = 'advancb'
    template_name = 'advancedsearchProducts.html'
    queryset = firstpagebaners.objects.all()


class fehrest(generic.ListView):
    models = productsgroups
    context_object_name = 'fehrests'
    template_name = 'index.html'
    queryset = productsgroups.objects.all()


class fehrestdetail(generic.ListView):
    models = products
    context_object_name = 'productsdetails'
    template_name = 'index.html'
    queryset = products.objects.all().filter(id__gt= 0)


class search_box(View):
    def get(self, request):
        zero_serch = request.GET.get('zero', None)
        SellBascket = sellbascket.objects.filter(Create_Uid=request.user.id, status=0).order_by('-id')
        SellBascket_list = list(SellBascket.values())
        aboutus_info = aboutus.objects.all()
        centercontactus_info = centercontactus.objects.all()
        check_zero_procuts_count = productsparamerts.objects.all()

        sellbascketCount = sellbascket.objects.filter(Create_Uid=request.user.id, status=0).count()
        fehrests = productsgroups.objects.all()
        spg, spgid, spgt, spgtr ,spgtr2 = headermenu()

        fhlogo = firstpagelogo.objects.all()
        result = None
        check_zero_procuts_count = 0
        aboutus_info = '0'
        centercontactus_info = '0'
        check_zero_procuts_count = '0'
        totalsumsell = 0
        max_min_price_info_result = 0

        if 'search' in request.GET or zero_serch == 'enter_key_down':
            search_box = self.request.GET.get('search')
            qs = productsparamerts.objects.all() or products.objects.all()
            if search_box and zero_serch == None:
                if products.objects.filter(name__icontains=search_box).values_list('id', flat=True) \
                or productscolors.objects.filter(color__contains=search_box).values_list('id', flat=True) \
                or productssize.objects.filter(size__contains=search_box).values_list('id', flat=True) \
                or productsparamerts.objects.filter(paramserial__contains=search_box).values_list('id', flat=True):
                    result = qs.filter(pid_id=products.objects.filter(name__icontains=search_box).values_list('id', flat=True).order_by('id')[:1]) or \
                    qs.filter(cid_id=productscolors.objects.filter(color__contains=search_box).values_list('id', flat=True).order_by('id')[:1]) or \
                    qs.filter(sid_id=productssize.objects.filter(size__contains=search_box).values_list('id', flat=True).order_by('id')[:1])  or \
                    qs.filter(paramserial=str(productsparamerts.objects.filter(paramserial__contains=search_box).values_list('id', flat=True).order_by('id')[:1]))
                else:
                    result = ''
            else:
                result = 0
                data = {
                    'enter_key_down': 'enter_key_down'
                }
                return JsonResponse(data)

            max_p_price = []
            if result != 0:
                for result_products in result:
                    param_best = productsparamerts.objects.filter(pid_id= result_products.id).values_list('productprice', 'pid', 'takhfifprice', 'productinventory_remain', 'takhfif').order_by('productprice')
                    max_p_price.append(param_best)
                max_min_price_info_result= []
                for mpp in max_p_price:
                    if len(mpp) > 0:
                        remain_sum = productsparamerts.objects.filter(pid_id = mpp[0][1]).aggregate(sum=Sum('productinventory_remain'))['sum']
                        max_product_price = max(list(mpp))
                        min_product_price = min(list(mpp))
                        product_price_select = mpp[0][1]
                        product_price_after_takhfif = mpp[0][2]
                        product_productinventory_remain = mpp[0][3]
                        max_min_price_info_result.append((product_price_select,max_product_price[0],min_product_price[0], product_price_after_takhfif, product_productinventory_remain, remain_sum, max_product_price[2], int(max_product_price[4])))

                totalsum = 0
                totalsumsell = []
                totalcount = 0
                pct = sellbascket.objects.filter(Create_Uid=request.user.id, status=0)
                for t in pct:
                    total = t.pcount * t.pprise
                    totalsum += total
                    totalcount += t.pcount
                    totalsumsell = totalsum
        result_products = products.objects.all()
        result_color = productscolors.objects.all()
        result_size = productssize.objects.all()
        return render(request, 'serach_result.html', {'fhlogo': fhlogo, 'result': result, 'fehrests': fehrests,'sellbascketCount': sellbascketCount,
                                                        'spg': spg, 'spgt': spgt, 'spgtr': spgtr, 'result_products': result_products, 'result_color': result_color,
                                                        'spgtr2': spgtr2,'check_zero_procuts_count': check_zero_procuts_count,'result_size': result_size,
                                                        'aboutus_info': aboutus_info, 'centercontactus_info': centercontactus_info
                                                        ,'totalsumsell' : totalsumsell, 'max_min_price_info_result': max_min_price_info_result})



class AddBascket(View):
    def get(self, request):
        sumBascketPriceoff = 0
        totalsumsell = 0
        priceoff = 0
        sizeid_bycolor = 0
        colorid_bysize = 0
        sizeid_bysize = 0

        id1 = request.GET.get('pid', None)

        
        sellbascketCount = sellbascket.objects.filter(Create_Uid=request.user.id, status=0).count()
        colorid_bycolor = request.GET['getcoid']
        sizeid_bycolor = request.GET['getsiid']
        colorid_bysize = request.GET['get_coid']
        sizeid_bysize = request.GET['get_siid']
        getproductid = request.GET['getproductid']

        priceoff , sumBascketPriceoff , totalsumsell, off, orginalprice, totalcount= makepreiceoff(request ,getproductid ,colorid_bycolor, sizeid_bycolor, colorid_bysize, sizeid_bysize)

        userid = request.user.id
        sellbascketcountsells = 0
        numberofgoods = 0
        AddedBefor = 0
        if products.objects.get(id=id1).goods:
            AddedBefor_check = sellbascket.objects.filter(Create_Uid=request.user.id, pid_id=id1, status=0, colorid_bycolor=colorid_bycolor, sizeid_bycolor=sizeid_bycolor, colorid_bysize=colorid_bysize, sizeid_bysize=sizeid_bysize)
            if AddedBefor_check:
                AddedBefor = 1
                
            sellbascket_check = sellbascket.objects.filter(pid_id=id1, status=0, colorid_bycolor=colorid_bycolor, sizeid_bycolor=sizeid_bycolor, colorid_bysize=colorid_bysize, sizeid_bysize=sizeid_bysize)
            for a in sellbascket_check:
                sellbascketcountsells += a.pcount

            
            if colorid_bycolor != '0':
                numberofgoods = productsparamerts.objects.get(pid_id=id1,cid_id=colorid_bycolor, sid_id=sizeid_bycolor).productinventory_remain
            else:
                numberofgoods = productsparamerts.objects.get(pid_id=id1,cid_id=colorid_bysize, sid_id=sizeid_bysize).productinventory_remain

        if numberofgoods <= 0:
            data = {
                'numberofgoods': numberofgoods
                }
            return JsonResponse(data)
        else:
            if not AddedBefor_check:
                obj = sellbascket.objects.create(
                    pid_id=id1,
                    status=0,
                    pprise = priceoff,
                    colorid_bycolor = colorid_bycolor,
                    sizeid_bycolor = sizeid_bycolor,
                    colorid_bysize = colorid_bysize,
                    sizeid_bysize = sizeid_bysize,
                    orginalprice = orginalprice,
                    pdiscount = off,
                    Create_Uid=userid,
                    Update_Uid=userid
                )
        i = '0'
        Bascket = {}
        if not AddedBefor_check:
            i = products.objects.get(id=obj.pid_id).img1
            Bascket = {'id': obj.id, 'pid': obj.pid_id, 'name': products.objects.get(
                id=obj.pid_id).name, 'img1': str(i), 'Create_Uid': obj.Create_Uid, 'pcount': 1}
        
        sumoff = 0
        data = {
            'Bascket': Bascket, 'sellbascketCount': sellbascketCount, 'sumoff' : sumoff ,'priceoff': priceoff, 'sumBascketPriceoff': sumBascketPriceoff, 'numberofgoods': numberofgoods, 'AddedBefor': AddedBefor, 'totalsumsell': totalsumsell
        }
        return JsonResponse(data)


class Bascketdelete(View):
    def get(self, request):
        id1 = request.GET.get('id', None)
        name = products.objects.get(id=sellbascket.objects.get(id=id1, status=0).pid_id).name
        sellbascket.objects.get(id=id1).delete()
        sellbascketCount = sellbascket.objects.filter(Create_Uid=request.user.id).count()
        sumBascketPriceoff=[]
        i=0
        sumoff = 0
        for p in sellbascket.objects.filter(Create_Uid=request.user.id, status=0):
            sumBascketPriceoff.append(0)
            sumBascketPriceoff[i] = p.pprise*p.pcount
            i+=1
        data = {
            'deleted': True, 'sellbascketCount': sellbascketCount, 'sumBascketPriceoff': sum(sumBascketPriceoff), 'name': name, 'sumoff': sumoff
        }
        return JsonResponse(data)


class AddFavorite(View):
    def get(self, request):
        id1 = request.GET.get('pid', None)
        userid = request.user.id
        if productdetails.objects.filter(Create_Uid=request.user.id, pid_id=id1, favorite=0):
            obj = productdetails.objects.get(
                Create_Uid=request.user.id, pid_id=id1)
            obj.favorite = 1
            obj.Update_Uid = userid
            obj.save()
        elif productdetails.objects.filter(Create_Uid=request.user.id, pid_id=id1, favorite=1):
            return JsonResponse({})
        else:
            obj = productdetails.objects.create(
                pid_id=id1,
                favorite=1,
                Create_Uid=userid,
                Update_Uid=userid
            )
        i = products.objects.get(id=obj.pid_id).img1
        Favorite = {'id': obj.id, 'pid': obj.pid_id, 'name': products.objects.get(
            id=obj.pid_id).name, 'img1': str(i), 'Create_Uid': obj.Create_Uid}
        favoriteCount = productdetails.objects.filter(
            Create_Uid=request.user.id, favorite=1).count()

        data = {
            'Favorite': Favorite, 'favoriteCount': favoriteCount
        }
        return JsonResponse(data)


class removepic(View):
    def get(self, request):
        id1 = request.GET.get('id', None)
        img = request.GET.get('img', None)
        if img == 'img1':
            b = products.objects.filter(id=id1)
            b.update(img1='')
        elif img == 'img2':
            b = products.objects.filter(id=id1)
            b.update(img2='')
        elif img == 'img3':
            b = products.objects.filter(id=id1)
            b.update(img3='')
        elif img == 'img4':
            b = products.objects.filter(id=id1)
            b.update(img4='')
        elif img == 'img5':
            b = products.objects.filter(id=id1)
            b.update(img5='')
        elif img == 'img6':
            b = products.objects.filter(id=id1)
            b.update(img6='')
        data = {
            'img': img
        }
        return JsonResponse(data)


class removepicBanner(View):
    def get(self, request):
        id1 = request.GET.get('id', None)
        img = request.GET.get('img', None)
        if img == 'baner1':
            b = firstpagebaners.objects.filter(id=id1)
            b.update(baner1='')
        elif img == 'img2':
            b = firstpagebaners.objects.filter(id=id1)
            b.update(banner1='')
        elif img == 'img3':
            b = firstpagebaners.objects.filter(id=id1)
            b.update(banner1='')
        elif img == 'img4':
            b = products.objects.filter(id=id1)
            b.update(img4='')
        elif img == 'img5':
            b = products.objects.filter(id=id1)
            b.update(img5='')
        elif img == 'img6':
            b = products.objects.filter(id=id1)
            b.update(img6='')
        data = {
            'img': img
        }
        return JsonResponse(data)


class Favoritedelete(View):
    def get(self, request):
        id1 = request.GET.get('id', None)
        name = products.objects.get(
            id=productdetails.objects.get(id=id1).pid_id).name
        productdetails.objects.get(id=id1).delete()
        favoriteCount = productdetails.objects.filter(
            Create_Uid=request.user.id, favorite=1).count()
        
        data = {
            'deleted': True, 'favoriteCount': favoriteCount,  'name': name
        }
        return JsonResponse(data)


class usersarticle(View):
    models = SPArticle, SPFactor

    def get(self, request):
        userid = request.user.customersid_id
        factorsid = SPFactor.objects.all().filter(CustomerId=userid)
        userarticles = SPArticle.objects.all().filter(SPId__in=factorsid)
        return render(request, 'userarticles.html', {'userarticles': userarticles, 'factorsid': factorsid})


class userspayarticle(View):
    models = PayRcv, Check

    def get(self, request):
        userid = request.user.customersid_id
        userarticles = Check.objects.all().filter(CId=userid)
        return render(request, 'userpayarticle.html', {'userarticles': userarticles})


class usersfactors(View):
    models = SPFactor, SPArticle

    def get(self, request):
        fcontact = centercontactus.objects.all()
        userid = request.user.id
        UserInfo = User.objects.all().filter(id=userid)
        userid = request.user.customersid_id
        spid = SPFactor.objects.filter(
            CustomerId=userid).values_list('id', flat=True)
        # totalcount = str(SPFactor.objects.all().filter(
        #     CustomerId=userid).filter().count())
        script1 = "select 0 as id, case when FactorType like 'خريد' then 'فروش' when FactorType like 'فروش' then 'فاکتور' when  FactorType like 'رسيد پرداخت' then 'رسید پرداخت' when FactorType like 'رسید دریافت' then  'رسيد دریافت'  when FactorType like 'برگشت از خريد' then  'برگشت از فروش' when FactorType like 'برگشت از فروش' then  'فاکتور برگشتی' end as FactorType,(select count(*) from SPArticle spa where spa.spid in (select id from SPFactor where FactorType=spf.FactorType and CustomerId  ={userid})) as totalcount,(select SUM(ATotal) from SPArticle spa where spa.spid in (select id from SPFactor where FactorType=spf.FactorType and CustomerId  ={userid})) as totalsale from SPFactor spf where CustomerId  ={userid} group by FactorType".format(
            userid=userid)
        print(script1)
        totalsale = SPArticle.objects.raw(script1)

        datein1 = request.GET.get('date1')
        datein2 = request.GET.get('date2')
        if request.method == 'GET':
            if datein1 == None or datein2 == None:
                query = """with tmp as(select id,1 as t,CustomerId,FactorNo,FactorType,cast(SPDate as date) as SPDate,
                CustomerName,Discount,Expense,Total from SPfactor union all select id,0 as t,CustomerId,PNo,PayType,
                cast(PDate as date) as SPDate,RAB0,0 as Discount,0 as Expense,PCValue from PayRcv)select id, 
                case 
                when FactorType like 'خريد' then 'فروش' 
                when FactorType like 'فروش' then 'خريد' 
                when  FactorType like 'رسيد پرداخت' then 'رسید پرداخت' 
                when FactorType like 'رسید دریافت' then  'رسيد دریافت'  
                when FactorType like 'برگشت از خريد' then  'برگشت از فروش' 
                when FactorType like 'برگشت از فروش' then  'برگشت از خريد' end as FactorType,
                CustomerId,FactorNo,SPDate,CustomerName,Discount,Expense,Total,t 
                from tmp where CustomerId is not null and CustomerId={userid}order by SPDate""".format(userid=userid)
                datefilter = SPFactor.objects.raw(query)
            else:
                datef1 = datein1.replace("-", "/")
                datef2 = datein2.replace("-", "/")
                query = """with tmp as(select id,1 as t,CustomerId,FactorNo,
                    FactorType,cast(SPDate as date) as SPDate,
                    CustomerName,Discount,Expense,Total from SPfactor union all select id,0 as t,CustomerId,PNo,
                    PayType,cast(PDate as date) as SPDate,RAB0,0 as Discount,0 as Expense,PCValue from PayRcv)select id,
                    case 
                    when FactorType like 'خريد' then 'فروش'
                    when FactorType like 'فروش' then 'خريد' 
                    when  FactorType like 'رسيد پرداخت' then 'رسید پرداخت'
                    when FactorType like 'رسید دریافت' then  'رسيد دریافت'  
                    when FactorType like 'برگشت از خريد' then  'برگشت از فروش' 
                    when FactorType like 'برگشت از فروش' then  'برگشت از خريد' end as FactorType,
                    CustomerId,FactorNo,SPDate,CustomerName,Discount,Expense,Total,t 
                    from tmp where CustomerId is not null and spdate between dbo.ShamsitoMiladi('{date1}') 
                    and dbo.ShamsitoMiladi('{date2}') and CustomerId={userid}
                    order by SPDate""".format(date1=datef1, date2=datef2, userid=userid)
                datefilter = SPFactor.objects.raw(query)

        spg, spgid, spgt, spgtr ,spgtr2 = headermenu()
        testform = filterdate1(request.GET)
        return render(request, 'dashboard.html', {'fcontact': fcontact, 'UserInfo': UserInfo, 'testform': testform, 'spg': spg, 'spgt': spgt, 'spgtr': spgtr, 'spgtr2': spgtr2, 'totalsale': totalsale,  'datefilter': datefilter, 'datein1': datein1, 'datein2': datein2})


@login_required(login_url='login')
def factordetail(request, id):
    fuserid = request.user.customersid_id
    fd = SPArticle.objects.all().filter(SPId=id)
    fno = SPFactor.objects.all().filter(id=id)
    Amountsum = SPArticle.objects.filter(customersid=fuserid).filter(
        SPId=id).aggregate(Sum=Sum('Amount'))['Sum']
    UnitPricesum = SPArticle.objects.filter(customersid=fuserid).filter(
        SPId=id).aggregate(Sum=Sum('UnitPrice'))['Sum']
    VTaxsum = SPArticle.objects.filter(customersid=fuserid).filter(
        SPId=id).aggregate(Sum=Sum('VTax'))['Sum']
    VChargesum = SPArticle.objects.filter(customersid=fuserid).filter(
        SPId=id).aggregate(Sum=Sum('VCharge'))['Sum']
    Percentagesum = SPArticle.objects.filter(customersid=fuserid).filter(
        SPId=id).aggregate(Sum=Sum('Percentage'))['Sum']
    ATotalsum = SPArticle.objects.filter(customersid=fuserid).filter(
        SPId=id).aggregate(Sum=Sum('ATotal'))['Sum']
    return render(request, 'factordetail.html', {'fno': fno, 'fd': fd, 'Amountsum': Amountsum,
                                                 'UnitPricesum': UnitPricesum, 'VTaxsum': VTaxsum, 'VChargesum': VChargesum, 'Percentagesum': Percentagesum,
                                                 'ATotalsum': ATotalsum})


@login_required(login_url='login')
def PayRcvDetail(request, id):
    customersid = request.user.id
    datefilter = Check.objects.raw(
        'select * from dbo.[Check] c inner join PayRcvCheck pr on c.id2=pr.CheckId inner join PayRcv p on p.id=pr.PayRcvId where p.id = {id}'.format(id=id))
    return render(request, 'PayRcvDetail.html', {'datefilter': datefilter})


@login_required(login_url='login')
def userchangeinfo(request):
    success = []
    userid = request.user.id
    edit_user = get_object_or_404(User, pk=userid)
    user_name = request.POST.get('username', None)
    userinfo = userinfoupdate(request.POST, request.FILES, instance=edit_user)
    if request.method == 'POST':
        if userinfo.is_valid():
            userinfo.save()
            success.append('کاربر گرامی اطلاعات شما با موفقیت ذخیره گردید .')
            userinfo = userinfoupdate(instance=edit_user)
            user_name = User.objects.filter(id=userid).values_list('username', flat=True)
            return render(request, 'partials/userschangeinfo.html', {'user_name': user_name,'userinfo': userinfo, 'success': success})
    userinfo = userinfoupdate(instance=edit_user)
    user_name = User.objects.filter(id=userid).values_list('username', flat=True)
    return render(request, 'partials/userschangeinfo.html', {'user_name': user_name,'userinfo': userinfo, 'success': success})


class AddComment(View):
    def get(self, request):
        Head1 = request.GET.get('Head', None)
        com1 = request.GET.get('com', None)
        pid1 = request.GET.get('pid', None)
        userid = request.user.id

        obj = comment.objects.create(
            pid_id=pid1,
            Head=Head1,
            com=com1,
            Create_Uid=userid,
            Update_Uid=userid
        )
        Create_Uid = request.user.first_name

        alarm = 'این نظر پس از تایید توسط مدیر سیستم در سایت نمایش داده خواهد شد.'

        comment1 = {
            'id': obj.id, 'pid': obj.pid_id, 'Head': obj.Head, 'com': obj.com, 'Create_Uid': obj.Create_Uid, 'Create_Date': obj.Create_Date
        }

        data = {
            'comment1': comment1, 'Create_Uid': Create_Uid, 'alarm': alarm,
        }
        return JsonResponse(data)


class AddStar(View):
    def get(self, request):
        selected = request.GET.get('selected', None)
        star = {'star1': request.GET.get('stars1', None),
                'star2': request.GET.get('stars2', None),
                'star3': request.GET.get('stars3', None),
                'star4': request.GET.get('stars4', None),
                'star5': request.GET.get('stars5', None)}[str(selected)]

        uid = request.user.id
        pid = request.GET.get('pid', None)

        if not stars.objects.filter(pid=pid, uid=uid).first():
            obj = stars.objects.create(
                stars=star,
                pid=products.objects.get(id=pid),
                uid=uid,
            )
        else:
            obj = stars.objects.filter(pid=pid, uid=uid).update(
                stars=star
            )

        StarSum = stars.objects.filter(uid=request.user.id, pid_id=pid).values(
            'pid_id').order_by('pid_id').annotate(total_stars=Sum('stars'))
        Starcount = stars.objects.filter(uid=request.user.id, pid_id=pid).values(
            'pid_id').order_by('pid_id').annotate(count=Count('pid_id'))
        StarAvarage = (StarSum[0]['total_stars']/(Starcount[0]['count']*5))*100
        stars1 = {
            'StarAvarage': StarAvarage
        }

        data = {
            'stars1': stars1
        }
        return JsonResponse(data)


class commentAccept(View):
    def get(self, request):
        id1 = request.GET.get('id', None)

        obj = comment.objects.filter(id=id1).update(
            status=1, Update_Uid=request.user.id)

        data = {

        }
        return JsonResponse(data)


class commentReject(View):
    def get(self, request):
        id1 = request.GET.get('id', None)

        obj = comment.objects.filter(id=id1).update(
            status=2, Update_Uid=request.user.id)

        data = {

        }
        return JsonResponse(data)


class commentDelete(View):
    def get(self, request):
        id1 = request.GET.get('id', None)

        obj = comment.objects.filter(id=id1).delete()

        data = {

        }
        return JsonResponse(data)


class UpdateCount(View):
    def get(self, request):
        newcount = request.GET.get('newcount')
        pid = request.GET.get('pid', None)
        id = request.GET.get('id', None)
        obj = sellbascket.objects.get(id=id, status=0)
        colorid_bycolor = sellbascket.objects.get(pid_id=pid, id = id).colorid_bycolor
        sizeid_bycolor = sellbascket.objects.get(pid_id=pid, id = id).sizeid_bycolor
        colorid_bysize = sellbascket.objects.get(pid_id=pid, id = id).colorid_bysize
        sizeid_bysize = sellbascket.objects.get(pid_id=pid, id = id).sizeid_bysize

        numberofgoods = 0

        if int(colorid_bycolor) != 0:
            numberofgoods = productsparamerts.objects.get(pid_id=pid,cid_id=colorid_bycolor, sid_id=sizeid_bycolor).productinventory_remain
        else:
            numberofgoods = productsparamerts.objects.get(pid_id=pid,cid_id=colorid_bysize, sid_id=sizeid_bysize).productinventory_remain

        isUpdated = 1
        if int(numberofgoods) < int(newcount):
            isUpdated = 0
            newcount = min(obj.pcount, numberofgoods)
        obj.pcount = newcount
        obj.save()

        price = 0
        discount_on_finalcheckout_price = price_off()

        priceoff , sumBascketPriceoff , totalsumsell, off, orginalprice, totalcount= makepreiceoff(request ,pid ,colorid_bycolor, sizeid_bycolor, colorid_bysize, sizeid_bysize)

        pay_after_laastpay_with_cost = 0
        send_price = 0
        pay_after_laastpay = 0
        max_price = 0
        send_count= 0
        DMaxType = 0
        if len(discount_on_finalcheckout_price) > 0:
            send_price = int(discount_on_finalcheckout_price[2])
            send_count = int(discount_on_finalcheckout_price[1])
            max_price = int(discount_on_finalcheckout_price[0])
            DMaxType = int(discount_on_finalcheckout_price[3])

            pay_after_laastpay = int(sumBascketPriceoff) + int(send_price)
            pay_after_laastpay_with_cost = int(sumBascketPriceoff) + int(send_price)
            if int(sumBascketPriceoff) >= int(max_price) or int(totalcount) >= int(send_count):
                pay_after_laastpay = int(sumBascketPriceoff)

        Newtotalcost = sellbascket.objects.get(id=id).pcount * priceoff 
        NewTotalOff = sellbascket.objects.get(id=id).pcount * off

        # vatprice = 0
        # pay_after_laastpay_vat = 0
        # pay_after_laastpay_vat = str(((int(sumBascketPriceoff))*9)/100)

        # vatprice = pay_after_laastpay_vat.split('.0')
        # int_pay_after_laastpay_vat = int(vatprice[0])
        int_pay_after_laastpay_vat = 0
        max_price_with_vat_cost = 0
        max_price_with_vat = 0
        
        if DMaxType == 1:
            if int(max_price) > 0 and int(totalsumsell) >= int(max_price):
                max_price_with_vat = int(totalsumsell) + int(int_pay_after_laastpay_vat)
                ersalcost = 0
            elif int(max_price) > 0 and  int(totalsumsell) < int(max_price):
                max_price_with_vat_cost = int(totalsumsell) + int(send_price) + int(int_pay_after_laastpay_vat)
                ersalcost = send_price
        elif DMaxType == 2: 
            if int(send_count) > 0 and int(totalcount) >= int(send_count):
                max_price_with_vat = int(totalsumsell) + int(int_pay_after_laastpay_vat)
                ersalcost = 0
            elif int(send_count) > 0 and  int(totalcount) < int(send_count):
                max_price_with_vat_cost = int(totalsumsell) + int(send_price) + int(int_pay_after_laastpay_vat)
                ersalcost = send_price
        elif DMaxType == 3:
            if int(max_price) > 0 and  int(send_count) > 0 and int(totalsumsell) >= int(max_price) or int(totalcount) >= int(send_count):
                max_price_with_vat = int(totalsumsell) + int(int_pay_after_laastpay_vat)
                ersalcost = 0
            elif int(max_price) > 0 and  int(send_count) > 0 and int(totalsumsell) < int(max_price) or int(totalcount) <= int(send_count):
                max_price_with_vat_cost = int(totalsumsell) + int(send_price) + int(int_pay_after_laastpay_vat)
                ersalcost = send_price
        data = {
            'send_price': send_price,'NewTotalOff': NewTotalOff, 
            'sumoff': off,'sumBascketPriceoff': sumBascketPriceoff, 
            'Newtotalcost': Newtotalcost, 'newcount': newcount,
            'isUpdated': isUpdated, 'send_count': int(send_count),
            'int_pay_after_laastpay_vat': int_pay_after_laastpay_vat,
            'max_price_with_vat_cost': max_price_with_vat_cost,
            'max_price_with_vat': max_price_with_vat,
            'pay_after_laastpay_with_cost': pay_after_laastpay_with_cost,
            'max_price': int(max_price), 'totalcount': int(totalcount),
            'pay_after_laastpay': pay_after_laastpay,
            'totalsumsell': totalsumsell,'ersalcost': ersalcost,
            'off': off,'DMaxType' : int(DMaxType),
            'orginalprice': orginalprice
        }
        return JsonResponse(data)


@login_required(login_url='login')
@permission_required('User.can_read_private_section')
def customerSync(request):
    with connection.cursor() as cursor:
        cursor.execute(u"exec customerSync")
    data = {}
    return HttpResponseRedirect('/dashboard/customer/report/')


@login_required(login_url='login')
@permission_required('User.can_read_private_section')
def UserSync(request):
    with connection.cursor() as cursor:
        cursor.execute(u"exec SyncUser")
    data = {}
    return HttpResponseRedirect('/dashboard/customer/report/')


@login_required(login_url='login')
@permission_required('User.can_read_private_section')
def ArticlsSync(request):
    with connection.cursor() as cursor:
        cursor.execute(u"exec ArticlsSync")
    data = {}
    return HttpResponseRedirect('/dashboard/customer/report/')


@login_required(login_url='login')
@permission_required('User.can_read_private_section')
def FactorSync(request):
    with connection.cursor() as cursor:
        cursor.execute(u"exec FactorSync")
    return HttpResponseRedirect('/dashboard/Factors/report/')


@login_required(login_url='login')
@permission_required('User.can_read_private_section')
def PayRcvSync(request):
    with connection.cursor() as cursor:
        cursor.execute(u"exec PayRcvSync")
    return HttpResponseRedirect('/dashboard/Pay/report/')


class ArticlereportJson(BaseDatatableView):
    model = SPArticle
    columns = ['', 'Id2', 'SPId', 'MerchandiseId', 'Amount', 'UnitId',
               'UnitPrice', 'SPADesc', 'VTax', 'VCharge', 'Percentage', 'ATotal']
    order_columns = ['', 'Id2', 'SPId', 'MerchandiseId', 'Amount',
                     'UnitId', 'UnitPrice', 'SPADesc', 'VTax', 'VCharge', 'Percentage', 'ATotal']

    def render_column(self, row, column):
        if column == 'SPDate':
            return escape('{0}'.format(MiladiToShamsi(row.SPDate)))
        else:
            return super(ArticlereportJson, self).render_column(row, column)

    def filter_queryset(self, qs):
        search = self.request.GET.get('search[value]', None)
        #FactorNo = self.request.GET.get('FactorNo', None)
        if search:
            qs = qs.filter(Q(Id2__icontains=search) | Q(SPId__icontains=search) | Q(MerchandiseId__icontains=search) | Q(Amount__icontains=search) | Q(UnitId__icontains=search) | Q(UnitPrice__icontains=search)
                           | Q(SPADesc__icontains=search) | Q(VTax__icontains=search) | Q(VCharge__icontains=search) | Q(Percentage__icontains=search))
        filter_customer = self.request.GET.get('FactorNo', None)
        return qs


class lastnewspage(generic.ListView):
    model = lastnews
    context_object_name = 'lnp'
    template_name = 'last_news.html'
    queryset = lastnews.objects.all()


class lastnewspageone(generic.ListView):
    model = lastnews

    def get(self, request, id):
        lnp = lastnews.objects.all().filter(id=id)
        id = 0
        return render(request, 'last_news.html', {'lnp': lnp, 'id': id})


class advancedsearchProducts(generic.ListView):
    models = products
    template_name = 'advancedsearchProducts.html'

    def get(self, request, id, *args, **kwargs):
        context = locals()
        allchecked = productsgroups.objects.filter(id=id).values_list('id')
        allcheckedList = []
        for a in allchecked:
            allcheckedList.append(a[0])
        context['aboutus_info'] = aboutus.objects.all()
        context['centercontactus_info'] = centercontactus.objects.all()
        context['allchecked'] = allchecked
        context['id'] = id
        context['sliders'] = insideslider.objects.all()
        context['khabar'] = lastnews.objects.all().order_by('-id')[:3]
        bestssale = sellbascket.objects.raw("""
            select a.pid_id as id,sum(a.pcount) as count,b.serial ,b.img1,b.name,
			case when 
                b.goods<>False
                then 
                b.numberofgoods- (select COALESCE(SUM(sb.pcount),0)
                                from sellbascket sb 
                                where sb.pid_id=a.pid_id and sb.status=1)
            else 0 
            end as existing,


            (select name from productsbrands where id=b.brand_id) as brand 

            from sellbascket a 
            join products b on a.pid_id=b.id 
            where b.id > 0 and a.id > 0
            group by pid_id,b.serial ,b.img1,b.name,b.group_id,b.brand_id , b.goods , b.numberofgoods
            order by sum(a.pcount) desc
            limit 4
            """.format(id=id))

        context['bestssale'] = bestssale


        bestssale2 = sellbascket.objects.values('pid').annotate(count=Count('pid')).order_by('count')
        StarAvarage_percent = []
        for pid in bestssale2:
            star ,  StarAvarage , Starcount , StarSum , pid= makestars(request, pid['pid'])
            StarAvarage_percent.append((pid,StarAvarage))
        context['StarAvarage_percent'] = StarAvarage_percent

        max_p_price = []
        for bsid in bestssale2:
            param_best = productsparamerts.objects.filter(pid_id= bsid['pid']).values_list('productprice', 'pid', 'takhfifprice', 'productinventory_remain', 'takhfif').order_by('productprice')
            max_p_price.append(param_best)
        max_min_price_info_bestsell = []
        for mpp in max_p_price:
            if len(mpp) > 0:
                remain_sum = productsparamerts.objects.filter(pid_id = mpp[0][1]).aggregate(sum=Sum('productinventory_remain'))['sum']
                max_product_price = max(list(mpp))
                min_product_price = min(list(mpp))
                product_price_select = mpp[0][1]
                product_price_after_takhfif = mpp[0][2]
                product_productinventory_remain = mpp[0][3]
                max_min_price_info_bestsell.append((product_price_select,max_product_price[0],min_product_price[0], product_price_after_takhfif, product_productinventory_remain, remain_sum, max_product_price[2], int(max_product_price[4])))

        context['max_min_price_info_bestsell'] = max_min_price_info_bestsell
        context['advancb'] = firstpagebaners.objects.all()
        context['fcontact'] = centercontactus.objects.all()
        context['spdesc'] = productsgroups.objects.all().filter(id=id, id__gt = 0)
        context['fhlogo'] = firstpagelogo.objects.all().order_by('-id')[:1]
        context['productsgroups'] = productsgroups.objects.filter(gparentid=0)
       
        context['productsgroups1'] = productsgroups.objects.filter(id=id, glevel__gt=0)
        context['productsgroups2'] = productsgroups.objects.filter(Q(id=id)| Q(gparentid=id))
        productslist =0
        productslist_group = []
        productslist_g = productsgroups.objects.filter(Q(gparentid=id)| Q(id=id)).values_list('id', flat=True)
        if len(productslist_g)>0:
            for products_list_g in productslist_g:
                productslist_group.append(products_list_g)

        productslist_selected = []
        productslist = products.objects.filter(group_id__in=productslist_group).order_by('-id')[:24]
        if len(productslist) > 0:
            for pro_list in productslist:
                productslist_selected.append(pro_list)

        max_p_price = []
        for psid in productslist_selected:
            if psid:
                param_best = productsparamerts.objects.filter(pid_id = psid.id).values_list('productprice', 'pid', 'takhfifprice', 'productinventory_remain', 'takhfif').order_by('productprice')
                if len(param_best)> 0:
                    max_p_price.append(param_best)
                    
        max_min_price_info_group_select = []
        for mpp in max_p_price:
            if len(mpp) > 0:
                remain_sum = productsparamerts.objects.filter(pid_id = mpp[0][1]).aggregate(sum=Sum('productinventory_remain'))['sum']
                max_product_price = max(list(mpp))
                min_product_price = min(list(mpp))
                product_price_select = mpp[0][1]
                product_price_after_takhfif = mpp[0][2]
                product_productinventory_remain = mpp[0][3]
                max_min_price_info_group_select.append((product_price_select,max_product_price[0],min_product_price[0], product_price_after_takhfif, product_productinventory_remain, remain_sum, max_product_price[2], int(int(max_product_price[4]))))

        context['max_min_price_info_group_select'] = max_min_price_info_group_select

        productslistKol = products.objects.raw('with tmp0 as (select * from productsgroups  where  id in ({Groups1})union all select * from productsgroups a where glevel=3 and gparentid in ({Groups1}) and gparentid not in (select gparentid from productsgroups where id in ({Groups1}) and glevel=3 )union all select * from productsgroups a where glevel=2 and gparentid in ({Groups1}) and gparentid not in (select gparentid from productsgroups where id in ({Groups1}) and glevel=2 )),tmp as(select * from productsgroups  where  id in ({Groups1}) union all select * from productsgroups a where glevel=3 and gparentid in ({Groups1}) and gparentid not in (select gparentid from productsgroups where id in ({Groups1}) and glevel=3 )union all select * from productsgroups a where glevel=2 and gparentid in ({Groups1}) and id not in (select gparentid from productsgroups where id in ({Groups1}) and glevel=3 ) union all select * from productsgroups a where glevel=3 and gparentid in (select id from tmp0) and gparentid not in (select gparentid from productsgroups where id in (select id from tmp0) and glevel=3 ))select  * from products where id <> 0 and group_id in (select id from tmp) order by group_id'.format(Groups1=id))

        count_products = productslist.count()

        StarAvarage_percent = []
        for pid in productslist_selected:
            star ,  StarAvarage , Starcount , StarSum , pid= makestars(request, pid.id)
            StarAvarage_percent.append((pid,StarAvarage))

        context['StarAvarage_percent'] = StarAvarage_percent
        context['products'] = productslist_selected
        productsFilteredCount = 0
        for a in range(count_products):
            productsFilteredCount += 1
        productsFilteredCountKol = 0
        for a in productslistKol:
            productsFilteredCountKol += 1
        context['productsCount'] = productsFilteredCount
        context['productsCountKol'] = productsFilteredCountKol

        id1 = productsgroups.objects.filter(id__gt=0, id=id).values_list('gparentid', flat=True)
        products_chose_with_group = products.objects.filter(Q(group_id=id) | Q(group__gparentid__in=id1) , Q(id__gt= 0)).values_list('brand_id', flat=True)

        brands = 0
        for p_c_w_g in products_chose_with_group:
            brands = productsbrands.objects.filter(id=p_c_w_g)

        context['productsbrands'] = brands

        group_cname_id = productsgroups.objects.filter(id__gt=0, id = id).values_list('cname1_id', 'cname2_id', 'cname3_id')

        cat_group_cname_1 = productscategory.objects.all().filter(id=group_cname_id[0][0])
        pc1 = '0'
        if cat_group_cname_1 != None:
            for cat_group_id_cname_1 in cat_group_cname_1:
                pc1 = productscategory.objects.all().filter(cparentid=cat_group_id_cname_1.id)

        cat_group_cname_2 = productscategory.objects.all().filter(id=group_cname_id[0][1])
        pc2 = '0'
        if cat_group_cname_2 != None:
            for cat_group_id_cname_2 in cat_group_cname_2:
                pc2 = productscategory.objects.all().filter(cparentid=cat_group_id_cname_2.id)

        cat_group_cname_3 = productscategory.objects.all().filter(id=group_cname_id[0][2])
        pc3 = '0'
        if cat_group_cname_3 != None:
            for cat_group_id_cname_3 in cat_group_cname_3:
                pc3 = productscategory.objects.all().filter(cparentid=cat_group_id_cname_3.id)

        context['cat_group_cname_1'] = cat_group_cname_1
        context['cat_group_cname_2'] = cat_group_cname_2
        context['cat_group_cname_3'] = cat_group_cname_3

        context['pc1'] = pc1
        context['pc2'] = pc2
        context['pc3'] = pc3

        spg, spgid, spgt, spgtr ,spgtr2 = headermenu()
        context['spg'] = spg
        context['spgid'] = spgid
        context['spgt'] = spgt
        context['spgtr'] = spgtr
        context['spgtr2'] = spgtr2
        totalsum = 0
        totalsumsell = []
        totalcount = 0
        pct = sellbascket.objects.filter(Create_Uid=request.user.id, status=0)
        for t in pct:
            total = t.pcount * t.pprise
            totalsum += total
            totalcount += t.pcount
            totalsumsell = totalsum
        context['totalsumsell'] = totalsumsell
        context['check_zero_procuts_count'] = productsparamerts.objects.all()

        error_list = []
        form = LoginForm(request.POST)
        if form.is_valid() and request.user.is_authenticated == False:
            cd = form.cleaned_data
            if User.objects.filter(username=cd['username']):
                if authenticate(username=cd['username'], password=cd['password']):
                    user = authenticate(
                        username=cd['username'], password=cd['password'])
                    if user is not None:
                        if user.is_active:
                            login(request, user)
                            return redirect(request.path)
                        error_list.append('کاربر وارد شده غیر فعال می باشد.')
                error_list.append(' کلمه عبور وارد شده اشتباه می باشد.')
            error_list.append(' نام کاربری وارد شده اشتباه می باشد.')
        
        context['form'] = form
        context['error_list'] = error_list
        return render(request, self.template_name, context)


class advancedsearchProductsJson(View):
    def get(self, request):
        Groups = request.GET.get('Groups', None)
        id = request.GET.get('id', None)
        all_group_checked = Groups[1:-1]
        if ',' in all_group_checked:
            Groups1 = all_group_checked.split(',')
        else:
            Groups1 = Groups[1:-1]
        if len(Groups1) > 0:

            Groups1Check = productsgroups.objects.filter(id__in=Groups1)
 
            Groups1 = '0'
            for a in Groups1Check:
                Groups1 += ','+str(a.id)

        if Groups[1:-1] and len(Groups1) > 0:
            Groups = Groups[1:-1].split(',')
            Groups = list(map(int, Groups))
        else:
            Groups = productsgroups.objects.filter(id=id).values_list('gparentid', flat=True)
        Brands = request.GET.get('Brands', None)
        if Brands[1:-1] and len(Brands) > 0:
            Brands = Brands[1:-1].split(',')
            Brands = list(map(int, Brands))
        else:
            Brands = ['0']

        nb_page_items = request.GET.get('nb_page_items', None)

        pc1 = request.GET.get('pc1', None)

        if len(pc1) > 0 and pc1[1:-1]:
            pc1 = pc1[1:-1].split(',')
            pc1 = list(map(int, pc1))
        else:
            pc1 = ['0']
        pc2 = request.GET.get('pc2', None)
        if len(pc2) > 0 and pc2[1:-1]:
            pc2 = pc2[1:-1].split(',')
            pc2 = list(map(int, pc2))
        else:
            pc2 = ['0']

        pc3 = request.GET.get('pc3', None)
        if len(pc3) > 0 and pc3[1:-1]:
            pc3 = pc3[1:-1].split(',')
            pc3 = list(map(int, pc3))
        else:
            pc3 = ['0']
        
        if nb_page_items != None:
            if int(nb_page_items) == 24:
                f1 = 0
                f2 = 24
            elif int(nb_page_items) == 48:
                f1 = 0
                f2 = 48
            else:
                f1 = 0
                f2 = 1000
        selectProductSort = request.GET.get('selectProductSort', None)
        f3 = 'id'
        if selectProductSort == 'quantity:desc':
            f3 = '-priceorg'
        elif selectProductSort == 'price:asc':
            f3 = 'priceorg'
        elif selectProductSort == 'price:desc':
            f3 = '-priceorg'
        elif selectProductSort == 'name:asc':
            f3 = 'name'
        elif selectProductSort == 'name:desc':
            f3 = '-name'
        elif selectProductSort == 'reference:asc':
            f3 = 'group'
        elif selectProductSort == 'reference:desc':
            f3 = '-group'
        gparent_id = productsgroups.objects.filter(id__gt=0, id=id).values_list('gparentid', flat=True)
        productsFiltered = products.objects.filter(Q(group_id=int(id)) | Q(group__gparentid=int(id))
         | Q(group_id__in=gparent_id) | Q(group__gparentid__in=gparent_id)).order_by(f3)
        

        productsFiltered = products.objects.filter(Q(group__gparentid__in=Groups) | Q(group_id__in=Groups)).order_by(f3)

        max_p_price = []
        for psid in productsFiltered:
            if psid:
                param_best = productsparamerts.objects.filter(pid_id = psid.id).values_list('productprice', 'pid', 'takhfifprice', 'productinventory_remain', 'takhfif').order_by('productprice')
                if len(param_best)> 0:
                    max_p_price.append(param_best)
                    
        max_min_price_info_advanced = []
        for mpp in max_p_price:
            if len(mpp) > 0:
                remain_sum = productsparamerts.objects.filter(pid_id = mpp[0][1]).aggregate(sum=Sum('productinventory_remain'))['sum']
                max_product_price = max(list(mpp))
                min_product_price = min(list(mpp))
                product_price_select = mpp[0][1]
                product_price_after_takhfif = mpp[0][2]
                product_productinventory_remain = mpp[0][3]
                max_min_price_info_advanced.append((product_price_select,max_product_price[0],min_product_price[0], product_price_after_takhfif, product_productinventory_remain, remain_sum, max_product_price[2], int(max_product_price[4])))

        product_brand_filter = productsFiltered.filter(Q(brand_id__in=Brands))
        if len(product_brand_filter) > 0:
            productsFiltered = product_brand_filter
        else:
            productsFiltered = productsFiltered

        product_pc1_filter = productsFiltered.filter(cname1_id__in=list(pc1))
        if len(product_pc1_filter) > 0:
            productsFiltered = product_pc1_filter
        else:
            productsFiltered = productsFiltered

        product_pc2_filter = productsFiltered.filter(cname2_id__in=list(pc2))
        if len(product_pc2_filter) > 0:
            productsFiltered = product_pc2_filter
        else:
            productsFiltered = productsFiltered

        product_pc3_filter = productsFiltered.filter(cname3_id__in=list(pc3))
        if len(product_pc3_filter) > 0:
            productsFiltered = product_pc3_filter
        else:
            productsFiltered = productsFiltered

        from django.db.models.functions import Coalesce

        productsFilteredCount = productsFiltered.all().order_by('{}'.format(f3)).count()
        productsFiltered = productsFiltered.all()[f1:f2]
        ProductsHtml = ''
        productsFilteredCountKol = 0
        for a in range(productsFilteredCount):
            productsFilteredCountKol += 1
        for a in productsFiltered:
            notexisthtml = ''
            productsFilteredCount = productsFilteredCount
            b = products.objects.filter(id=a.id)
            d = ''
            e = ''
            StarSum = stars.objects.filter(uid=request.user.id, pid_id=a.id).values(
                'pid_id').order_by('pid_id').annotate(total_stars=Sum('stars'))
            Starcount = stars.objects.filter(uid=request.user.id, pid_id=a.id).values(
                'pid_id').order_by('pid_id').annotate(count=Count('pid_id'))
            if Starcount:
                StarAvarage = (StarSum[0]['total_stars'] / (Starcount[0]['count']*5))*100
            else:
                StarAvarage = 0
                
            if not b:
                c = 0
                e = 0
            else:
                for c in b:
                    d = str(c.priceorg)+'تومان '
                    e = c.priceorg

            rname = a.name.replace(' ','-')
            for priceinfo in max_min_price_info_advanced:
                if priceinfo[0] == a.id:
                    dnone = 'd-none'
                    if priceinfo[5] < 1:
                        dnone = ''

                    specialsell = 'd-none'
                    if priceinfo[3] != 0:
                         specialsell = ''

                    nospecialsell = ''
                    if priceinfo[3] != 0:
                         nospecialsell = 'd-none'

                    ProductsHtml += """
                    <div class="col-lg-3 col-md-3 col-6 text-center mb-3" style="border-radius: 10px;">
                        <div class="border" style="border-radius: 10px;">
                            <figure class="product-media ">

                                <span style="border-radius: 5px;"
                                    class="product-label bg-danger fw-bold text-white shadow {specialsell}">فروش ویژه</span>
                                
                                <span style="border-radius: 5px;"
                                    class="product-label bg-danger fw-bold text-white shadow {dnone}">ناموجود</span>
                             

                                <a href="/category/productlist/showproduct/{id}/{pname}/">
                                    <img style="max-height: 168px; border-radius: 10px; max-width: 100%;" 
                                    src="/static/media/{img1}"
                                        alt="تصویر محصول" class="product-image">

                                    <img style="max-height: 168px; border-radius: 10px; max-width: 100%;"
                                    src="/static/media/{img2}" alt="تصویر محصول" class="product-image-hover">
                                </a>
                                {notexisthtml}

                                <div class="product-action-vertical">
                                    <div onclick="addFavorite({id},'{name}','{img1}')" class="btn-product-icon btn-wishlist btn-expandable"
                                        style="cursor: pointer;">
                                        <span>افزودن به لیست علاقه مندی</span>
                                    </div>
                                </div><!-- End .product-action -->
                                
                            </figure><!-- End .product-media -->

                            <div class="product-body"  style="border-radius: 10px;">
                                <div class="col-12">
                                    <div class="ratings">
                                        <div class="ratings-val text-center mb-2" style="width: {StarAvarage}%;">
                                        </div><!-- End .ratings-val -->
                                    </div><!-- End .ratings -->
                                    
                                </div><!-- End .rating-container -->
                               
                                
                                <h3 class="product-title text-center" >
                                    <a class="product-title text-center col-12" href="/category/productlist/showproduct/{id}/">{name}</a>
                                </h3>
   
                                <p class="col-lg-12 col-md-12 col-sm-12 col-12 fw-bold text-center text-dark h6 {nospecialsell}">{azprice} ریال</p>

                                <p class="col-lg-12 col-md-12 col-sm-12 col-12 fw-bold text-center new-price text-dark h6 {specialsell}">{takhfif} ریال</p>
                                <p class="col-lg-12 col-md-12 col-sm-12 col-12 fw-bold text-center old-price text-danger h6 {specialsell}">{azprice} ریال</p>
                                
                            </div><!-- End .product-body -->
                        </div><!-- End .product -->
                    </div>
                    """.format(id=a.id, img1=a.img1, img2=a.img2, name=a.name, notexisthtml=notexisthtml, StarAvarage=StarAvarage, pname=rname,
                    azprice=priceinfo[1], takhfif=priceinfo[7], dnone=dnone, specialsell=specialsell, nospecialsell=nospecialsell)
           
        filterd = True
        data = {
            'filterd': filterd, 'ProductsHtml': ProductsHtml, 'productsFilteredCount': productsFilteredCount, 'productsFilteredCountKol': productsFilteredCountKol
        }

        return JsonResponse(data)


class ProductCategoryJson(View):
    def get(self, request):
        Groups = request.GET.get('Groups', None)
        userid = request.user.id
        gp = productsgroups.objects.filter(id=Groups)
        for g in gp:
            d1 = productscategory.objects.filter(cparentid=g.cname1_id)
            d2 = productscategory.objects.filter(cparentid=g.cname2_id)
            d3 = productscategory.objects.filter(cparentid=g.cname3_id)
            html1 = '<option value="">-----</option>'
            categoryname1 = str(g.cname1)
            for h in d1:
                html1 += '<option value="{id}">{cname}</option>'.format(id=h.id, cname=h.cname)
            html2 = '<option value="">-----</option>'
            categoryname2 = str(g.cname2)
            for h in d2:
                html2 += '<option value="{id}">{cname}</option>'.format(id=h.id, cname=h.cname)
            html3 = '<option value="">-----</option>'
            categoryname3 = str(g.cname3)
            for h in d3:
                html3 += '<option value="{id}">{cname}</option>'.format(id=h.id, cname=h.cname)
        data = {
            'filterd': True, 'html1': html1, 'html2': html2, 'html3': html3, 'categoryname1': categoryname1, 'categoryname2': categoryname2, 'categoryname3': categoryname3}
        return JsonResponse(data)


class searchcustomerJson(View):
    def get(self, request):
        serachstatement = request.GET.get('serachstatement', None)
        if serachstatement:
            CustomersResult = Customers.objects.filter(
                Name__icontains=serachstatement)
        else:
            CustomersResult = Customers.objects.all()

        html1 = ''
        for g in CustomersResult:
            html1 += '<option value="{id}">{cname}</option>'.format(
                id=g.id, cname=g.Name)
        html1 += '<option value="">---------</option>'
        data = {
            'filterd': True, 'html1': html1}
        return JsonResponse(data)


@login_required(login_url='login')
def userschangeinfo(request):
    success = []
    userid = request.user.id
    edit_user = get_object_or_404(User, pk=userid)
    userinfo = usersinfoupdate(request.POST, request.FILES, instance=edit_user)
    if request.method == 'POST':
        if userinfo.is_valid():
            userinfo.save()
            success.append('کاربر گرامی اطلاعات شما با موفقیت ذخیره گردید .')
            userinfo = usersinfoupdate(instance=edit_user)
            id = 0
            return render(request, 'partials/userschangeinfo.html', {'id': id,'userinfo': userinfo, 'success': success})
    userinfo = usersinfoupdate(instance=edit_user)
    id = 0
    return render(request, 'partials/userschangeinfo.html', {'id': id, 'userinfo': userinfo, 'success': success})


class resetpass(View):
    def get(self, request):
        tel = request.GET.get('tel', None)
        userforget = request.GET.get('userforget', None)
        filterd = False
        if User.objects.filter(cellphone=tel, username=userforget):
            newpass = createpass(tel)
            newpasshash = make_password(newpass)
            User.objects.filter(cellphone=tel, username=userforget).update(
                password=newpasshash)
            filterd = True
        id = 0
        data = {'filterd': filterd, 'id': id}
        return JsonResponse(data)


class CancelOrders(View):
    def get(self, request):

        CancelOrdersList = request.GET.get('CancelOrdersList', None)

        OrdersList = CancelOrdersList.split(",")
        OrdersList.remove('')
        html = 'کاربر گرامی : سفارش لغو شد .'

        finalcheckout.objects.filter(TrackingCode__in=OrdersList).update(status=2)
        sellbascket.objects.filter(TrackingCode__in=OrdersList).update(status=2)
        canclorder = sellbascket.objects.filter(TrackingCode__in=OrdersList, status=2)
        for co in canclorder:
            if co.colorid_bycolor != 0:
                productid_id = co.pid_id
                color_id = co.colorid_bycolor
                size_id = co.sizeid_bycolor
                inv = co.pcount
                cancel_param = productsparamerts.objects.filter(pid_id=productid_id, cid_id=color_id, sid_id=size_id)
                for c_pa in cancel_param:
                    productsparamerts.objects.filter(pid_id=productid_id, cid_id=color_id, sid_id=size_id).update(
                    productinventory_sold=int(c_pa.productinventory_sold)-int(inv),
                    productinventory_remain=int(c_pa.productinventory_remain)+int(inv))
                    productsparaminvcharge.objects.create(
                        invpid_id = int(productid_id),
                        invcid_id = int(color_id),
                        invsid_id = int(size_id),
                        productinventory = int(c_pa.productinventory),
                        productinventory_recharge =  int(c_pa.productinventory_recharge),
                        productinventory_sold = int(c_pa.productinventory_sold)-int(inv),
                        productinventory_remain = int(c_pa.productinventory_remain)+int(inv),
                        pdesc = 'برگشت از فروش  ',
                        Create_Uid = request.user.id,
                        Update_Uid = request.user.id
                        )
            else:
                productid_id = co.pid_id
                color_id = co.colorid_bysize
                size_id = co.sizeid_bysize
                inv = co.pcount
                cancel_param = productsparamerts.objects.filter(pid_id=productid_id, cid_id=color_id, sid_id=size_id)
                for c_pa in cancel_param:
                    productsparamerts.objects.filter(pid_id=productid_id, cid_id=color_id, sid_id=size_id).update(
                    productinventory_sold=int(c_pa.productinventory_sold)-int(inv),
                    productinventory_remain=int(c_pa.productinventory_remain)+int(inv))
                    productsparaminvcharge.objects.create(
                        invpid_id = int(productid_id),
                        invcid_id = int(color_id),
                        invsid_id = int(size_id),
                        productinventory = int(c_pa.productinventory),
                        productinventory_recharge = int(c_pa.productinventory_recharge),
                        productinventory_sold = int(c_pa.productinventory_sold)-int(co.pcount),
                        productinventory_remain = int(c_pa.productinventory_remain)+int(inv),
                        pdesc = 'برگشت از فروش',
                        Create_Uid = request.user.id,
                        Update_Uid = request.user.id
                        )
        data = {
            'Cancelled': 'OK',
            'id': 'id',
            'html': html
        }
        return JsonResponse(data)


def groupdelete(request, rowid):
    User.objects.filter(id=rowid).delete()
    id= 0
    data = {'delete': 'OK', 'id': id,}
    return JsonResponse(data)
    


def cuseredit(request, gid, rowid):
    User.objects.all().filter(id=rowid).update(customersgroupid=gid)
    data = {'Changed': 'OK'}
    return JsonResponse(data)


class UserDashboardArticleLV(LoginRequiredMixin, generic.ListView):
    models = finalcheckout

    def get(self, request):
        userid = request.user.id
        users_sell_info = finalcheckout.objects.all().filter(Create_Uid=userid, status=1, sendstatus=0)

        id = 0
        return render(request, 'dashboardS.html', {'users_sell_info': users_sell_info, 'id': id})

class UserDashboardSentOrders(LoginRequiredMixin, generic.ListView):
    models = finalcheckout

    def get(self, request):
        userid = request.user.id
        users_sell_info = finalcheckout.objects.all().filter(Create_Uid=userid, status=1, sendstatus=1)

        id = 0
        return render(request, 'dashboardS_sent.html', {'users_sell_info': users_sell_info, 'id': id})

class UserDashboardCancelOrders(LoginRequiredMixin, generic.ListView):
    models = finalcheckout

    def get(self, request):
        userid = request.user.id
        users_sell_info = finalcheckout.objects.all().filter(Create_Uid=userid, status=2)

        id = 0
        return render(request, 'dashboardS_cancel.html', {'users_sell_info': users_sell_info, 'id': id})



# بخش گزارش های درآمدی
class salereport(View):
    def get(self, request, session_to_omit=None):
                
        ucount = 1
        activeuserpercent = 1
        totalsaleprise = 0
        statuszqerocount = sellbascket.objects.all().filter(status=0).count()
        if statuszqerocount > 0:
            totalsaleprise = sellbascket.objects.all().filter(status=0).aggregate(Sum=Sum('pprise'))['Sum']
        orderscount = sellbascket.objects.all().values_list('id').count()
        orders = sellbascket.objects.all()
        userid = User.objects.all()
        productsinfo = products.objects.all().filter(id__gt= 0)
        sessions = Session.objects.filter(expire_date__gt=timezone.now())
        uid_list = []
        for session in sessions:
            data = session.get_decoded()
            uid_list.append(data.get('_auth_user_id', None))

        ucount = User.objects.filter(id__in=uid_list).count()
        users_active_list = User.objects.filter(id__in=uid_list)
        useridcount = User.objects.all().values_list('id').count()
        activeuserpercent = (int(ucount) * 100)/int(useridcount)
        
        ts = sellbascket.objects.all().filter(status=1).aggregate(Sum=Sum('pprise'))['Sum']
        if ts == None:
            totalsale = 0
            tspercent = 0
        else:
            tspercent = 0
            totalsale = ts
            if totalsale == 0 or totalsaleprise == 0: 
                totalsale = 0
            else:
                tspercent = (int(totalsale) * 100)/int(totalsaleprise)

        tc = sellbascket.objects.all().filter(status=2).aggregate(Sum=Sum('pprise'))['Sum']
        if tc == None:
            totalcanceled = 0
            tcpercent = 0
        else:
            tcpercent = 0
            totalcanceled = tc
            if totalcanceled == 0 or totalsaleprise == 0  :
                totalcanceled = 0
            else:
                tcpercent = (int(totalcanceled) * 100)/int(totalsaleprise)
    

        os = finalcheckout.objects.filter(id__gt = 0).values_list('id').count()
        tpos = sellbascket.objects.all().values('pprise').aggregate(Sum=Sum('pprise'))['Sum']
        if os == 0:
            ordercount = 0
            ospercent = 0
            totalpriseos = 0
            totalpriseosp = 0
        else:
            ordercount = os
            ospercent = (int(ordercount) * 100)/300
            totalpriseos = tpos
            totalpriseosp = (int(ordercount) * 100)/100000000

        
        aos = finalcheckout.objects.all().filter(status=1, id__gt = 0).values_list('id').count()
        if aos == 0:
            aordercount = 0
            aospercent = 0
        else:
            aordercount = aos
            aospercent = (int(aordercount) * 100)/int(orderscount)

        
        osc = finalcheckout.objects.all().filter(status=2, id__gt = 0).values_list('id').count()
        if osc == 0:
            ordercancelcount = 0
            oscpercent = 0
        else:
            ordercancelcount = osc
            oscpercent = (int(ordercancelcount) * 100)/int(orderscount)

        
        uc = User.objects.all().values_list('id').filter(id__gt = 0).count()
        if uc == None:
            userscount = 0
        else:
            userscount = uc
        Users_i = User.objects.all().order_by('-id')
        if len(Users_i) > 9:
            Users_info = Users_i[:6]
        else:
            Users_info = User.objects.all().order_by('id')[1]

        total_products_count = products.objects.filter(id__gt=0).count()
        total_users_count = User.objects.filter(id__gt=0).count()
        total_dontsendorder_count = finalcheckout.objects.filter(status=1, sendstatus=0).count()
        total_sentorder_count = finalcheckout.objects.filter(status=1, sendstatus=1).count()
        total_cancelorder_count = finalcheckout.objects.filter(status=2).count()
        best_sale_products = sellbascket.objects.all().values('pid_id').annotate(count=Count('pid_id')).order_by('count')[:5]
        bs_pro_result = []
        for bspro in best_sale_products:
            bs_pro = productsparamerts.objects.filter(pid_id=bspro['pid_id']).values_list('productprice', flat=True).order_by('-productprice')
            minprice = max(list(bs_pro))
            pname = products.objects.get(id=bspro['pid_id']).name
            pimg1 = products.objects.get(id=bspro['pid_id']).img1
            bs_pro_result.append((pname,pimg1,minprice))

        zero_id = 0
        return render(request, 'Admin-Reports.html', {'totalsale': totalsale,
        'ordercount': ordercount,'Users_info': Users_info,'total_products_count': total_products_count,
        'ospercent': ospercent, 'orderscount': orderscount, 'oscpercent': oscpercent
        ,'totalcanceled': totalcanceled, 'tcpercent': tcpercent, 'tspercent': tspercent,
        'ordercancelcount': ordercancelcount, 'userscount': userscount, 'orders': orders,
        'userid': userid, 'total_users_count': total_users_count,
        'productsinfo': productsinfo, 'aordercount': aordercount, 'aospercent': aospercent,
        'totalpriseos': totalpriseos, 'totalpriseosp': totalpriseosp, 'ucount': ucount,
        'total_dontsendorder_count': total_dontsendorder_count,'bs_pro_result': bs_pro_result,
        'total_sentorder_count': total_sentorder_count,'total_cancelorder_count': total_cancelorder_count,
        'activeuserpercent': activeuserpercent, 'id': zero_id })


class SaleChartJson(View):
    def chart(request):
        persiandate = datetime.date(datetime.now())
        pd = str(persiandate)
        sfarvardin = '-01-01'
        fistpersiandate = pd[0:4] + sfarvardin

        year = fistpersiandate[0:4]+'-'+fistpersiandate[6:7]+'-'+fistpersiandate[9:10]
        dyear = datetime.strptime(year,'%Y-%m-%d')
        englishdate = datetime.date(dyear).togregorian()

        dayscreate = [30,130,230,330,430,530,629,729,829,929,1029,1128]
        last_day_of_month = []
        for dc in dayscreate:
            syear = fistpersiandate[0:4]+'0'+fistpersiandate[6:7]+'0'+fistpersiandate[9:10]
            far = int(syear) + int(dc)
            farvardin = str(far)
            cyear = farvardin[0:4]+'-'+farvardin[4:6]+'-'+farvardin[6:8]
            m1 = datetime.strptime(cyear,'%Y-%m-%d')
            englishdatem1 = datetime.date(m1).togregorian()
            last_day_of_month.append(englishdatem1)

        fi =  sellbascket.objects.all().filter(Create_Date__gt = englishdate, Create_Date__lte = last_day_of_month[0], status=1).aggregate(Sum=Sum('pprise'))['Sum']
        if fi == None:
            farvardin_incom = 0
        else:
            farvardin_incom = fi
        oi =  sellbascket.objects.all().filter(Create_Date__gt = last_day_of_month[0], Create_Date__lte = last_day_of_month[1], status=1).aggregate(Sum=Sum('pprise'))['Sum']
        if oi == None:
            ordibehesht_incom = 0
        else:
            ordibehesht_incom = oi
        ki =  sellbascket.objects.all().filter(Create_Date__gt = last_day_of_month[1], Create_Date__lte = last_day_of_month[2], status=1).aggregate(Sum=Sum('pprise'))['Sum']
        if ki == None:
            khordad_incom = 0
        else:
            khordad_incom = ki
        ti =  sellbascket.objects.all().filter(Create_Date__gt = last_day_of_month[2], Create_Date__lte = last_day_of_month[3], status=1).aggregate(Sum=Sum('pprise'))['Sum']
        if ti == None:
            tir_incom = 0
        else:
            tir_incom = ti
        mi =  sellbascket.objects.all().filter(Create_Date__gt = last_day_of_month[3], Create_Date__lte = last_day_of_month[4], status=1).aggregate(Sum=Sum('pprise'))['Sum']
        if mi == None:
            mordad_incom = 0
        else:
            mordad_incom = mi
        si =  sellbascket.objects.all().filter(Create_Date__gt = last_day_of_month[4], Create_Date__lte = last_day_of_month[5], status=1).aggregate(Sum=Sum('pprise'))['Sum']
        if si == None:
            shahrivar_incom = 0
        else:
            shahrivar_incom = si
        mei =  sellbascket.objects.all().filter(Create_Date__gt = last_day_of_month[5], Create_Date__lte = last_day_of_month[6], status=1).aggregate(Sum=Sum('pprise'))['Sum']
        if mei == None:
            mehr_incom = 0
        else:
            mehr_incom = mei
        abi =  sellbascket.objects.all().filter(Create_Date__gt = last_day_of_month[6], Create_Date__lte = last_day_of_month[7], status=1).aggregate(Sum=Sum('pprise'))['Sum']
        if abi == None:
            aban_incom = 0
        else:
            aban_incom = abi
        azi =  sellbascket.objects.all().filter(Create_Date__gt = last_day_of_month[7], Create_Date__lte = last_day_of_month[8], status=1).aggregate(Sum=Sum('pprise'))['Sum']
        if azi == None:
            azar_incom = 0
        else:
            azar_incom = azi
        dei =  sellbascket.objects.all().filter(Create_Date__gt = last_day_of_month[8], Create_Date__lte = last_day_of_month[9], status=1).aggregate(Sum=Sum('pprise'))['Sum']
        if dei == None:
            dey_incom = 0
        else:
            dey_incom = dei
        bahi =  sellbascket.objects.all().filter(Create_Date__gt = last_day_of_month[9], Create_Date__lte = last_day_of_month[10], status=1).aggregate(Sum=Sum('pprise'))['Sum']
        if bahi == None:
            bahman_incom = 0
        else:
            bahman_incom = bahi
        esi =  sellbascket.objects.all().filter(Create_Date__gt = last_day_of_month[10], Create_Date__lte = last_day_of_month[11], status=1).aggregate(Sum=Sum('pprise'))['Sum']
        if esi == None:
            esfand_incom = 0
        else:
            esfand_incom = esi



        afi =  sellbascket.objects.all().filter(Create_Date__gt = englishdate, Create_Date__lte = last_day_of_month[0]).aggregate(Sum=Sum('pprise'))['Sum']
        if afi == None:
            afarvardin_incom = 0
        else:
            afarvardin_incom = afi
        aoi =  sellbascket.objects.all().filter(Create_Date__gt = last_day_of_month[0], Create_Date__lte = last_day_of_month[1]).aggregate(Sum=Sum('pprise'))['Sum']
        if aoi == None:
            aordibehesht_incom = 0
        else:
            aordibehesht_incom = aoi
        aki =  sellbascket.objects.all().filter(Create_Date__gt = last_day_of_month[1], Create_Date__lte = last_day_of_month[2]).aggregate(Sum=Sum('pprise'))['Sum']
        if aki == None:
            akhordad_incom = 0
        else:
            akhordad_incom = aki
        ati =  sellbascket.objects.all().filter(Create_Date__gt = last_day_of_month[2], Create_Date__lte = last_day_of_month[3]).aggregate(Sum=Sum('pprise'))['Sum']
        if ati == None:
            atir_incom = 0
        else:
            atir_incom = ati
        ami =  sellbascket.objects.all().filter(Create_Date__gt = last_day_of_month[3], Create_Date__lte = last_day_of_month[4]).aggregate(Sum=Sum('pprise'))['Sum']
        if ami == None:
            amordad_incom = 0
        else:
            amordad_incom = ami
        asi =  sellbascket.objects.all().filter(Create_Date__gt = last_day_of_month[4], Create_Date__lte = last_day_of_month[5]).aggregate(Sum=Sum('pprise'))['Sum']
        if asi == None:
            ashahrivar_incom = 0
        else:
            ashahrivar_incom = asi
        amei =  sellbascket.objects.all().filter(Create_Date__gt = last_day_of_month[5], Create_Date__lte = last_day_of_month[6]).aggregate(Sum=Sum('pprise'))['Sum']
        if amei == None:
            amehr_incom = 0
        else:
            amehr_incom = amei
        aabi =  sellbascket.objects.all().filter(Create_Date__gt = last_day_of_month[6], Create_Date__lte = last_day_of_month[7]).aggregate(Sum=Sum('pprise'))['Sum']
        if aabi == None:
            aaban_incom = 0
        else:
            aaban_incom = aabi
        aazi =  sellbascket.objects.all().filter(Create_Date__gt = last_day_of_month[7], Create_Date__lte = last_day_of_month[8]).aggregate(Sum=Sum('pprise'))['Sum']
        if aazi == None:
            aazar_incom = 0
        else:
            aazar_incom = aazi
        adei =  sellbascket.objects.all().filter(Create_Date__gt = last_day_of_month[8], Create_Date__lte = last_day_of_month[9]).aggregate(Sum=Sum('pprise'))['Sum']
        if adei == None:
            adey_incom = 0
        else:
            adey_incom = adei
        abahi =  sellbascket.objects.all().filter(Create_Date__gt = last_day_of_month[9], Create_Date__lte = last_day_of_month[10]).aggregate(Sum=Sum('pprise'))['Sum']
        if abahi == None:
            abahman_incom = 0
        else:
            abahman_incom = abahi
        aesi =  sellbascket.objects.all().filter(Create_Date__gt = last_day_of_month[10], Create_Date__lte = last_day_of_month[11]).aggregate(Sum=Sum('pprise'))['Sum']
        if aesi == None:
            aesfand_incom = 0
        else:
            aesfand_incom = aesi



        cfi =  sellbascket.objects.all().filter(Create_Date__gt = englishdate, Create_Date__lte = last_day_of_month[0], status=2).aggregate(Sum=Sum('pprise'))['Sum']
        if cfi == None:
            cfarvardin_incom = 0
        else:
            cfarvardin_incom = cfi
        coi =  sellbascket.objects.all().filter(Create_Date__gt = last_day_of_month[0], Create_Date__lte = last_day_of_month[1], status=2).aggregate(Sum=Sum('pprise'))['Sum']
        if coi == None:
            cordibehesht_incom = 0
        else:
            cordibehesht_incom = coi
        cki =  sellbascket.objects.all().filter(Create_Date__gt = last_day_of_month[1], Create_Date__lte = last_day_of_month[2], status=2).aggregate(Sum=Sum('pprise'))['Sum']
        if cki == None:
            ckhordad_incom = 0
        else:
            ckhordad_incom = cki
        cti =  sellbascket.objects.all().filter(Create_Date__gt = last_day_of_month[2], Create_Date__lte = last_day_of_month[3], status=2).aggregate(Sum=Sum('pprise'))['Sum']
        if cti == None:
            ctir_incom = 0
        else:
            ctir_incom = cti
        cmi =  sellbascket.objects.all().filter(Create_Date__gt = last_day_of_month[3], Create_Date__lte = last_day_of_month[4], status=2).aggregate(Sum=Sum('pprise'))['Sum']
        if cmi == None:
            cmordad_incom = 0
        else:
            cmordad_incom = cmi
        csi =  sellbascket.objects.all().filter(Create_Date__gt = last_day_of_month[4], Create_Date__lte = last_day_of_month[5], status=2).aggregate(Sum=Sum('pprise'))['Sum']
        if csi == None:
            cshahrivar_incom = 0
        else:
            cshahrivar_incom = csi
        cmei =  sellbascket.objects.all().filter(Create_Date__gt = last_day_of_month[5], Create_Date__lte = last_day_of_month[6], status=2).aggregate(Sum=Sum('pprise'))['Sum']
        if cmei == None:
            cmehr_incom = 0
        else:
            cmehr_incom = cmei
        cabi =  sellbascket.objects.all().filter(Create_Date__gt = last_day_of_month[6], Create_Date__lte = last_day_of_month[7], status=2).aggregate(Sum=Sum('pprise'))['Sum']
        if cabi == None:
            caban_incom = 0
        else:
            caban_incom = cabi
        cazi =  sellbascket.objects.all().filter(Create_Date__gt = last_day_of_month[7], Create_Date__lte = last_day_of_month[8], status=2).aggregate(Sum=Sum('pprise'))['Sum']
        if cazi == None:
            cazar_incom = 0
        else:
            cazar_incom = cazi
        cdei =  sellbascket.objects.all().filter(Create_Date__gt = last_day_of_month[8], Create_Date__lte = last_day_of_month[9], status=2).aggregate(Sum=Sum('pprise'))['Sum']
        if cdei == None:
            cdey_incom = 0
        else:
            cdey_incom = cdei
        cbahi =  sellbascket.objects.all().filter(Create_Date__gt = last_day_of_month[9], Create_Date__lte = last_day_of_month[10], status=2).aggregate(Sum=Sum('pprise'))['Sum']
        if cbahi == None:
            cbahman_incom = 0
        else:
            cbahman_incom = cbahi
        cesi =  sellbascket.objects.all().filter(Create_Date__gt = last_day_of_month[10], Create_Date__lte = last_day_of_month[11], status=2).aggregate(Sum=Sum('pprise'))['Sum']
        if cesi == None:
            cesfand_incom = 0
        else:
            cesfand_incom = cesi



        data = {'list':[
             farvardin_incom,
             ordibehesht_incom,
             khordad_incom,
             tir_incom,
             mordad_incom,
             shahrivar_incom,
             mehr_incom,
             aban_incom,
             azar_incom,
             dey_incom,
             bahman_incom,
             esfand_incom],

             'list2':[
             afarvardin_incom,
             aordibehesht_incom,
             akhordad_incom,
             atir_incom,
             amordad_incom,
             ashahrivar_incom,
             amehr_incom,
             aaban_incom,
             aazar_incom,
             adey_incom,
             abahman_incom,
             aesfand_incom],

             'list3':[
             cfarvardin_incom,
             cordibehesht_incom,
             ckhordad_incom,
             ctir_incom,
             cmordad_incom,
             cshahrivar_incom,
             cmehr_incom,
             caban_incom,
             cazar_incom,
             cdey_incom,
             cbahman_incom,
             cesfand_incom]

        }

        return JsonResponse(data)


class takhfifreportjson(BaseDatatableView):
    model = mastertakhfif
    columns = ['', 'id','','takhfifpricetype','takhfiftype', 'pid_name', 'gid_name',
    'price','priceoffpercent', 'colorid_name', 'sizeid_name', 'desc' ]
    order_columns = ['', 'id','','takhfifpricetype','takhfiftype', 'pid_name', 'gid_name',
    'price','priceoffpercent', 'colorid_name', 'sizeid_name', 'desc' ]

    def render_column(self, row, column):
        return super(takhfifreportjson, self).render_column(row, column)

    def filter_queryset(self, qs):
        search = self.request.GET.get('search[value]', None)
        
        if search:
            qs = qs.filter(Q(pid_name__icontains=search)| Q(gid_name__icontains=search)
            |Q(colorid_name__icontains=search)| Q(sizeid_name__icontains=search))
            
        return qs

class productscolosreportrender(View):
    models = productscolors
    
    def get(self, request):
        color = productscolors.objects.all()
        return render(request, 'productscolorsreport.html', {'color': color })


def productscolorcreate(request):
    color_name = request.GET.get('color_name', None)
    color_hexa = request.GET.get('color_hexa', None)
    color_rgba = request.GET.get('color_rgba', None)
    if color_name != None:
        productscolors.objects.create(
            color = color_name,
            hezacode = color_hexa,
            rgbacode = color_rgba,
            Create_Uid = request.user.id,
            Update_Uid = request.user.id
        )
    data = {
        'data is created' : 'ok'
        }
    if color_name != None:
        data = {
            'color_name' : color_name
        }
        return JsonResponse(data)
    else:
        return render(request, 'productscolorsreport.html', {})


class productscolorsreport(BaseDatatableView):
    model = productscolors
    columns = ['', 'id', '', 'color', 'hezacode' , 'rgbacode']
    order_columns = ['', 'id', '', 'color', 'hezacode' , 'rgbacode']

    def render_column(self, row, column):
        return super(productscolorsreport, self).render_column(row, column)

    def filter_queryset(self, qs):
        search = self.request.GET.get('search[value]', None)
        
        if search:
            qs = qs.filter(Q(color__icontains=search)| Q(hezacode__icontains=search)| Q(rgbacode__icontains=search))
            
        return qs



class productssizereportrender(View):
    models = productssize
    
    def get(self, request):
        size = productssize.objects.all()
        return render(request, 'productssizereport.html', {'size': size })


def productssizecreate(request, psize):
    productssize.objects.create(
        size = psize,
        Create_Uid = request.user.id,
        Update_Uid = request.user.id
    )
    data = {
        'data is created' : 'ok'
    }

    return JsonResponse(data)


class productssizereport(BaseDatatableView):
    model = productssize
    columns = ['', 'id', '', 'size']
    order_columns = ['', 'id', '', 'size']

    def render_column(self, row, column):
        return super(productssizereport, self).render_column(row, column)

    def filter_queryset(self, qs):
        search = self.request.GET.get('search[value]', None)
        
        if search:
            qs = qs.filter(Q(size__icontains=search))
            
        return qs


class productsparametreportrender(View):
    models = productsparamerts
    
    def get(self, request):
        param = productsparamerts.objects.all()
        paramproducts = productsparamerts.objects.values('pid').annotate(count=Count('pid')).order_by('pid')
        productsname = []
        for name in paramproducts:
            prodc = products.objects.filter(id=name['pid']).values_list('id','name')
            productsname.append(prodc)
        lastpinfo = []
        for pp in productsname:
            lastpinfo.append(pp[0])
        product = products.objects.all()
        color = productscolors.objects.all()
        size = productssize.objects.all()
        return render(request, 'productsparametrs.html', {'param': param, 'products': product
        , 'color': color, 'size': size, 'lastpinfo': lastpinfo})


class productsparametrreport(BaseDatatableView):
    model = productsparamerts
    columns = ['','id', '' ,'pid' ,'cid', 'sid', 'paramserial', 'productinventory', 'productinventory_recharge'
    ,'productinventory_sold', 'productinventory_remain', 'productprice', 'takhfifprice',
    'takhfif', 'pdesc']
    order_columns = ['','id', '' ,'pid' ,'cid', 'sid', 'paramserial', 'productinventory', 'productinventory_recharge'
    ,'productinventory_sold', 'productinventory_remain', 'productprice', 'takhfifprice',
    'takhfif', 'pdesc']

    def render_column(self, row, column):
        return super(productsparametrreport, self).render_column(row, column)

    def filter_queryset(self, qs):
        search = self.request.GET.get('search[value]', None)
        
        if search:
            qs = qs.filter(Q(pid__name__icontains=search)| Q(cid__color__icontains=search)  
            | Q(sid__size__icontains=search)| Q(productinventory__icontains=search)
            | Q(productprice__icontains=search) | Q(paramserial__contains=search))
            
        return qs

class productsparametrcreate(View):
    def get(self,request):
        ppid = request.GET.get('ppid', None)
        pcid = request.GET.get('pcid', None)
        psid = request.GET.get('psid', None)
        pproductinventory = request.GET.get('pproductinventory', None)
        pproductprice = request.GET.get('pproductprice', None)
        productdesc = request.GET.get('productdesc', None)
        html = ''
        pro_id = 0
        get_serial = products.objects.get(id=ppid).serial
        param_get_id = productsparamerts.objects.filter(pid_id=ppid, cid_id=pcid, sid_id=psid)
        if param_get_id:
            for pgi in param_get_id:
                html = '<p class="fw-bold text-danger text-start>کالای مورد نظر در سیستم موجود است - کد کالا : </p>'
                pro_id = pgi.id
        else:
            productsparamerts.objects.create(
                pid_id = int(ppid),
                cid_id = int(pcid),
                sid_id = int(psid),
                paramserial = get_serial,
                productinventory = pproductinventory,
                productinventory_sold = 0,
                productinventory_remain = pproductinventory,
                productprice = pproductprice,
                takhfif = pproductprice,
                pdesc = productdesc,
                Create_Uid = request.user.id,
                Update_Uid = request.user.id
            )

        html_final = html
        pro_id_final = pro_id
        data = {
            'data is created' : 'ok',
            'html_final': html_final,
            'pro_id_final': pro_id_final
        }

        return JsonResponse(data)


class getcolorsid(View):
    def get(self, request):
        co_id = request.GET.get('co_id', None)
        pid = request.GET.get('pid', None)
        max_p_price = []
        for lstid in range(1):
            param_best = productsparamerts.objects.filter(pid_id= pid, cid_id=co_id).values_list('productprice', 'pid', 'takhfif', 'takhfifprice', 'productinventory_remain').order_by('takhfifprice')
            max_p_price.append(param_best)
        max_min_price_info_getcolorsid = []
        for mpp in max_p_price:
            if len(mpp) > 0:
                remain_sum = productsparamerts.objects.filter(pid_id = mpp[0][1]).aggregate(sum=Sum('productinventory_remain'))['sum']
                max_product_price = max(list(mpp))
                min_product_price = min(list(mpp))
                product_price_select = mpp[0][1]
                product_price_after_takhfif = mpp[0][2]
                product_productinventory_remain = mpp[0][3]
                max_min_price_info_getcolorsid.append((product_price_select,max_product_price[0],min_product_price[0], product_price_after_takhfif, product_productinventory_remain, remain_sum, max_product_price[2], int(max_product_price[4])))

        html = ''
        html += '<option value="0">---------</option>'
        param_size_id = productsparamerts.objects.filter(cid_id=co_id, pid_id = pid).values_list('sid_id').order_by('sid_id')
        for size_id in param_size_id:
            size =  productssize.objects.filter(id = int(size_id[0]))
            html += '<option class="text-center text-dark h6 getsizeid" value="{id}">{cname}</option>'.format(id=int(size_id[0]), cname=size[0])
        
        new_price = 0
        old_price = 0
        if len(max_min_price_info_getcolorsid) != 0:
            new_price = int(max_min_price_info_getcolorsid[0][3])
            old_price = int(max_min_price_info_getcolorsid[0][2])

        org_price = 0
        if int(max_min_price_info_getcolorsid[0][4]) == 0:
            org_price = int(max_min_price_info_getcolorsid[0][2])
            new_price = 0
            old_price = 0

        data = {
            'html': html,
            'new_price': new_price,
            'old_price': old_price,
            'org_price': org_price,
            }
        
        return JsonResponse(data)


class getparamrowid(View):
    def get(self, request):
        getcoid = request.GET.get('getcoid', 0)
        getsiid = request.GET.get('getsiid', 0)
        getpiid = request.GET.get('getpiid', 0)
        max_p_price = []
        for lstid in range(1):
            param_best = productsparamerts.objects.filter(pid_id= getpiid, cid_id=getcoid , sid_id=getsiid).values_list('productprice', 'pid', 'takhfif', 'takhfifprice', 'productinventory_remain').order_by('takhfifprice')
            max_p_price.append(param_best)
        max_min_price_info_getcolorsid = []
        for mpp in max_p_price:
            if len(mpp) > 0:
                remain_sum = productsparamerts.objects.filter(pid_id = mpp[0][1]).aggregate(sum=Sum('productinventory_remain'))['sum']
                max_product_price = max(list(mpp))
                min_product_price = min(list(mpp))
                product_price_select = mpp[0][1]
                product_price_after_takhfif = mpp[0][2]
                product_productinventory_remain = mpp[0][3]
                max_min_price_info_getcolorsid.append((product_price_select,max_product_price[0],min_product_price[0], product_price_after_takhfif, product_productinventory_remain, remain_sum, max_product_price[2], int(max_product_price[4])))

        param_deesc = 'شرح ...'
        p_d = productsparamerts.objects.filter(pid_id= getpiid, cid_id=getcoid , sid_id=getsiid).values_list('pdesc', flat=True)
        if len(p_d)>0:
            param_deesc = p_d[0]

        param_count = 0
        p_i = productsparamerts.objects.filter(pid_id= getpiid, cid_id=getcoid , sid_id=getsiid).values_list('productinventory_remain', flat=True)
        if len(p_i)>0:
            param_count = p_i[0]

        new_price = 0
        old_price = 0
        if len(max_min_price_info_getcolorsid) != 0:
            new_price = int(max_min_price_info_getcolorsid[0][3])
            old_price = int(max_min_price_info_getcolorsid[0][2])

        org_price = 0
        if int(max_min_price_info_getcolorsid[0][4]) == 0:
            org_price = int(max_min_price_info_getcolorsid[0][2])
            new_price = 0
            old_price = 0

        data = {
            'new_price': new_price,
            'old_price': old_price,
            'org_price': org_price,
            'param_deesc': param_deesc,
            'param_count': param_count,
            }
        
        return JsonResponse(data)


class getsizeid(View):
    def get(self, request):
        si_id = request.GET.get('si_id', None)
        pid = request.GET.get('pid', None)
        max_p_price = []
        for lstid in range(1):
            param_best = productsparamerts.objects.filter(pid_id= pid, sid_id=si_id).values_list('productprice', 'pid', 'takhfif', 'takhfifprice', 'productinventory_remain').order_by('id')
            max_p_price.append(param_best)
        max_min_price_info_getcolorsid = []
        for mpp in max_p_price:
            if len(mpp) > 0:
                remain_sum = productsparamerts.objects.filter(pid_id = mpp[0][1]).aggregate(sum=Sum('productinventory_remain'))['sum']
                max_product_price = max(list(mpp))
                min_product_price = min(list(mpp))
                product_price_select = mpp[0][1]
                product_price_after_takhfif = mpp[0][2]
                product_productinventory_remain = mpp[0][3]
                max_min_price_info_getcolorsid.append((product_price_select,max_product_price[0],min_product_price[0], product_price_after_takhfif, product_productinventory_remain, remain_sum, max_product_price[2], int(max_product_price[4])))

        html = ''
        html += '<option value="0">---------</option>'
        param_color_id = productsparamerts.objects.filter(sid_id=si_id, pid_id = pid).values_list('cid_id').order_by('cid_id')
        for color_id in param_color_id:
            color =  productscolors.objects.filter(id = int(color_id[0]))
            html += '<option class="text-center text-dark h6 getcolorid" value="{id}">{cname}</option>'.format(id=int(color_id[0]), cname=color[0])
            

        new_price = 0
        old_price = 0
        if len(max_min_price_info_getcolorsid) != 0:
            new_price = int(max_min_price_info_getcolorsid[0][3])
            old_price = int(max_min_price_info_getcolorsid[0][2])

        org_price = 0
        if int(max_min_price_info_getcolorsid[0][4]) == 0:
            org_price = int(max_min_price_info_getcolorsid[0][2])
            new_price = 0
            old_price = 0

        data = {
            'html': html,
            'new_price': new_price,
            'old_price': old_price,
            'org_price': org_price,

            }
        
        return JsonResponse(data)


class productsparametrreporttakhfif(View):
    def get(self, request):
        takhfiftype = request.GET.get('takhfif_type', 0)
        html = ''
        html += '<option value="0">همه</option>'
        takhfif = 0
        if int(takhfiftype) == 2:
            if int(takhfiftype) > 0:
                takhfif = int(takhfiftype)
                if int(takhfif) == 2:
                    paramproducts = productsparamerts.objects.values('pid').annotate(count=Count('pid')).order_by('pid')
                    productsgrouid = []
                    for name in paramproducts:
                        prodc = products.objects.filter(id=name['pid']).values_list('group_id')
                        productsgrouid.append(prodc)
                        
                    group_info = productsgroups.objects.all().filter(id__gt=0, id__in=productsgrouid).values_list('id', 'Group_Name')
                    for groupinfo in group_info:
                        html += '<option class="text-center text-dark h6 getcolorid" value="{id}">{groupname}</option>'.format(id=int(groupinfo[0]), groupname=groupinfo[1])
            data = {
                "takhfiftype": int(takhfiftype),
                "html": html
                }
        else:
            paramproducts = productsparamerts.objects.values('pid').annotate(count=Count('pid')).order_by('pid')
            for name in paramproducts:
                prodc = products.objects.filter(id=name['pid']).values_list('id','name')
                for pro_dc in prodc:
                    html += '<option class="text-center text-dark h6 getcolorid" value="{id}">{name}</option>'.format(id=int(pro_dc[0]), name=pro_dc[1])  
            data = {
                "takhfiftype": int(takhfiftype),
                "html": html
            }
        
        return JsonResponse(data)


class takhfifselectsize(View):
    def get(self, request):
        pid = request.GET.get('pid', None)
        html = ''
        html += '<option value="0">همه</option>'
        takhfifsize_id = productsparamerts.objects.filter(pid_id = pid).values('sid_id').annotate(count=Count('sid_id')).order_by('sid_id')
        for takhfifsize in takhfifsize_id:
            size =  productssize.objects.filter(id = int(takhfifsize['sid_id']))
            html += '<option class="text-center text-dark h6 getcolorid" value="{id}">{name}</option>'.format(id=int(takhfifsize["sid_id"]), name=size[0])

        data = {
            'html': html,
            }
        
        return JsonResponse(data)


class takhfifcands(View):
    def get(self, request):
        pid = request.GET.get('pid', 0)
        cands = request.GET.get('cands', 0)
        html = ''
        html += '<option value="0">همه</option>'
        if cands == '0':
            takhfifsize_id = productsparamerts.objects.filter(pid_id = pid).values_list('sid_id').order_by('sid_id')
            for takhfifsize in takhfifsize_id:
                size =  productssize.objects.filter(id = int(takhfifsize[0]))
                html += '<option class="text-center text-dark h6 getcolorid" value="{id}">{name}</option>'.format(id=int(takhfifsize[0]), name=size[0])
        if cands == '1':
            takhfifcolor_id = productsparamerts.objects.filter(pid_id = pid).values('cid_id').annotate(count=Count('cid_id')).order_by('cid_id')
            for takhfifcolor in takhfifcolor_id:
                color =  productscolors.objects.filter(id = int(takhfifcolor['cid_id']))
                html += '<option class="text-center text-dark h6 getcolorid" value="{id}">{name}</option>'.format(id=int(takhfifcolor['cid_id']), name=color[0])

        data = {
            'html': html,
            'cands': cands,
            }
        
        return JsonResponse(data)

class takecolorsandsizes(View):
    def get(self, request):
        pid = request.GET.get('pid', 0)
        cands = request.GET.get('cands', 0)
        size = request.GET.get('size', 0)
        html = ''
        html += '<option value="0">همه</option>'

        takhfifcolor_id = productsparamerts.objects.filter(sid_id = int(size), pid_id = int(pid)).values('cid_id').annotate(count=Count('cid_id')).order_by('cid_id')
        for takhfifcolor in takhfifcolor_id:
            color =  productscolors.objects.filter(id = int(takhfifcolor['cid_id']))
            html += '<option class="text-center text-dark h6 getcolorid" value="{id}">{name}</option>'.format(id=int(takhfifcolor['cid_id']), name=color[0])

        data = {
            'html': html,
            }
        
        return JsonResponse(data)


class selectgrouplevel(View):
    def get(self, request):
        group_level = request.GET.get('group_level', 0)
        html = ''
        html += '<option value="0">---------</option>'

        if int(group_level) == 1:
            glevel_one = productsgroups.objects.filter(glevel=1, id__gt=0).values_list('id', 'Group_Name')
            for g_one in glevel_one:
                html += '<option class="text-center text-dark h6 getcolorid" value="{id}">{name}</option>'.format(id=int(g_one[0]), name=g_one[1])
        if int(group_level) == 2: 
            glevel_two = productsgroups.objects.filter(glevel=2, id__gt=0).values_list('id', 'Group_Name', 'gparentid')
            for g_two in glevel_two:
                gparent_name = productsgroups.objects.filter(id=g_two[2]).values_list('Group_Name', flat=True)
                html += '<option class="text-center text-dark h6 getcolorid" value="{id}">{name} ( {gparentname} )</option>'.format(id=int(g_two[0]), name=g_two[1], gparentname=gparent_name[0])

        data = {
            'html': html,
            }
        
        return JsonResponse(data)



def createtakhfif(request, send_pid, pidid, send_gid, gidid, send_price, send_priceoffpercent, send_desc, send_colorid, cidid, send_sizeid, sidid, send_takhfiftype, send_takhfifpricetype):
    mt = mastertakhfif(
        pid_name = send_pid,
        pid = pidid,
        gid_name = send_gid,
        gid = gidid,
        price = send_price,
        priceoffpercent = send_priceoffpercent,
        desc = send_desc,
        colorid_name = send_colorid,
        colorid = cidid,
        sizeid_name = send_sizeid,
        sizeid = sidid,
        takhfiftype = send_takhfiftype,
        takhfifpricetype = send_takhfifpricetype,
        Create_Uid = request.user.id,
        Update_Uid = request.user.id
    )
    mt.save()

    return 'ok'

class makediscountzero(View):
    def get(self, request):
        html = ''
        takhfif_type = request.GET.get('takhfif_type', 0)
        product_obj = request.GET.get('product_obj', 0)
        color_obj = request.GET.get('color_obj', 0)
        size_obj = request.GET.get('size_obj', 0)
        group_obj = request.GET.get('group_obj', 0)

        if int(takhfif_type) == 1:
            if int(product_obj) > 0 and int(color_obj) > 0 and int(size_obj) > 0:
                selectedparam = productsparamerts.objects.filter(pid_id=product_obj, cid_id=color_obj, sid_id=size_obj)
                for sepa in selectedparam:
                    productsparamerts.objects.filter(pid_id=product_obj, cid_id=color_obj, sid_id=size_obj).update(takhfif=sepa.productprice, takhfifprice=0)
                html = 'تخفیف مربوط به این کالا صفر گردید .'
                
            elif int(product_obj) > 0 and int(color_obj) == 0 and int(size_obj) > 0:
                selectedparam = productsparamerts.objects.filter(pid_id=product_obj, sid_id=size_obj)
                for sepa in selectedparam:
                    productsparamerts.objects.filter(pid_id=product_obj, sid_id=size_obj).update(takhfif=sepa.productprice, takhfifprice=0)
                html = 'تخفیف مربوط به این کالا صفر گردید .'

            elif int(product_obj) > 0 and int(color_obj) == 0 and int(size_obj) == 0:
                selectedparam = productsparamerts.objects.filter(pid_id=product_obj)
                for sepa in selectedparam:
                    productsparamerts.objects.filter(pid_id=product_obj).update(takhfif=sepa.productprice, takhfifprice=0)
                html = 'تخفیف مربوط به این کالا صفر گردید .'

        elif int(takhfif_type) == 2:
            s_p_group = products.objects.filter(Q(group_id=int(group_obj))| Q(group__gparentid=int(group_obj)))
            param_products = []
            for p_pro in s_p_group:
                ppro = productsparamerts.objects.all().filter(pid_id=p_pro.id).values_list('pid_id', 'productprice')
                if len(ppro) > 0:
                    param_products.append(ppro)

            for pro_update in param_products:
                productsparamerts.objects.filter(pid_id=pro_update[0][0]).update(takhfif=float(pro_update[0][1]), takhfifprice=0)
            html = 'تخفیف کلیه کالا های مربوط به گروه انتخابی صفر گردید .'
            
        data = {
            'html': html,
            }
        return JsonResponse(data)


class calpriceoforallproducts(View):
    def get(self, request):
        html= ''
        html_exist_products = ''
        tapr = 0
        takhfif_type = request.GET.get('takhfif_type', None)
        price_type = request.GET.get('price_type', None)
        product_obj = request.GET.get('product_obj', None)
        color_obj = request.GET.get('color_obj', None)
        size_obj = request.GET.get('size_obj', None)
        group_obj = request.GET.get('group_obj', None)
        pricep_kala = request.GET.get('pricep_kala', None)
        pricep_group = request.GET.get('pricep_group', None)
        if int(takhfif_type) == 1:
            param_id = 0
            if int(product_obj) > 0 and int(color_obj) > 0 and int(size_obj) > 0:
                param_id = productsparamerts.objects.filter(pid_id=product_obj, cid_id=color_obj, sid_id=size_obj)
            elif int(product_obj) > 0 and int(color_obj) == 0 and int(size_obj) > 0:
                param_id = productsparamerts.objects.filter(pid_id=product_obj, sid_id=size_obj)
            elif int(product_obj) > 0 and int(color_obj) == 0 and int(size_obj) == 0:
                param_id = productsparamerts.objects.filter(pid_id=product_obj)

            if len(param_id) > 0:
                if int(price_type) == 1:
                    selectedparam = 0

                    if int(product_obj) > 0 and int(color_obj) > 0 and int(size_obj) > 0:
                        selectedparam = productsparamerts.objects.filter(pid_id=product_obj, cid_id=color_obj, sid_id=size_obj)
                    elif int(product_obj) > 0 and int(color_obj) == 0 and int(size_obj) > 0:
                        selectedparam = productsparamerts.objects.filter(pid_id=product_obj, sid_id=size_obj)
                    elif int(product_obj) > 0 and int(color_obj) == 0 and int(size_obj) == 0:
                        selectedparam = productsparamerts.objects.filter(pid_id=product_obj)

                    for sepa in selectedparam:
                        tapr = int(pricep_kala)
                        sepa_after_price_takhfif = float(sepa.productprice) - float(pricep_kala)

                        productsname = products.objects.filter(id=int(product_obj)).values_list('name', flat=True)
                        products_color = productscolors.objects.filter(id=int(color_obj)).values_list('color', flat=True)
                        products_size = productssize.objects.filter(id=int(size_obj)).values_list('size', flat=True)
                        productsid = products.objects.filter(id=int(product_obj)).values_list('id', flat=True)
                        products_colorid = productscolors.objects.filter(id=int(color_obj)).values_list('id', flat=True)
                        products_sizeid = productssize.objects.filter(id=int(size_obj)).values_list('id', flat=True)

                        if int(product_obj) > 0 and int(color_obj) > 0 and int(size_obj) > 0 and int(sepa_after_price_takhfif) > 0:
                            productsparamerts.objects.filter(pid_id=product_obj, cid_id=color_obj, sid_id=size_obj).update(takhfif = tapr, takhfifprice = sepa_after_price_takhfif)
                            mastertakhfif.objects.filter(pid=product_obj, colorid=color_obj, sizeid=size_obj).delete()
                            createtakhfif(request, productsname[0],productsid[0], 0,0, int(pricep_kala), 0 ,'تخفیف بر اساس کالا و مبلغ', products_color[0],products_colorid[0], products_size[0],products_sizeid[0], 1, 1)
                        elif int(product_obj) > 0 and int(color_obj) == 0 and int(size_obj) > 0 and int(sepa_after_price_takhfif) > 0:

                            productsparamerts.objects.filter(id = sepa.id).update(takhfif = tapr , takhfifprice = sepa_after_price_takhfif)
                            mastertakhfif.objects.filter(pid=product_obj, sizeid=size_obj).delete()
                            createtakhfif(request, productsname[0],productsid[0], 0,0, int(pricep_kala), 0 ,'تخفیف بر اساس کالا و مبلغ', products_color[0],products_colorid[0], products_size[0],products_sizeid[0], 1, 1)
                        elif int(product_obj) > 0 and int(color_obj) == 0 and int(size_obj) == 0 and int(sepa_after_price_takhfif) > 0:
                            productsparamerts.objects.filter(id=sepa.id).update(takhfif = tapr , takhfifprice = sepa_after_price_takhfif)
                            mastertakhfif.objects.filter(pid=product_obj).delete()
                            createtakhfif(request, productsname[0],productsid[0], 0,0, int(pricep_kala), 0 ,'تخفیف بر اساس کالا و مبلغ', products_color[0],products_colorid[0], products_size[0],products_sizeid[0], 1, 1)
                        html = 'تخفیف برای کالای {pid} با رنگ {color} و سایز {size} و با مبلغ {price} ایجاد گردید .'.format(pid=productsname[0], color=products_color[0], size=products_size[0], price=int(pricep_kala))
                        
                if int(price_type) == 2:
                    selectedparam = 0

                    if int(product_obj) > 0 and int(color_obj) > 0 and int(size_obj) > 0:
                        selectedparam = productsparamerts.objects.filter(pid_id=product_obj, cid_id=color_obj, sid_id=size_obj)
                    elif int(product_obj) > 0 and int(color_obj) == 0 and int(size_obj) > 0:
                        selectedparam = productsparamerts.objects.filter(pid_id=product_obj, sid_id=size_obj)
                    elif int(product_obj) > 0 and int(color_obj) == 0 and int(size_obj) == 0:
                        selectedparam = productsparamerts.objects.filter(pid_id=product_obj)

                    for sepa in selectedparam:
                        tapr = (int(sepa.productprice) * int(pricep_kala)) / 100
                        sepa_after_price_takhfif = float(sepa.productprice) - float(tapr)
                        
                        productsname = products.objects.filter(id=int(product_obj)).values_list('name', flat=True)
                        products_color = productscolors.objects.filter(id=int(color_obj)).values_list('color', flat=True)
                        products_size = productssize.objects.filter(id=int(size_obj)).values_list('size', flat=True)
                        productsid = products.objects.filter(id=int(product_obj)).values_list('id', flat=True)
                        products_colorid = productscolors.objects.filter(id=int(color_obj)).values_list('id', flat=True)
                        products_sizeid = productssize.objects.filter(id=int(size_obj)).values_list('id', flat=True)

                        if int(product_obj) > 0 and int(color_obj) > 0 and int(size_obj) > 0 and int(sepa_after_price_takhfif) > 0:
                            productsparamerts.objects.filter(pid_id=product_obj, cid_id=color_obj, sid_id=size_obj).update(takhfif = sepa_after_price_takhfif, takhfifprice = tapr)
                            mastertakhfif.objects.filter(pid=product_obj, colorid=color_obj, sizeid=size_obj).delete()
                            createtakhfif(request, productsname[0],productsid[0], 0, 0, 0,int(pricep_kala) ,'تخفیف بر اساس کالا و درصد',  products_color[0],products_colorid[0], products_size[0],products_sizeid[0], 1, 2)
                        elif int(product_obj) > 0 and int(color_obj) == 0 and int(size_obj) > 0 and int(sepa_after_price_takhfif) > 0:
                            productsparamerts.objects.filter(id = sepa.id).update(takhfif = sepa_after_price_takhfif, takhfifprice = tapr)
                            mastertakhfif.objects.filter(pid=product_obj, sizeid=size_obj).delete()
                            createtakhfif(request, productsname[0],productsid[0], 0, 0, 0,int(pricep_kala) ,'تخفیف بر اساس کالا و درصد',  products_color[0],products_colorid[0], products_size[0],products_sizeid[0], 1, 2)
                        elif int(product_obj) > 0 and int(color_obj) == 0 and int(size_obj) == 0 and int(sepa_after_price_takhfif) > 0:
                            productsparamerts.objects.filter(id = sepa.id).update(takhfif = sepa_after_price_takhfif, takhfifprice = tapr)
                            mastertakhfif.objects.filter(pid=product_obj).delete()
                            createtakhfif(request, productsname[0],productsid[0], 0, 0, 0,int(pricep_kala) ,'تخفیف بر اساس کالا و درصد',  products_color[0],products_colorid[0], products_size[0],products_sizeid[0], 1, 2)
                        
                        html = 'تخفیف برای کالای {pid} با رنگ {color} و سایز {size} و با مبلغ {price} ایجاد گردید .'.format(pid=productsname[0], color=products_color[0], size=products_size[0], price=int(tapr))
        if int(takhfif_type) == 2:
            s_p_group = products.objects.filter(Q(group_id=int(group_obj))| Q(group__gparentid=int(group_obj)))
            param_products = []
            for p_pro in s_p_group:
                ppro = productsparamerts.objects.all().filter(pid_id=p_pro.id).values_list('pid_id', flat=True)
                if len(ppro) > 0:
                    param_products.append(ppro)

            if len(param_products) > 0:
                if int(price_type) == 1:
                    selectedparam = []
                    for se_p_gr in param_products:
                        sedp = productsparamerts.objects.filter(pid_id=se_p_gr[0]).values_list('id', 'productprice', 'productinventory', 'pid_id')
                        selectedparam.append(sedp)
                    if len(selectedparam) > 0:
                        for sepa in list(selectedparam):
                            for sepa_final in sepa:
                                if len(sepa_final) > 0:
                                    if int(sepa_final[2]) > 0:
                                        sepa_after_price_takhfif = float(sepa_final[1]) - float(pricep_group)

                                        groupname = productsgroups.objects.filter(id=int(group_obj)).values_list('Group_Name', flat=True)
                                        groupid = productsgroups.objects.filter(id=int(group_obj)).values_list('id', flat=True)
                                        productsparamerts.objects.filter(id=int(sepa_final[0]), pid_id=int(sepa_final[3])).update(takhfif = sepa_after_price_takhfif , takhfifprice = pricep_group) 
                                        mastertakhfif.objects.filter(gid=groupid[0]).delete()
                                        pro_of_group = products.objects.filter(Q(group_id=groupid[0]) | Q(group__gparentid=groupid[0])).values_list('id', flat=True)
                                        mastertakhfif.objects.filter(pid__in=pro_of_group).delete()
                                        createtakhfif(request, 0,0, groupname[0],groupid[0], int(pricep_group), 0 ,'تخفیف بر اساس گروه کالا و مبلغ', 0,0,0,0, 2, 1)   
                                        html = 'تخفیف روی گروه {group} و با مبلغ {price} ایجاد گردید .'.format(group=groupname[0], price=int(pricep_group))
                if int(price_type) == 2:
                    selectedparam = []
                    for se_p_gr in param_products:
                        sedp = productsparamerts.objects.filter(pid_id=se_p_gr[0]).values_list('id', 'productprice', 'productinventory', 'pid_id')
                        selectedparam.append(sedp)
                    if len(selectedparam) > 0:
                        for sepa in list(selectedparam):
                            for sepa_final in sepa:
                                if len(sepa_final) > 0:
                                    if int(sepa_final[2]) > 0:
                                        groupname = productsgroups.objects.filter(id=int(group_obj)).values_list('Group_Name', flat=True)
                                        groupid = productsgroups.objects.filter(id=int(group_obj)).values_list('id', flat=True)
                                        if int(pricep_group) > 0:
                                            tapr = (int(sepa_final[1]) * int(pricep_group)) / 100
                                            sepa_after_price_takhfif = float(sepa_final[1]) - float(tapr)
                                            productsparamerts.objects.filter(id=int(sepa_final[0]), pid_id=int(sepa_final[3])).update(takhfif= sepa_after_price_takhfif , takhfifprice = tapr)
                                            mastertakhfif.objects.filter(gid=groupid[0]).delete()
                                            pro_of_group = products.objects.filter(Q(group_id=groupid[0]) | Q(group__gparentid=groupid[0])).values_list('id', flat=True)
                                            mastertakhfif.objects.filter(pid__in=pro_of_group).delete()
                                            createtakhfif(request, 0,0, groupname[0],groupid[0], 0, int(pricep_group) ,'تخفیف بر اساس گروه کالا و درصد', 0, 0, 0, 0, 2, 2)
                                            html = 'تخفیف روی گروه {group} و با مبلغ {price} ایجاد گردید .'.format(group=groupname[0], price=int(tapr))
                                        else:
                                            mastertakhfif.objects.filter(gid=groupid[0]).delete()
                                            pro_of_group = products.objects.filter(Q(group_id=groupid[0]) | Q(group__gparentid=groupid[0])).values_list('id', flat=True)
                                            mastertakhfif.objects.filter(pid__in=pro_of_group).delete()
                                            createtakhfif(request, 0,0, groupname[0],groupid[0], 0, int(pricep_group) ,'تخفیف بر اساس گروه کالا و درصد', 0, 0, 0, 0, 2, 2)
                                            productsparamerts.objects.filter(id=int(sepa_final[0]), pid_id=int(sepa_final[3])).update(takhfif= int(sepa_final[1]), takhfifprice = 0)
                                            html = 'تخفیف روی گروه {group} و با مبلغ {price} ایجاد گردید .'.format(group=groupname[0], price=int(tapr))
            else:                       
                html = 'در گروه {group} کالایی وجود ندارد .'.format(group=group_obj)
        data = {
            'dataIsOk': 'dataIsOk',
            'html': html,
            'html_exist_products': html_exist_products
            }
        
        return JsonResponse(data)


class calpriceoforselectedproducts(View):
    def get(self, request):
        html= ''
        html_exist_products = ''
        tapr = 0
        takhfif_type = request.GET.get('takhfif_type', None)
        price_type = request.GET.get('price_type', None)
        product_obj = request.GET.get('product_obj', None)
        color_obj = request.GET.get('color_obj', None)
        size_obj = request.GET.get('size_obj', None)
        group_obj = request.GET.get('group_obj', None)
        pricep_kala = request.GET.get('pricep_kala', None)
        pricep_group = request.GET.get('pricep_group', None)
        mproductlist = mastertakhfif.objects.all().values('pid').annotate(count=Count('pid')).order_by()
        if int(takhfif_type) == 1:
            param_id = productsparamerts.objects.filter(pid_id=product_obj, cid_id=color_obj, sid_id=size_obj)
            if len(param_id) > 0:
                exist_product = mastertakhfif.objects.filter(pid=product_obj, colorid=color_obj, sizeid=size_obj).values_list('id', 'pid_name', 'colorid_name', 'sizeid_name')
                if len(exist_product) == 0:
                    if int(price_type) == 1:
                        selectedparam = productsparamerts.objects.filter(pid_id=product_obj, cid_id=color_obj, sid_id=size_obj)
                        for sepa in selectedparam:
                            tapr = int(pricep_kala)
                            sepa_after_price_takhfif = float(sepa.productprice) - float(pricep_kala)
                            if int(sepa_after_price_takhfif) >= 0:
                                productsparamerts.objects.filter(pid_id=product_obj, cid_id=color_obj, sid_id=size_obj).update(takhfif= tapr, takhfifprice = sepa_after_price_takhfif)
                                productsname = products.objects.filter(id=int(product_obj)).values_list('name', flat=True)
                                products_color = productscolors.objects.filter(id=int(color_obj)).values_list('color', flat=True)
                                products_size = productssize.objects.filter(id=int(size_obj)).values_list('size', flat=True)
                                productsid = products.objects.filter(id=int(product_obj)).values_list('id', flat=True)
                                products_colorid = productscolors.objects.filter(id=int(color_obj)).values_list('id', flat=True)
                                products_sizeid = productssize.objects.filter(id=int(size_obj)).values_list('id', flat=True)
                                checktakhfif = mastertakhfif.objects.filter(pid=productsid[0], colorid=products_colorid[0], sizeid=products_sizeid[0]).values_list('id', flat=True)
                                if len(checktakhfif) == 0:
                                    createtakhfif(request, productsname[0],productsid[0], 0,0, int(pricep_kala), 0 ,'تخفیف بر اساس کالا و مبلغ', products_color[0],products_colorid[0], products_size[0],products_sizeid[0], 1, 1)    
                                else:
                                    html = 'برای کالای ',productsname[0],' با رنگ ',products_color[0],' و سایز ',products_size[0],' قبلا با کد : ',checktakhfif[0],' تخفیف ایجاد شده است'     
                            else:
                                html = 'به دلیل منفی شدن مبلغ پس از تخفیف روی کالای {pid} از کالا ها انجام این عملیات برای این کالا امکان پذیر نمی باشد'.format(pid = product_obj)
                    if int(price_type) == 2:
                        selectedparam = productsparamerts.objects.filter(pid_id=product_obj, cid_id=color_obj, sid_id=size_obj)
                        for sepa in selectedparam:
                            tapr = (int(sepa.productprice) * int(pricep_kala)) / 100
                            sepa_after_price_takhfif = float(sepa.productprice) - float(tapr)
                            if int(sepa_after_price_takhfif) >= 0:
                                productsparamerts.objects.filter(pid_id=product_obj, cid_id=color_obj, sid_id=size_obj).update(takhfif= tapr, takhfifprice = sepa_after_price_takhfif)
                                productsname = products.objects.filter(id=int(product_obj)).values_list('name', flat=True)
                                products_color = productscolors.objects.filter(id=int(color_obj)).values_list('color', flat=True)
                                products_size = productssize.objects.filter(id=int(size_obj)).values_list('size', flat=True)
                                productsid = products.objects.filter(id=int(product_obj)).values_list('id', flat=True)
                                products_colorid = productscolors.objects.filter(id=int(color_obj)).values_list('id', flat=True)
                                products_sizeid = productssize.objects.filter(id=int(size_obj)).values_list('id', flat=True)
                                checktakhfif = mastertakhfif.objects.filter(pid=productsid[0], colorid=products_colorid[0], sizeid=products_sizeid[0]).values_list('id', flat=True)
                                if len(checktakhfif) == 0:
                                    createtakhfif(request, productsname[0],productsid[0], 0, 0, int(tapr),0 ,'تخفیف بر اساس کالا و درصد',  products_color[0],products_colorid[0], products_size[0],products_sizeid[0], 1, 2)
                                else:
                                    html = 'برای کالای ',productsname[0],' با رنگ ',products_color[0],' و سایز ',products_size[0],' قبلا با کد : ',checktakhfif[0],' تخفیف ایجاد شده است'     
                            else:
                                html = 'به دلیل منفی شدن مبلغ پس از تخفیف روی کالای {pid} از کالا ها انجام این عملیات برای این کالا امکان پذیر نمی باشد'.format(pid = product_obj)
                else:
                    for existp in exist_product:
                        html = ' برای  ',existp[1],'  بارنگ  ',existp[2],'  وباسایز  ',existp[3],'  در جدول تخفیف ها و با کد  ',existp[0],' قبلا تخفیف ایجاد شده است  '
            else:
                html = 'کاربر گرامی : کالا با اطلاعات انتخابی مورد نظر وجود ندارد'
        if int(takhfif_type) == 2:
            s_p_group = products.objects.filter(Q(group_id=int(group_obj))| Q(group__gparentid=int(group_obj)))
            param_products = []
            for p_pro in s_p_group:
                ppro = productsparamerts.objects.all().filter(pid_id=p_pro.id).values_list('pid_id', flat=True)
                if len(ppro) > 0:
                    param_products.append(ppro)

            if len(param_products) > 0:
                if int(price_type) == 1:
                    selectedparam = []
                    for se_p_gr in param_products:
                        sedp = productsparamerts.objects.filter(pid_id=se_p_gr[0]).values_list('id', 'productprice', 'productinventory', 'pid_id')
                        selectedparam.append(sedp)
                    if len(selectedparam) > 0:
                        for sepa in list(selectedparam):
                            for sepa_final in sepa:
                                if len(sepa_final) > 0:
                                    if int(sepa_final[2]) > 0:
                                        sepa_after_price_takhfif = float(sepa_final[1]) - float(pricep_group)
                                        groupname = productsgroups.objects.filter(id=int(group_obj)).values_list('Group_Name', flat=True)
                                        groupid = productsgroups.objects.filter(id=int(group_obj)).values_list('id', flat=True)
                                        checktakhfif = mastertakhfif.objects.filter(gid=groupid[0]).values_list('id', flat=True)
                                        checktakhfif_gproducts = productsgroups.objects.filter(id=groupid[0]).values_list('id', 'gparentid', 'glevel')
                                        for check_gp in checktakhfif_gproducts:
                                            if check_gp[2] == 1:
                                                glevel2goup = productsgroups.objects.filter(gparentid=check_gp[0]).values_list('id', flat=True)
                                                ex_pro =[]
                                                ex_pro_id = []
                                                for mpro in mproductlist:
                                                    exist_products = products.objects.filter(group_id__in=glevel2goup, id=mpro['pid'], id__gt=0).values_list('name', flat=True)
                                                    if len(exist_products) > 0:
                                                        ex_pro.append(exist_products[0])
                                                    exist_products_update = products.objects.filter(group_id__in=glevel2goup, id=mpro['pid'], id__gt=0).values_list('id', flat=True)
                                                    if len(exist_products_update) > 0:
                                                        ex_pro_id.append(exist_products_update[0])
                                             
                                                html_exist_products = 'در گروه ',groupname[0],' قبلا برای : ',ex_pro,' تخفیف ایجاد شده است , لذا در مبلغ تخفیف این کالا ها تغییری ایجاد نخواهد شد .', 
                                                if len(ex_pro_id) > 0:
                                                    productsparamerts.objects.filter(id=int(sepa_final[0]), pid_id=int(sepa_final[3])).exclude(~Q(id__in=ex_pro_id)).update(takhfif=pricep_group, takhfifprice=sepa_after_price_takhfif)
                                                
                                            productsparamerts.objects.filter(id=int(sepa_final[0]), pid_id=int(sepa_final[3])).update(takhfif=pricep_group, takhfifprice=sepa_after_price_takhfif)
                    
                        if len(checktakhfif) == 0:
                            createtakhfif(request, 0,0, groupname[0],groupid[0], int(pricep_group), 0 ,'تخفیف بر اساس گروه کالا و مبلغ', 0,0,0,0, 2, 1)
                        else:
                            html = 'برای گروه ',groupname[0],' قبلا با کد : ',checktakhfif[0],'  تخفیف ایجاد شده است .',     
                    else:
                        html = 'کاربر گرامی : کالایی با گروه انتخابی مورد نظر وجود ندارد'
                if int(price_type) == 2:
                    selectedparam = []
                    for se_p_gr in param_products:
                        sedp = productsparamerts.objects.filter(pid_id=se_p_gr[0]).values_list('id', 'productprice', 'productinventory', 'pid_id')
                        selectedparam.append(sedp)
                    if len(selectedparam) > 0:
                        for sepa in list(selectedparam):
                            for sepa_final in sepa:
                                if len(sepa_final) > 0:
                                    if int(sepa_final[2]) > 0:
                                        tapr = (int(sepa_final[1]) * int(pricep_group)) / 100
                                        sepa_after_price_takhfif = float(sepa_final[1]) - float(tapr)
                                        groupname = productsgroups.objects.filter(id=int(group_obj)).values_list('Group_Name', flat=True)
                                        groupid = productsgroups.objects.filter(id=int(group_obj)).values_list('id', flat=True)
                                        checktakhfif = mastertakhfif.objects.filter(gid=groupid[0]).values_list('id', flat=True)
                                        checktakhfif_gproducts = productsgroups.objects.filter(id=groupid[0]).values_list('id', 'gparentid', 'glevel')
                                        for check_gp in checktakhfif_gproducts:
                                            if check_gp[2] == 1:
                                                glevel2goup = productsgroups.objects.filter(gparentid=check_gp[0]).values_list('id', flat=True)
                                                for mpro in mproductlist:
                                                    ex_pro =[]
                                                    ex_pro_id = []
                                                    for mpro in mproductlist:
                                                        exist_products = products.objects.filter(group_id__in=glevel2goup, id=mpro['pid'], id__gt=0).values_list('name', flat=True)
                                                        if len(exist_products) > 0:
                                                            ex_pro.append(exist_products[0])
                                                        exist_products_update = products.objects.filter(group_id__in=glevel2goup, id=mpro['pid'], id__gt=0).values_list('id', flat=True)
                                                        if len(exist_products_update) > 0:
                                                            ex_pro_id.append(exist_products_update[0])
                                             
                                                    html_exist_products = 'در گروه ',groupname[0],' قبلا برای : ',ex_pro,' تخفیف ایجاد شده است , لذا در مبلغ تخفیف این کالا ها تغییری ایجاد نخواهد شد .', 
                                                    if len(ex_pro_id) > 0:
                                                        productsparamerts.objects.filter(id=int(sepa_final[0]), pid_id=int(sepa_final[3])).exclude(~Q(id__in=ex_pro_id)).update(takhfif=sepa_after_price_takhfif, takhfifprice=tapr)
                                            productsparamerts.objects.filter(id=int(sepa_final[0]), pid_id=int(sepa_final[3])).update(takhfif= tapr, takhfifprice= sepa_after_price_takhfif)

                        if len(checktakhfif) == 0:
                            createtakhfif(request, 0,0, groupname[0],groupid[0], int(tapr), 0 ,'تخفیف بر اساس گروه کالا و درصد', 0, 0, 0, 0, 2, 2)
                        else:
                            html = 'برای گروه ',groupname[0],' قبلا با کد : ',checktakhfif[0],'  تخفیف ایجاد شده است .', 
            else:
                html = 'کاربر گرامی : کالایی با گروه انتخابی مورد نظر وجود ندارد'

        data = {
            'dataIsOk': 'dataIsOk',
            'html': html,
            'html_exist_products': html_exist_products
            }
        
        return JsonResponse(data)


class productsparaminv(LoginRequiredMixin, PermissionRequiredMixin, generic.ListView):
    models = productsparaminvcharge
    template_name = 'productsparamchargeinv.html'
    permission_required = 'can_read_private_section'

    def get(self,request):
        chargedinv_info = self.models.objects.all()
        paramproducts = productsparamerts.objects.values('pid_id').annotate(count=Count('pid_id')).order_by()
        products_info_charge = []
        for pinfo in paramproducts:
            prodc = products.objects.filter(id=pinfo['pid_id']).values_list('id','name')
            products_info_charge.append(prodc)
        colors = productscolors.objects.all()
        sizes = productssize.objects.all()
        return render(request, self.template_name, {'chargedinv_info': chargedinv_info,
         'products_info_charge': products_info_charge, 'colors': colors, 'sizes': sizes})


class productsparamchargeinvjsonreport(BaseDatatableView):
    model = productsparaminvcharge
    columns = ['', 'id', '', 'invpid', 'invcid', 'invsid', 'productinventory', 'productinventory_recharge', 'productinventory_sold', 'productinventory_remain']
    order_columns = ['', 'id', '', 'invpid', 'invcid', 'invsid',  'productinventory', 'productinventory_recharge', 'productinventory_sold', 'productinventory_remain']

    def render_column(self, row, column):
        return super(productsparamchargeinvjsonreport, self).render_column(row, column)

    def filter_queryset(self, qs):
        search = self.request.GET.get('search[value]', None)
        
        if search:
            qs = qs.filter(Q(invpid__name__icontains=search)| Q(invcid__color__contains=search)  
            | Q(invsid__size__contains=search)| Q(productinventory__contains=search)
            | Q(productinventory_recharge__contains=search)| Q(productinventory_sold__contains=search)
            | Q(productinventory_remain__contains=search))
            
        return qs


class productsparaminvcreate(View):
    def get(self,request):
        result_invppid = request.GET.get('invppid', None)
        result_invpcid = request.GET.get('invpcid', None)
        result_invpsid = request.GET.get('invpsid', None)
        result_invpproductinventory = request.GET.get('invpproductinventory', None)
        result_invproductdesc = request.GET.get('invproductdesc', None)
        html = ''
        productsparametrsinfo = productsparamerts.objects.filter(pid_id=int(result_invppid), cid_id=int(result_invpcid), sid_id=int(result_invpsid))
        if productsparametrsinfo:
            for pcharge in productsparametrsinfo:
                new_remain = int(pcharge.productinventory_remain) + int(result_invpproductinventory)
                productsparaminvcharge.objects.create(
                    invpid_id = int(result_invppid),
                    invcid_id = int(result_invpcid),
                    invsid_id = int(result_invpsid),
                    productinventory = int(pcharge.productinventory),
                    productinventory_recharge = int(result_invpproductinventory),
                    productinventory_sold = int(pcharge.productinventory_sold),
                    productinventory_remain = new_remain,
                    pdesc = result_invproductdesc,
                    Create_Uid = request.user.id,
                    Update_Uid = request.user.id
                    )
                new_charge = (pcharge.productinventory_recharge) + int(result_invpproductinventory)
                productsparamerts.objects.filter(pid_id=int(result_invppid), cid_id=int(result_invpcid), sid_id=int(result_invpsid)).update(
                    productinventory_recharge = int(new_charge),
                     productinventory_remain = new_remain)
        else:
            html = 'کاربر گرامی : کالا با اطلاعات وارد شده در لیست پارامتر ها وجودندارد'
        data = {
            'data is created' : 'ok',
            'html': html
        }

        return JsonResponse(data)



class carttocart(View):
    def get(self,request):
        result_carttocart_cardno = request.GET.get('carttocart_cardno', None)
        result_carttocart_trackingcode = request.GET.get('carttocart_trackingcode', None)
        result_carttocart_price = request.GET.get('carttocart_price', None)
        html = ''
        sellbascket.objects.filter(Create_Uid=request.user.id, status=0).update(TrackingCode = int(result_carttocart_trackingcode))
        checksell = sellbascket.objects.filter(Create_Uid=request.user.id, status=0,TrackingCode = int(result_carttocart_trackingcode)).values_list('TrackingCode', flat=True)
        if checksell:
            maxid = finalcheckout.objects.latest('id').id
            finalcheckout.objects.create(
                id = int(maxid)+1,
                senddate = datetime.date(datetime.now()).togregorian(),
                sendstatus = 0,
                postcode = '',
                sendtype = 2,
                first_name = request.user.first_name,
                last_name = request.user.last_name,
                cellphone = request.user.cellphone,
                email = request.user.email,
                totalprise = int(result_carttocart_price),
                TrackingCode = int(result_carttocart_trackingcode),
                BankTrackingCode = int(result_carttocart_trackingcode),
                bank_card_no = int(result_carttocart_cardno),
                status = 1,
                colorid_bycolor = 0,
                sizeid_bycolor = 0,
                colorid_bysize = 0,
                sizeid_bysize = 0,
                order_id = 0,
                Create_Uid = request.user.id,
                Update_Uid = request.user.id,

            )
            html = 'مشتری گرامی : سفارش شما با موفقیت ثبت گردید .'
            sellbascket.objects.filter(Create_Uid=request.user.id, status=0, TrackingCode = int(result_carttocart_trackingcode)).update(status=1)
            uoi_result = []
            user_order_info = sellbascket.objects.filter(Create_Uid=request.user.id, status =1, TrackingCode=int(result_carttocart_trackingcode)).values_list('pid', 'colorid_bycolor', 'sizeid_bycolor', 'colorid_bysize', 'sizeid_bysize', 'pcount')
            for uoi in user_order_info:
                uoi_result.append(uoi)

            for uoir in uoi_result:
                if int(uoir[1]) != 0:
                    p_color_info = productsparamerts.objects.filter(pid_id=uoir[0], cid_id=uoir[1], sid_id=uoir[2])
                    for pci in p_color_info:
                        soldcount = int(pci.productinventory_sold) + int(uoir[5])
                        remaincount = (int(pci.productinventory) + int(pci.productinventory_recharge)) - int(soldcount)
                        if int(remaincount) >= 0:
                            productsparamerts.objects.filter(id=pci.id).update(productinventory_sold=soldcount, productinventory_remain=remaincount)
                            productsparaminvcharge.objects.create(
                            invpid_id = int(pci.pid_id),
                            invcid_id = int(pci.cid_id),
                            invsid_id = int(pci.sid_id),
                            productinventory = int(pci.productinventory),
                            productinventory_recharge = int(pci.productinventory_recharge),
                            productinventory_sold = int(uoir[5]),
                            productinventory_remain = remaincount,
                            pdesc = 'فروش - کارت به کارت',
                            Create_Uid = request.user.id,
                            Update_Uid = request.user.id
                            )
                        else:
                            html = 'به دلیل منفی شدن موجودی برخی از کالا ها امکان انجام این عملیات وجود ندارد'
                if int(uoir[1]) == 0:
                    p_size_info = productsparamerts.objects.filter(pid_id=uoir[0], cid_id=uoir[3], sid_id=uoir[4])
                    for psi in p_size_info:
                        soldcount = int(psi.productinventory_sold) + int(uoir[5])
                        remaincount = (int(psi.productinventory) + int(psi.productinventory_recharge)) - int(soldcount)
                        if int(remaincount) >= 0:
                            productsparamerts.objects.filter(id=psi.id).update(productinventory_sold=soldcount, productinventory_remain=remaincount)
                            productsparaminvcharge.objects.create(
                            invpid_id = int(psi.pid_id),
                            invcid_id = int(psi.cid_id),
                            invsid_id = int(psi.sid_id),
                            productinventory = int(psi.productinventory),
                            productinventory_recharge = int(psi.productinventory_recharge),
                            productinventory_sold = int(uoir[5]),
                            productinventory_remain = remaincount,
                            pdesc = 'فروش - کارت به کارت',
                            Create_Uid = request.user.id,
                            Update_Uid = request.user.id
                            )
                        else:
                            html = 'به دلیل منفی شدن موجودی برخی از کالا ها امکان انجام این عملیات وجود ندارد'
        else:
            html = ' سفارشی با کد پیگیری ثبت شده در سیستم وجود ندارد.'
        data = {
            'html' : html
        }
        return JsonResponse(data)


class takhfifreport(View):
    def get(self, request):
        takhfifiino = mastertakhfif.objects.all()
        return render(request, 'mastertakhfifreport.html', {'takhfifiino': takhfifiino})


class GroupDeleteRows(View):
    def get(self, request):
        html = ''
        rowsid = request.GET.get('rowid', 0)
        ModelName = request.GET.get('model', 0)
        modelinfo = apps.get_model('WebSite', ModelName)

        modelinfo.objects.filter(id=int(rowsid)).delete()

        html = 'ردیف و یا ردیف ها با شماره :',rowsid,'حذف گردید .'
        data = {
            'html': html
        }
        return JsonResponse(data)


class tadilpath(View):
    def get(self, request):
        tadil_type = request.GET.get('tadil_type', 0)
        html = ''
        html += '<option value="0">---------</option>'
        tadil = 0
        
        if int(tadil_type) == 1:
            paramproducts = productsparamerts.objects.values('pid').annotate(count=Count('pid')).order_by()
            for name in paramproducts:
                prodc = products.objects.filter(id=name['pid']).values_list('id','name')
                for pro_dc in prodc:
                    html += '<option class="text-center text-dark h6 getcolorid" value="{id}">{name}</option>'.format(id=int(pro_dc[0]), name=pro_dc[1])  
            data = {
                "tadil_type": int(tadil_type),
                "html": html
            }

        elif int(tadil_type) == 2:
            paramproducts = productsparamerts.objects.values('pid').annotate(count=Count('pid')).order_by()
            for name in paramproducts:
                prodc = products.objects.filter(id=name['pid']).values_list('id','name')
                for pro_dc in prodc:
                    html += '<option class="text-center text-dark h6 getcolorid" value="{id}">{name}</option>'.format(id=int(pro_dc[0]), name=pro_dc[1])  
            data = {
                "tadil_type": int(tadil_type),
                "html": html
            }

        elif int(tadil_type) == 3:
            if int(tadil_type) > 0:
                tadil = int(tadil_type)
                if int(tadil) == 3:
                    paramproducts = productsparamerts.objects.values('pid').annotate(count=Count('pid')).order_by()
                    productsgrouid = []
                    for name in paramproducts:
                        prodc = products.objects.filter(id=name['pid']).values_list('group_id')
                        productsgrouid.append(prodc)
                        
                    group_info = productsgroups.objects.filter(id__gt=0, id__in=productsgrouid).values_list('id', 'Group_Name', 'gparentid')
                    for groupinfo in group_info:
                        gparent_name = productsgroups.objects.filter(id=groupinfo[2]).values_list('Group_Name', flat=True)
                        html += '<option class="text-center text-dark h6 getcolorid" value="{id}">{groupname} ( {gparentname} )</option>'.format(id=int(groupinfo[0]), groupname=groupinfo[1], gparentname=gparent_name[0])
            data = {
                "tadil_type": int(tadil_type),
                "html": html
                }
        return JsonResponse(data)


class tadilcalculate(View):
    def get(self, request):
        html= ''
        html_price_error = ''
        tadil_type = request.GET.get('tadil_type', None)
        tapgselect_type = request.GET.get('tapgselect_type', None)
        product_obj = request.GET.get('product_obj', None)
        color_obj = request.GET.get('color_obj', None)
        size_obj = request.GET.get('size_obj', None)
        group_obj = request.GET.get('group_obj', None)
        pricep_kala = request.GET.get('pricep_kala', None)
        pricep_group = request.GET.get('pricep_group', None)
        producttpall_obj = request.GET.get('producttpall_obj', None)
        pricep_to_all = request.GET.get('pricep_to_all', None)
        paramid = productsparamerts.objects.filter(pid_id=product_obj, cid_id=color_obj, sid_id=size_obj).values_list('id', 'productprice', 'productinventory', 'takhfif', 'takhfifprice', 'productinventory_remain', 'productinventory_recharge', 'productinventory_sold')
        param_id_toall = productsparamerts.objects.filter(pid_id=producttpall_obj).values_list('id', 'productprice', 'productinventory', 'takhfif', 'takhfifprice', 'productinventory_remain', 'productinventory_recharge', 'productinventory_sold')
    
        if int(tapgselect_type) == 1:
            for param_id in paramid:
                if int(tadil_type) == 1:
                    productsparamerts.objects.filter(pid_id=product_obj, cid_id=color_obj, sid_id=size_obj).update(
                        productprice= int(param_id[1]) + int(pricep_kala),
                        takhfif= int(param_id[3]) + int(pricep_kala)
                    )
                if int(tadil_type) == 2:
                    if (int(param_id[1]) - int(pricep_kala)) < int(param_id[4]) or (int(param_id[3]) - int(pricep_kala)) < 0:
                        html_price_error += 'انجام تعدیل باعث منفی شدن ردیف  : {id} می شود , بنابراین این تغییر برای این ردیف انجام نگردید . {linebreaker}'.format(id=str(param_id[0]), linebreaker='<br>')
                    else: 
                        productsparamerts.objects.filter(pid_id=product_obj, cid_id=color_obj, sid_id=size_obj).update(
                            productprice = int(param_id[1]) - int(pricep_kala),
                            takhfif = int(param_id[3]) - int(pricep_kala)
                        )
                if int(tadil_type) == 3:
                    productsparamerts.objects.filter(pid_id=product_obj, cid_id=color_obj, sid_id=size_obj).update(
                        productprice= int(param_id[1]) + int((int(param_id[1]) * int(pricep_kala))/100),
                        takhfif= int(param_id[3]) + int((int(param_id[1]) * int(pricep_kala))/100)
                    )
                if int(tadil_type) == 4:
                    if (int(param_id[1]) - int((int(param_id[1]) * int(pricep_kala))/100)) < int(param_id[4]) or (int(param_id[3]) - int((int(param_id[1]) * int(pricep_kala))/100)) < 0:
                        html_price_error += 'انجام تعدیل باعث منفی شدن ردیف  : {id} می شود , بنابراین این تغییر برای این ردیف انجام نگردید . {linebreaker}'.format(id=str(param_id[0]), linebreaker='<br>')
                    else:
                        productsparamerts.objects.filter(pid_id=product_obj, cid_id=color_obj, sid_id=size_obj).update(
                            productprice = int(param_id[1]) - int((int(param_id[1]) * int(pricep_kala))/100),
                            takhfif = int(param_id[3]) - int((int(param_id[1]) * int(pricep_kala))/100),
                        )
                if int(tadil_type) == 5:
                    productsparamerts.objects.filter(pid_id=product_obj, cid_id=color_obj, sid_id=size_obj).update(
                        productinventory= int(param_id[2]) + int(pricep_kala),
                        productinventory_remain = int(param_id[5]) + int(pricep_kala),
                    )
                if int(tadil_type) == 6:
                    if ((int(param_id[2]) + int(param_id[6])) - int(pricep_kala)) < int(param_id[7]) or int(param_id[5]) - int(pricep_kala) < 0:
                        html_price_error += 'انجام تعدیل باعث منفی شدن ردیف  : {id} می شود , بنابراین این تغییر برای این ردیف انجام نگردید . {linebreaker}'.format(id=str(param_id[0]), linebreaker='<br>')
                    else:
                        productsparamerts.objects.filter(pid_id=product_obj, cid_id=color_obj, sid_id=size_obj).update(
                            productinventory= int(param_id[2]) - int(pricep_kala),
                            productinventory_remain = int(param_id[5]) - int(pricep_kala)
                        )
                if int(tadil_type) == 7:
                    productsparamerts.objects.filter(pid_id=product_obj, cid_id=color_obj, sid_id=size_obj).update(
                         productinventory_remain = 0
                    ) 
        if int(tapgselect_type) == 2:
            for param_id_all in param_id_toall:
                if int(tadil_type) == 1:
                    productsparamerts.objects.filter(id=param_id_all[0]).update(
                        productprice= int(param_id_all[1]) + int(pricep_to_all),
                        takhfif= int(param_id_all[3]) + int(pricep_to_all),
                    )
                if int(tadil_type) == 2:
                    if (int(param_id_all[1]) - int(pricep_to_all)) < int(param_id_all[4]) or (int(param_id_all[3]) - int(pricep_to_all)) < 0:
                        html_price_error += 'انجام تعدیل باعث منفی شدن ردیف  : {id} می شود , بنابراین این تغییر برای این ردیف انجام نگردید . {linebreaker}'.format(id=str(param_id_all[0]), linebreaker='<br>')
                    else: 
                        productsparamerts.objects.filter(id=param_id_all[0]).update(
                            productprice = int(param_id_all[1]) - int(pricep_to_all),
                            takhfif = int(param_id_all[3]) - int(pricep_to_all)
                        )
                elif int(tadil_type) == 3:
                    productsparamerts.objects.filter(id=param_id_all[0]).update(
                        productprice= int(param_id_all[1]) + int((int(param_id_all[1]) * int(pricep_to_all))/100),
                        takhfif= int(param_id_all[3]) + int((int(param_id_all[1]) * int(pricep_to_all))/100)
                    )
                if int(tadil_type) == 4:
                    if (int(param_id_all[1]) - int((int(param_id_all[1]) * int(pricep_to_all))/100)) < int(param_id_all[4]) or (int(param_id_all[3]) - int((int(param_id_all[1]) * int(pricep_to_all))/100)) < 0:
                        html_price_error += 'انجام تعدیل باعث منفی شدن ردیف  : {id} می شود , بنابراین این تغییر برای این ردیف انجام نگردید . {linebreaker}'.format(id=str(param_id_all[0]), linebreaker='<br>')
                    else: 
                        productsparamerts.objects.filter(id=param_id_all[0]).update(
                            productprice= int(param_id_all[1]) - int((int(param_id_all[1]) * int(pricep_to_all))/100),
                            takhfif = int(param_id_all[3]) - int((int(param_id_all[1]) * int(pricep_to_all))/100)
                        )
                if int(tadil_type) == 5:
                    productsparamerts.objects.filter(id=param_id_all[0]).update(
                        productinventory = int(param_id_all[2]) + int(pricep_to_all),
                        productinventory_remain = int(param_id_all[5]) + int(pricep_to_all)
                    )
                if int(tadil_type) == 6:
                    if ((int(param_id_all[2]) + int(param_id_all[6])) - int(pricep_to_all)) < int(param_id_all[7]) or int(param_id_all[5]) - int(pricep_group) < 0:
                        html_price_error += 'انجام تعدیل باعث منفی شدن ردیف  : {id} می شود , بنابراین این تغییر برای این ردیف انجام نگردید . {linebreaker}'.format(id=str(param_id_all[0]), linebreaker='<br>')
                    else:
                        productsparamerts.objects.filter(id=param_id_all[0]).update(
                            productinventory = int(param_id_all[2]) - int(pricep_to_all),
                            productinventory_remain = int(param_id_all[5]) - int(pricep_to_all)
                        )
                if int(tadil_type) == 7:
                    productsparamerts.objects.filter(id=param_id_all[0]).update(
                         productinventory_remain = 0
                    ) 
        if int(tapgselect_type) == 3:
            grpup_product = products.objects.filter(Q(group_id=int(group_obj))| Q(group__gparentid=int(group_obj))).values_list('id', flat=True)
            s_p_group = productsparamerts.objects.filter(pid_id__in=grpup_product)
            for p_pro in s_p_group:
                if int(tadil_type) == 1:
                    productsparamerts.objects.filter(id=p_pro.id).update(
                    productprice= int(p_pro.productprice) + int(pricep_group),
                    takhfif = int(p_pro.takhfif) + int(pricep_group)
                    )
                elif int(tadil_type) == 2:
                    if (int(p_pro.productprice) - int(pricep_group)) < int(p_pro.takhfifprice) or (int(p_pro.takhfif) - int(pricep_group)) < 0:
                        html_price_error += 'انجام تعدیل باعث منفی شدن ردیف  : {id} می شود , بنابراین این تغییر برای این ردیف انجام نگردید . {linebreaker}'.format(id=str(p_pro.id), linebreaker='<br>')
                    else:    
                        productsparamerts.objects.filter(id=p_pro.id).update(
                        productprice= int(p_pro.productprice) - int(pricep_group),
                        takhfif = int(p_pro.takhfif) - int(pricep_group)
                    )
                elif int(tadil_type) == 3:
                    productsparamerts.objects.filter(id=p_pro.id).update(
                    productprice = int(p_pro.productprice) + int((int(p_pro.productprice) * int(pricep_group))/100)
                    , takhfif = int(p_pro.takhfif) + int((int(p_pro.productprice) * int(pricep_group))/100)
                    )

                elif int(tadil_type) == 4:
                    if (int(p_pro.productprice) - int((int(p_pro.productprice) * int(pricep_group))/100)) < int(p_pro.takhfifprice) or (int(p_pro.takhfif) - int((int(p_pro.productprice) * int(pricep_group))/100)) < 0:
                        html_price_error += 'انجام تعدیل باعث منفی شدن ردیف  : {id} می شود , بنابراین این تغییر برای این ردیف انجام نگردید . {linebreaker}'.format(id=str(p_pro.id), linebreaker='<br>')
                    else: 
                        productsparamerts.objects.filter(pid_id=p_pro.id).update(
                        productprice = int(p_pro.productprice) - int((int(p_pro.productprice) * int(pricep_group))/100)
                        , takhfif = int(p_pro.takhfif) - int((int(p_pro.productprice) * int(pricep_group))/100)
                    )
                elif int(tadil_type) == 5:
                        productsparamerts.objects.filter(id=p_pro.id).update(
                        productinventory = int(p_pro.productinventory) + int(pricep_group),
                        productinventory_remain = int(p_pro.productinventory_remain) + int(pricep_group)
                    )
                elif int(tadil_type) == 6:
                    if ((int(p_pro.productinventory) + int(p_pro.productinventory_recharge)) - int(pricep_group)) < int(p_pro.productinventory_sold) or int(p_pro.productinventory_recharge) - int(pricep_group) < 0:
                        html_price_error += 'انجام تعدیل باعث منفی شدن ردیف  : {id} می شود , بنابراین این تغییر برای این ردیف انجام نگردید . {linebreaker}'.format(id=str(p_pro.id), linebreaker='<br>')
                    else: 
                        productsparamerts.objects.filter(id=p_pro.id).update(
                        productinventory= int(p_pro.productinventory) - int(pricep_group),
                        productinventory_remain = int(p_pro.productinventory_remain) - int(pricep_group)
                    )
                elif int(tadil_type) == 7:
                    productsparamerts.objects.filter(id=p_pro.id).update(
                    productinventory_remain = 0, 
                    )
        html = 'تعدیل های مورد نظر با موفقیت انجام شد '
        data = {
            'html': html,
            'html_price_error': html_price_error
            }
        
        return JsonResponse(data)


class AjaxErsalCreate(View):
    def get(self,request):
        cost_ersal_maxprice = request.GET.get('cost_ersal_maxprice', 0)
        cost_ersal_maxcount = request.GET.get('cost_ersal_maxcount', 0)
        cost_ersal_price = request.GET.get('cost_ersal_price', 0)
        DM_Type = request.GET.get('DM_Type', 0)
        DM_exist = DiscountFinal.objects.all().values_list('id', flat=True)
        if len(DM_exist) == 0:
            if cost_ersal_price != 0:
                ersalcost = DiscountFinal(
                    Dmax_Type=int(DM_Type),
                    DmaxPriceToSend=int(cost_ersal_maxprice),
                    DmaxCountToSend=int(cost_ersal_maxcount),
                    ErsalPrice=int(cost_ersal_price),
                    Create_Uid=request.user.id,
                    Update_Uid=request.user.id)
                ersalcost.save()
            else:
                html = 'مبلغ به درستی وارد نشده است'

        else:
            if cost_ersal_price != 0:
                 DiscountFinal.objects.filter(id=DM_exist[0]).update(
                    Dmax_Type=int(DM_Type),
                    DmaxPriceToSend=int(cost_ersal_maxprice),
                    DmaxCountToSend=int(cost_ersal_maxcount),
                    ErsalPrice=int(cost_ersal_price),
                    Create_Uid=request.user.id,
                    Update_Uid=request.user.id
                 )
            else:
                html = 'مبلغ به درستی وارد نشده است'

        html = 'هزینه ارسال با موفقیت ایجاد گردید .'
        data = {
            'html': html
        }
        return JsonResponse(data)